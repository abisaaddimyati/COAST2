<div style="height: 100%; width: 100%; background-color: #fff; position: relative;">
	<img src="<?php echo img_url();?>coming-soon.png" style="display: block; margin: auto">
</div>