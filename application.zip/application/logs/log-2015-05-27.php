<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-27 00:54:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-27 00:55:31 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-05-27 08:56:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-27 20:06:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-27 20:08:41 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-05-27 20:14:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-27 22:12:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-27 22:12:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-27 23:02:11 --> 404 Page Not Found --> favicon.ico
