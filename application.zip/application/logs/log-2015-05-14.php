<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-14 00:24:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-14 01:08:15 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-14 01:08:16 --> 404 Page Not Found --> mobile
ERROR - 2015-05-14 01:28:05 --> 404 Page Not Found --> m
ERROR - 2015-05-14 12:42:35 --> 404 Page Not Found --> mobile
ERROR - 2015-05-14 12:50:22 --> 404 Page Not Found --> m
ERROR - 2015-05-14 21:19:18 --> 404 Page Not Found --> favicon.ico
