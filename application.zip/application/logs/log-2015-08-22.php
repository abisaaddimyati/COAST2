<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-22 09:06:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-22 09:12:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-22 09:12:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-22 09:12:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-22 09:12:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-22 09:12:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-22 09:12:05 --> 404 Page Not Found --> assets
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-08-22 09:13:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-08-22 09:13:06 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-08-22 09:13:07 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-22 10:42:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-22 10:44:08 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-22 10:44:08 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-22 10:44:08 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-22 10:44:08 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-22 11:09:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-22 11:09:28 --> 404 Page Not Found --> favicon.ico
