<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-17 19:45:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 19:45:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 20:31:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 20:31:46 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-08-17 20:31:46 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-08-17 21:20:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 21:57:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 22:05:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 22:05:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 22:27:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-08-17 22:27:44 --> 404 Page Not Found --> assets
ERROR - 2015-08-17 22:27:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-17 22:27:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:27:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:27:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:27:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-17 22:27:58 --> 404 Page Not Found --> assets
ERROR - 2015-08-17 22:28:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-17 22:28:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:28:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:28:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:28:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-17 22:28:40 --> 404 Page Not Found --> assets
ERROR - 2015-08-17 22:29:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-17 22:29:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:29:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:29:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-17 22:29:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-17 22:29:43 --> 404 Page Not Found --> assets
ERROR - 2015-08-17 22:33:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 22:40:52 --> 404 Page Not Found --> assets
ERROR - 2015-08-17 22:41:14 --> Severity: Notice  --> Undefined index: EMPLOYEE_EMAIL /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas075.php 211
ERROR - 2015-08-17 22:42:58 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-17 22:42:58 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-17 22:42:58 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-17 22:42:58 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-17 22:44:03 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-17 22:44:03 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-17 22:44:03 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-17 22:44:03 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-17 22:45:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-08-17 22:45:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-08-17 22:45:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-08-17 22:45:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-17 22:57:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 22:57:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-17 23:52:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-17 23:52:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 257
ERROR - 2015-08-17 23:52:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-17 23:52:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-08-17 23:58:03 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-08-17 23:58:03 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-08-17 23:58:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-08-17 23:58:04 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-17 23:58:57 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-08-17 23:58:57 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-08-17 23:58:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-08-17 23:58:58 --> 404 Page Not Found --> jquery.js
