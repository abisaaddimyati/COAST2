<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-09 19:28:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 19:28:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 19:31:36 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:31:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:31:45 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:31:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:32:19 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:32:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:32:31 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 19:32:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 20:32:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:32:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:32:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:33:50 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 21:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 21:34:01 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 21:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-09 21:34:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:37:19 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-07-09 21:39:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:39:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:40:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:49:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:50:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 21:56:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-07-09 21:56:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-07-09 21:56:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-07-09 21:56:09 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-07-09 21:56:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-07-09 21:56:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-07-09 21:56:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-09 21:56:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-09 21:56:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-09 21:56:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-09 21:56:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-09 21:57:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-09 22:13:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 22:13:29 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-09 22:13:29 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-09 22:24:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-09 22:24:28 --> 404 Page Not Found --> favicon.ico
