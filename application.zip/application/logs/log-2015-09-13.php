<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-13 04:46:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 04:47:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 19:47:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 19:47:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-09-13 19:47:52 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-09-13 20:21:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:13 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 20:59:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/core/Exceptions.php:185) /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 202
ERROR - 2015-09-13 20:59:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/core/Exceptions.php:185) /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 203
ERROR - 2015-09-13 20:59:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/core/Exceptions.php:185) /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 204
ERROR - 2015-09-13 21:01:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY pr.PR_ID desc' at line 49
ERROR - 2015-09-13 21:04:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 21:04:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 21:06:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 21:07:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 21:11:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 21:11:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 21:15:08 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-09-13 22:31:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 22:33:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 22:34:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 23:20:58 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-13 23:20:58 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-13 23:20:58 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-13 23:20:58 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-13 23:37:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 23:40:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-13 23:41:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY pr.PR_ID desc' at line 49
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:16 --> Severity: Notice  --> Undefined index: STATUS_KARYAWAN /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 140
ERROR - 2015-09-13 23:42:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/core/Exceptions.php:185) /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 202
ERROR - 2015-09-13 23:42:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/core/Exceptions.php:185) /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 203
ERROR - 2015-09-13 23:42:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/core/Exceptions.php:185) /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas005.php 204
