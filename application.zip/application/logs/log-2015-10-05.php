<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-05 00:15:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 00:28:24 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-05 00:28:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-05 00:43:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 00:43:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-05 00:43:53 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-05 00:43:55 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-05 00:43:55 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-05 00:45:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-10-05 00:45:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-10-05 00:59:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:04:20 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 01:04:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 01:04:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 01:04:20 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 01:04:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 01:04:20 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 01:23:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:25:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-05 01:25:52 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-05 01:30:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 01:30:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 01:30:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 01:30:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 01:30:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 01:30:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 01:30:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 01:31:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 01:31:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:31:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:32:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:32:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:36:46 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-10-05 01:36:46 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-10-05 01:36:46 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-10-05 01:36:46 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 01:39:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 01:39:33 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 01:39:33 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 01:39:33 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 01:39:33 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 01:39:33 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 01:39:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 01:41:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:41:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:46:40 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 01:46:40 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 01:46:40 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 01:46:40 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 01:46:40 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 01:46:40 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 01:46:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 01:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 01:48:51 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-05 01:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-05 01:48:51 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-05 01:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-05 01:50:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 01:50:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:10:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:10:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:14:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 02:14:55 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 02:14:55 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 02:14:55 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 02:14:55 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 02:14:55 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 02:15:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 02:16:32 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-10-05 02:16:32 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-10-05 02:16:32 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-10-05 02:16:33 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 02:19:46 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-10-05 02:19:46 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-10-05 02:19:46 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-10-05 02:19:47 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 02:20:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:20:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:24:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 02:24:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 02:24:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 02:24:42 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 02:24:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 02:24:42 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 02:25:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 02:30:08 --> Query error: Duplicate entry '2-62' for key 'PRIMARY'
ERROR - 2015-10-05 02:30:12 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-05 02:32:00 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:35:04 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:35:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:35:36 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 02:35:36 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 02:35:36 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 02:35:36 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 02:35:36 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 02:35:36 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 02:35:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 02:38:11 --> Query error: Duplicate entry '2-65' for key 'PRIMARY'
ERROR - 2015-10-05 02:38:21 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-05 02:39:44 --> Query error: Duplicate entry '2-65' for key 'PRIMARY'
ERROR - 2015-10-05 02:39:50 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-05 02:40:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:40:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 02:42:36 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:42:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:46:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 02:46:07 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 02:46:07 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 02:46:07 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 02:46:07 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 02:46:07 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 02:46:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 02:48:17 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-10-05 02:48:17 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-10-05 02:48:17 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-10-05 02:48:17 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 02:49:08 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:49:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:51:05 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 02:51:05 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 02:51:05 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 02:51:05 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 02:51:05 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 02:51:05 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 02:51:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 02:53:27 --> Query error: Duplicate entry '2-65' for key 'PRIMARY'
ERROR - 2015-10-05 02:53:32 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-05 02:53:59 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-10-05 02:53:59 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-10-05 02:53:59 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-10-05 02:53:59 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 02:55:24 --> Query error: Duplicate entry '2-68' for key 'PRIMARY'
ERROR - 2015-10-05 02:55:33 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-05 02:59:29 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:59:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:59:38 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:59:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:59:59 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 02:59:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 03:02:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 03:02:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 03:02:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 03:02:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 03:02:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 03:02:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 03:02:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 03:04:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 03:04:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 03:04:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 03:04:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 03:04:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 03:04:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 03:04:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-05 03:05:55 --> Query error: Duplicate entry '2-72' for key 'PRIMARY'
ERROR - 2015-10-05 03:05:58 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-05 03:08:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:08:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 03:08:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:08:35 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:09:03 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 03:12:16 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 03:12:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 03:15:24 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 03:15:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-10-05 03:18:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 03:24:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:24:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 03:24:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:24:27 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:24:41 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:31:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-10-05 03:31:11 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 420
ERROR - 2015-10-05 03:31:12 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:31:12 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-05 03:31:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-05 03:31:12 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-05 03:31:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-05 03:31:26 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-05 03:31:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-05 03:31:26 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-05 03:31:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:32:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-10-05 03:32:55 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 420
ERROR - 2015-10-05 03:32:56 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:33:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:34:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-10-05 03:34:04 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 420
ERROR - 2015-10-05 03:34:05 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:34:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-10-05 03:34:41 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 420
ERROR - 2015-10-05 03:34:41 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:34:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 03:34:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:34:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:34:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:34:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 03:34:44 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 03:35:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 03:35:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:35:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:35:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:35:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 03:35:16 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 03:36:14 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:36:14 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 03:36:14 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:36:15 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:36:28 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 03:40:15 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 03:44:36 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-10-05 03:44:36 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-10-05 03:44:36 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-10-05 03:44:36 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-10-05 03:44:36 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-10-05 03:44:36 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-10-05 03:45:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 463
ERROR - 2015-10-05 03:45:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 467
ERROR - 2015-10-05 03:45:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-10-05 03:45:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:46:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-10-05 03:46:03 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 420
ERROR - 2015-10-05 03:46:04 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 03:51:14 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 03:54:05 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 03:54:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 03:54:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:54:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:54:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 03:54:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 03:54:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 04:35:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-10-05 04:35:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-10-05 04:36:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-10-05 04:36:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-10-05 10:03:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 19:44:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 19:44:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 20:10:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:10:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:10:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:10:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:10:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:10:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:11:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:11:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:11:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:11:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:11:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:11:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:15:44 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:16:01 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-05 20:16:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-05 20:16:01 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-05 20:16:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-05 20:20:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 20:20:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 20:23:15 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:28:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 20:28:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 20:32:14 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:32:14 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:32:14 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:32:14 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:32:14 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:32:15 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 20:33:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-10-05 20:33:16 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 420
ERROR - 2015-10-05 20:33:19 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 20:36:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:36:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:36:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:36:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:36:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:36:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:37:58 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:38:17 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:38:17 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:38:17 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:38:17 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:38:17 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:38:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:39:17 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:17 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:18 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:39:23 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:23 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:39 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:39 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:46 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:46 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:57 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:39:57 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:39:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:40:48 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:40:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-05 20:40:48 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:40:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-05 20:41:08 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:41:46 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:42:52 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:45:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:45:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:45:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:45:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:45:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:45:13 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:46:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:46:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:46:10 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:46:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:46:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:46:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:46:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:46:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:46:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:46:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:47:32 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:47:32 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:48:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-05 20:48:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-05 20:48:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-05 20:48:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-05 20:48:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-05 20:48:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-05 20:48:21 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:48:21 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:48:27 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:48:27 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:50:05 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:50:05 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:51:31 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:51:31 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:51:58 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:51:58 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:13 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:52:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:52:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:52:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:52:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:52:23 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:52:27 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:27 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:29 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:29 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:53 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:53 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:55 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:55 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:56 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:56 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:57 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:57 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:52:59 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:52:59 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:53:00 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:53:00 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:53:01 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:53:01 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 20:53:04 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:53:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:53:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:53:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:53:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:53:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:53:31 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:54:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:54:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:54:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:54:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:54:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:54:58 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:55:18 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:55:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:55:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:55:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:55:18 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:55:18 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:56:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:56:49 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:56:49 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:56:49 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:56:49 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:56:49 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:56:50 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:56:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:56:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:56:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:56:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:56:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:56:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:58:27 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 20:58:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 20:58:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:58:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:58:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 20:58:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 20:58:43 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 20:59:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:04:11 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:04:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 21:08:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:08:37 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:09:58 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:10:48 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:12:12 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:13:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:13:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:13:06 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:13:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:13:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:13:10 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:13:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:13:33 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:33 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:33 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:13:34 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:13:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:13:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:13:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:13:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:14:40 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:14:47 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:15:09 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:15:45 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:15:45 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:15:56 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:15:56 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:16 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:16 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:19 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:19 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:39 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:39 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:42 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:42 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:45 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:48 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:48 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:48 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:49 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:49 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:50 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:16:50 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:16:50 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:16:50 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:16:50 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:16:50 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:16:50 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:50 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:16:51 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:16:51 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:17:09 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:17:09 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:17:09 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:17:09 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:17:09 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:17:10 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:17:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:17:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:17:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:17:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:17:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:17:30 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:18:36 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:18:36 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:18:52 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:18:52 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:10 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:10 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:15 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:15 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:45 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:45 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:49 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:51 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:51 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:52 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:52 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:19:53 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:19:53 --> Query error: Duplicate entry '4-83' for key 'PRIMARY'
ERROR - 2015-10-05 21:20:42 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:21:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 21:22:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:22:35 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:22:35 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:22:35 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:22:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:22:36 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:23:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:23:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:23:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:23:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:23:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:23:04 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:24:33 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:24:33 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:24:41 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:24:41 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:24:44 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:24:44 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:24:46 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:24:46 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:24:46 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:24:46 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:24:59 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:24:59 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:25:02 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:25:02 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:25:31 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:25:32 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:25:33 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:25:33 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:25:34 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:25:34 --> Query error: Duplicate entry '4-78' for key 'PRIMARY'
ERROR - 2015-10-05 21:26:14 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:26:14 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:26:14 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:26:14 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:26:14 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:26:15 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:26:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:26:35 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:26:35 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:26:35 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:26:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:26:35 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:26:35 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:27:41 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:27:47 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:27:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:27:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:27:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:27:47 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:27:47 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:28:20 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:29:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:29:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:29:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:29:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:29:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:29:04 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:29:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:29:56 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:29:56 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:29:56 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:29:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:29:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:30:41 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:30:41 --> Query error: Duplicate entry '4-92' for key 'PRIMARY'
ERROR - 2015-10-05 21:31:10 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:31:10 --> Query error: Duplicate entry '4-92' for key 'PRIMARY'
ERROR - 2015-10-05 21:31:10 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:31:10 --> Query error: Duplicate entry '4-92' for key 'PRIMARY'
ERROR - 2015-10-05 21:31:11 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:31:11 --> Query error: Duplicate entry '4-92' for key 'PRIMARY'
ERROR - 2015-10-05 21:31:30 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:31:55 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:31:59 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:32:03 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:32:25 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:32:56 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:33:02 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:33:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:34:57 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-05 21:34:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-05 21:34:57 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-05 21:34:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-05 21:36:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:36:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:36:08 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:36:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:36:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:36:31 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:36:35 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:36:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:36:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:36:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:36:39 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:37:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:37:31 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:37:31 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:37:31 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:37:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:37:32 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:38:07 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:38:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:38:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:38:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:38:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:38:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:38:13 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:38:53 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:38:53 --> Query error: Duplicate entry '4-92' for key 'PRIMARY'
ERROR - 2015-10-05 21:39:10 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:39:10 --> Query error: Duplicate entry '4-92' for key 'PRIMARY'
ERROR - 2015-10-05 21:39:24 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:39:44 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:40:40 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:40:41 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:42:24 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:42:46 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:43:19 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:45:00 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:45:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:46:18 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:48:20 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:49:24 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:55:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:55:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:55:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:55:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:55:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:55:08 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:55:47 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:55:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:55:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:55:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:55:47 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:55:48 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 21:56:41 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 21:56:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 21:56:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:56:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:56:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 21:56:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 21:56:47 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:01:46 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:02:33 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:04:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:04:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:04:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:04:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:04:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:04:05 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:04:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:04:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:04:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:04:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:04:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:04:56 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:05:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:05:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:05:56 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:06:32 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:07:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 22:07:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 22:07:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 22:07:08 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 22:07:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:09:16 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 22:11:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:11:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:12:32 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 22:12:32 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 22:12:32 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 22:12:43 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 22:13:39 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 22:13:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 22:13:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 22:13:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 22:13:44 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 22:15:15 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 22:15:35 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:16:09 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:16:41 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:17:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:17:19 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:17:19 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:17:19 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:17:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:17:19 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:18:54 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:19:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:19:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:19:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:19:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:19:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:19:12 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:21:06 --> 404 Page Not Found --> intranet.cybertrend-intra.comc_oas045
ERROR - 2015-10-05 22:21:18 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:21:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:21:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:21:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:21:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:21:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:21:24 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:21:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:21:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:21:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:21:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:21:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:21:38 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:21:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 22:21:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 22:21:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 22:21:45 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 22:21:49 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:22:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:22:01 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:22:01 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:22:01 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:22:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:22:02 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:22:22 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 22:22:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:22:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:22:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:22:30 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:22:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:22:30 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:23:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:23:44 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:23:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:23:56 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:23:56 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:23:56 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:23:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:23:56 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:24:20 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:24:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:24:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:25:02 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:26:02 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:26:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:26:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:26:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:26:02 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:26:02 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:27:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:27:36 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:27:36 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:27:36 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:27:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:27:41 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:27:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:29:10 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:29:10 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:29:40 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:29:40 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:30:44 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:30:44 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:31:29 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:31:29 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:31:38 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:31:38 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:31:38 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:31:38 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:31:39 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:31:39 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:31:40 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:31:40 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:32:11 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:32:11 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:32:25 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:32:25 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:32:54 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:32:54 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:32:54 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:32:54 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:32:54 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:32:55 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:33:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:33:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:33:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:33:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:33:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:33:12 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:36:14 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-10-05 22:37:26 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:38:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 22:38:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:38:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:38:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 22:38:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 22:38:24 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:38:37 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 22:41:37 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:41:37 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:42:27 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:42:27 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:42:43 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 22:42:43 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 22:44:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:45:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 22:45:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-05 23:00:33 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-05 23:00:40 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-05 23:01:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-05 23:01:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-05 23:01:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-05 23:01:12 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-05 23:01:46 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-05 23:52:29 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:29 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:36 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:36 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:43 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:43 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:43 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:43 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:44 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:44 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:45 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:45 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:46 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:46 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:46 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:46 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:47 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:47 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:47 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:47 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:48 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:48 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:49 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:49 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:52:50 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:52:50 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:53:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 23:53:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:53:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:53:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:53:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 23:53:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 23:53:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 23:53:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:53:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:53:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:53:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 23:53:42 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 23:54:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 23:54:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:54:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:54:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:54:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 23:54:06 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 23:55:17 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:55:17 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:55:27 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:55:27 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:55:41 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:55:41 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:56:32 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-05 23:56:32 --> Query error: Duplicate entry '4-101' for key 'PRIMARY'
ERROR - 2015-10-05 23:57:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 23:57:31 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:57:31 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:57:31 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:57:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 23:57:31 --> 404 Page Not Found --> assets
ERROR - 2015-10-05 23:59:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-05 23:59:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:59:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:59:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-05 23:59:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-05 23:59:13 --> 404 Page Not Found --> assets
