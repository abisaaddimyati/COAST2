<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-15 00:35:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-15 01:52:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-15 01:54:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-15 01:54:14 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-06-15 08:30:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-15 23:02:40 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-15 23:02:40 --> 404 Page Not Found --> robots.txt
