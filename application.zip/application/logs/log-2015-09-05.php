<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-05 03:06:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-05 03:06:22 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-09-05 03:06:22 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-09-05 23:19:15 --> 404 Page Not Found --> favicon.ico
