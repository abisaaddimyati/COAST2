<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-14 00:36:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-14 00:36:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-14 21:52:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-14 21:52:03 --> 404 Page Not Found --> favicon.ico
