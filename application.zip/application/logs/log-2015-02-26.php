<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-26 17:11:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-26 22:50:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-26 23:08:59 --> Query error: Duplicate entry '1-33' for key 'PRIMARY'
