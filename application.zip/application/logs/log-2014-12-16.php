<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-16 00:38:22 --> Query error: Unknown column 'bt.STATUS' in 'field list'
ERROR - 2014-12-16 00:40:43 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-16 00:40:43 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-16 00:40:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2014-12-16 18:52:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 19:08:39 --> Query error: Unknown column 'bt.STATUS' in 'field list'
ERROR - 2014-12-16 19:08:52 --> Query error: Unknown column 'bt.STATUS' in 'field list'
ERROR - 2014-12-16 19:12:19 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-12-16 19:12:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-12-16 19:12:19 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-12-16 19:12:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-12-16 19:13:30 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 105
ERROR - 2014-12-16 19:13:30 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 115
ERROR - 2014-12-16 19:13:31 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-16 19:15:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 19:15:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 19:15:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 19:38:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 19:38:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 20:04:51 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 105
ERROR - 2014-12-16 20:04:51 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 115
ERROR - 2014-12-16 20:04:52 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-16 22:03:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 22:03:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 22:15:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 22:25:11 --> Severity: Notice  --> Undefined variable: destination_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas063.php 57
ERROR - 2014-12-16 22:25:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas063.php 57
ERROR - 2014-12-16 22:28:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 22:28:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-16 22:32:05 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-16 22:32:53 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-16 22:50:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
