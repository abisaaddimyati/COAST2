<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-16 21:46:42 --> 404 Page Not Found --> favicon.ico
