<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-22 00:18:39 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-22 00:18:39 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-22 00:18:39 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-22 00:18:39 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-22 00:18:39 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-22 00:18:39 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-22 00:44:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 00:44:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 00:46:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-22 00:46:26 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-22 00:46:26 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-22 00:46:26 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-22 00:46:26 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-22 00:46:26 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-22 00:46:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-22 00:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-22 00:46:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 00:46:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 03:09:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 03:26:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 03:26:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 03:50:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 03:50:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 03:51:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 03:51:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:51:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:51:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:51:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 03:51:53 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 03:53:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 03:53:11 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:53:11 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:53:11 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:53:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 03:53:12 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 03:54:09 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 03:54:09 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:54:09 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:54:09 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:54:09 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 03:54:09 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 03:57:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 03:57:44 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:57:44 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:57:44 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:57:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 03:57:44 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 03:59:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 03:59:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:59:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:59:12 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 03:59:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 03:59:13 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 04:01:34 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 04:01:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 04:01:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 04:01:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 04:01:57 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 04:01:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 04:01:57 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 06:23:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 06:23:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 12:29:01 --> 404 Page Not Found --> asset
ERROR - 2015-09-22 12:29:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 12:29:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 17:18:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 17:24:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 17:24:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 17:41:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-22 17:41:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-22 17:41:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-22 17:41:28 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-22 18:17:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 20:46:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:00:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:07:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:07:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:08:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:08:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:08:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:08:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:08:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:08:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:08:37 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:08:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:08:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:08:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:08:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:08:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:08:56 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:09:18 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:09:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:09:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:09:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:09:18 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:09:19 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:16:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:16:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:16:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:16:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:16:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:16:47 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:17:37 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-22 21:17:37 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-22 21:17:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-22 21:17:37 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-22 21:18:08 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-09-22 21:18:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-09-22 21:18:08 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-09-22 21:18:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-09-22 21:18:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:18:21 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-09-22 21:18:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-09-22 21:18:21 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-09-22 21:18:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-09-22 21:18:47 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-22 21:18:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-22 21:18:47 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-22 21:18:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-22 21:18:59 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-22 21:18:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-22 21:18:59 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-22 21:18:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-22 21:19:13 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-09-22 21:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-09-22 21:19:13 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-09-22 21:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-09-22 21:20:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:20:01 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:20:01 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:20:01 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:20:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:20:02 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:20:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:20:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:20:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:20:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:20:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:20:18 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:21:02 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-22 21:21:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:21:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:21:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:21:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:21:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:21:10 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:22:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:22:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:22:47 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:28:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:28:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:29:57 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:30:43 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:32:22 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:32:46 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:33:20 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:35:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:35:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:35:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:35:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:35:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:35:16 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:37:02 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:37:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:37:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:37:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:37:02 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:37:04 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:37:17 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:37:17 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:37:17 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:37:17 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:37:17 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:37:17 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:41:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:41:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:41:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:41:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:41:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:41:55 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:43:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:43:02 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:45:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:45:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 21:49:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:49:25 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:49:25 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:49:25 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:49:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:49:29 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 21:56:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 21:56:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:56:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:56:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 21:56:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 21:56:46 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:00:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:00:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:00:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:00:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:00:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:00:46 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:01:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:01:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:01:40 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:01:40 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:01:40 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:01:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:01:41 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:02:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:15:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:15:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:30:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:30:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:30:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:30:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:30:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:30:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:30:24 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:30:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:30:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:30:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:30:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:30:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:30:43 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:32:59 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:32:59 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:32:59 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:32:59 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:32:59 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:32:59 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:33:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:33:25 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:25 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:25 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:33:26 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:33:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:33:38 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:38 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:38 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:33:38 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:33:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-22 22:33:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-22 22:33:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-22 22:33:46 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 22:34:47 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-22 22:56:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:58:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 22:59:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 23:22:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 23:50:15 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 23:51:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 23:51:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-22 23:57:26 --> 404 Page Not Found --> assets
ERROR - 2015-09-22 23:57:53 --> 404 Page Not Found --> assets
