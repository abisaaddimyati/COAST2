<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-05 20:16:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-05 20:16:47 --> 404 Page Not Found --> favicon.ico
