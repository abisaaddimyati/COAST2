<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-31 01:33:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-31 09:31:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-31 19:46:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-31 19:46:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-31 19:55:24 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-07-31 19:55:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-07-31 19:55:24 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-07-31 19:55:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-07-31 23:45:47 --> 404 Page Not Found --> favicon.ico
