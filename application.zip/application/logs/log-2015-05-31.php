<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-31 12:47:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-31 19:54:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-31 21:26:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-31 21:31:39 --> 404 Page Not Found --> favicon.ico
