<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-04 19:59:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 19:59:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 20:38:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 20:38:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 22:48:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 22:53:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 22:53:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-04 23:24:18 --> 404 Page Not Found --> favicon.ico
