<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-19 00:29:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-19 00:29:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-19 00:29:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-19 00:29:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-19 00:29:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-19 00:29:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-19 00:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-19 00:54:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 00:54:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 00:57:56 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 00:57:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 00:57:56 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 00:57:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 00:58:27 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 00:58:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 00:58:27 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 00:58:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 00:58:45 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 00:58:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 00:58:45 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 00:58:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:01:06 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:01:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:01:06 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:01:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:36:49 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:36:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:36:49 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:36:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:37:17 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:37:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:37:17 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:37:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:37:30 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:37:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-19 01:37:30 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:37:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-19 01:37:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 01:44:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 01:44:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 01:58:49 --> Severity: Warning  --> Missing argument 2 for C_OAS041::load_form() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas041.php 45
ERROR - 2015-10-19 01:58:49 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas041.php 48
ERROR - 2015-10-19 04:14:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 04:14:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 06:02:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 08:01:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 09:56:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 11:50:28 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-19 11:50:28 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-19 11:50:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-19 11:50:29 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-19 15:12:41 --> 404 Page Not Found --> robots.txt
ERROR - 2015-10-19 18:27:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 19:48:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 19:48:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 20:21:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-19 20:21:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-19 20:21:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-19 20:21:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-19 20:21:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-19 20:21:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-19 20:22:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-19 20:27:14 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-19 20:27:14 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-19 20:27:15 --> 404 Page Not Found --> assets
ERROR - 2015-10-19 20:28:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-19 20:28:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-19 20:28:12 --> 404 Page Not Found --> assets
ERROR - 2015-10-19 20:28:39 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 296
ERROR - 2015-10-19 20:28:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-19 20:28:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-19 20:28:46 --> 404 Page Not Found --> assets
ERROR - 2015-10-19 21:07:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:07:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:08:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:08:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:08:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:09:13 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 21:09:22 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-19 21:09:22 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-19 21:09:22 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-19 21:09:22 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-19 21:09:22 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-19 21:09:22 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-19 21:09:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-19 21:09:28 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 21:09:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-19 21:09:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-19 21:09:50 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 21:13:36 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 21:17:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-10-19 21:17:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-10-19 21:17:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-10-19 21:17:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-10-19 21:17:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-10-19 21:17:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-10-19 21:24:11 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 21:25:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:25:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 21:25:28 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 22:12:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-19 22:15:46 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 22:17:23 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 22:22:20 --> Query error: Unknown column 'fs.REVISE_APPROVEPUR_BY' in 'field list'
ERROR - 2015-10-19 22:25:57 --> 404 Page Not Found --> assets
