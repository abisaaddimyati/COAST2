<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-21 05:04:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-21 17:45:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-21 18:27:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-21 20:48:24 --> 404 Page Not Found --> favicon.ico
