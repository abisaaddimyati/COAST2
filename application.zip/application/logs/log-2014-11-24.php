<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-24 06:23:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-24 06:23:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-24 06:29:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas046.php 153
ERROR - 2014-11-24 09:06:35 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 98
ERROR - 2014-11-24 09:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 158
ERROR - 2014-11-24 09:06:37 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-24 09:32:24 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 98
ERROR - 2014-11-24 09:32:25 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-24 10:21:36 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas046.php 192
ERROR - 2014-11-24 10:21:36 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:21:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:21:36 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:21:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:21:36 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 209
ERROR - 2014-11-24 10:21:36 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 212
ERROR - 2014-11-24 10:21:36 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 216
ERROR - 2014-11-24 10:22:44 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas046.php 192
ERROR - 2014-11-24 10:22:44 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:22:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:22:44 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:22:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:22:44 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 209
ERROR - 2014-11-24 10:22:44 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 212
ERROR - 2014-11-24 10:22:44 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 216
ERROR - 2014-11-24 10:23:58 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas046.php 192
ERROR - 2014-11-24 10:23:58 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:23:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:23:58 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:23:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:23:58 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 209
ERROR - 2014-11-24 10:23:58 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 212
ERROR - 2014-11-24 10:23:58 --> Severity: Notice  --> Undefined index: RCA_currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 216
ERROR - 2014-11-24 10:25:35 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:25:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 103
ERROR - 2014-11-24 10:25:35 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 10:25:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 154
ERROR - 2014-11-24 12:00:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-24 19:50:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-24 19:50:28 --> 404 Page Not Found --> favicon.ico
