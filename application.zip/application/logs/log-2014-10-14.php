<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-14 01:04:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-14 01:04:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-14 01:06:08 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-10-14 01:06:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
