<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-27 19:02:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-27 21:40:16 --> 404 Page Not Found --> favicon.ico
