<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-22 00:33:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-22 19:33:20 --> 404 Page Not Found --> favicon.ico
