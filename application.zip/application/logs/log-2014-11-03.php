<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-03 01:01:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-03 01:01:15 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-11-03 01:01:16 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2014-11-03 01:08:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-03 01:08:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-03 01:08:28 --> 404 Page Not Found --> favicon.ico
