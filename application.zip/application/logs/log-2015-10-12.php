<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-12 00:05:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 00:05:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 00:39:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 00:40:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-12 00:40:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-12 00:40:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-12 00:40:29 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-12 01:28:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 01:30:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 01:30:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 01:37:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-12 01:37:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-12 01:37:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-12 01:37:35 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-12 01:43:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 01:43:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 02:17:11 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 106
ERROR - 2015-10-12 02:17:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 106
ERROR - 2015-10-12 02:17:11 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 157
ERROR - 2015-10-12 02:17:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 157
ERROR - 2015-10-12 02:21:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 03:56:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 04:51:09 --> 404 Page Not Found --> robots.txt
ERROR - 2015-10-12 05:10:43 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-12 06:54:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 06:54:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 07:39:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 19:51:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 19:51:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 20:00:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-12 20:00:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:00:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:00:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:00:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-12 20:00:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-12 20:01:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-12 20:01:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:01:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:01:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:01:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-12 20:01:04 --> 404 Page Not Found --> assets
ERROR - 2015-10-12 20:03:40 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-10-12 20:03:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-12 20:03:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:03:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:03:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-12 20:03:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-12 20:03:47 --> 404 Page Not Found --> assets
ERROR - 2015-10-12 20:40:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 20:40:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 20:45:05 --> 404 Page Not Found --> assets
ERROR - 2015-10-12 20:45:52 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-12 20:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-12 20:45:52 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-12 20:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-12 20:47:54 --> 404 Page Not Found --> assets
ERROR - 2015-10-12 20:58:49 --> Query error: Duplicate entry '2-98' for key 'PRIMARY'
ERROR - 2015-10-12 20:58:54 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-10-12 21:06:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 21:52:37 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-12 21:52:37 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-12 21:52:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-12 21:52:37 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-12 22:01:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 22:12:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 22:15:15 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-12 22:15:15 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-12 22:15:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-12 22:15:15 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-12 22:22:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 22:22:39 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-12 22:22:39 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-12 22:22:39 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-12 22:22:39 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-12 22:22:39 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-12 22:22:39 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-12 22:24:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-12 22:24:48 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-12 22:24:48 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-12 22:24:48 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-12 22:24:48 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-12 22:24:48 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-12 22:46:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 22:46:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 23:14:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 23:15:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 23:42:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-12 23:42:29 --> 404 Page Not Found --> favicon.ico
