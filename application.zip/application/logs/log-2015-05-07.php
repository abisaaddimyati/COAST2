<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-07 00:07:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-07 08:59:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-07 08:59:13 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-07 08:59:13 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-07 19:51:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-07 19:51:34 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-07 19:51:35 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-07 20:36:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-07 20:36:35 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-07 20:36:36 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-07 21:54:27 --> 404 Page Not Found --> favicon.ico
