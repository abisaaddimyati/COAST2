<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-10 00:46:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-10 02:46:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-10 02:46:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-10 04:32:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-10 04:32:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-10 04:32:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-08-10 04:32:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-08-10 04:32:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-08-10 04:32:38 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-10 04:32:58 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-08-10 12:51:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-10 20:25:12 --> 404 Page Not Found --> favicon.ico
