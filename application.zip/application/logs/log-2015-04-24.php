<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-24 00:08:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-24 06:49:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-24 06:49:47 --> 404 Page Not Found --> favicon.ico
