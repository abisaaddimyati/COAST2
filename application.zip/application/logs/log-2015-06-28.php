<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-28 14:43:50 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-28 21:21:58 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas029.php 172
ERROR - 2015-06-28 21:21:58 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-06-28 21:21:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-06-28 21:21:58 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 151
ERROR - 2015-06-28 21:21:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 151
ERROR - 2015-06-28 22:12:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-28 22:12:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-28 23:24:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-28 23:24:46 --> 404 Page Not Found --> favicon.ico
