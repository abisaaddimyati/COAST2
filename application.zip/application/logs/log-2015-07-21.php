<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-21 21:02:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-21 21:02:08 --> 404 Page Not Found --> favicon.ico
