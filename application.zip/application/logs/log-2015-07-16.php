<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-16 03:50:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-16 03:50:33 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
