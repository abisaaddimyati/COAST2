<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-23 02:00:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-23 02:01:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas015.php 165
ERROR - 2014-09-23 02:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas015.php 165
ERROR - 2014-09-23 02:02:33 --> 404 Page Not Found --> assets
ERROR - 2014-09-23 02:03:13 --> 404 Page Not Found --> assets
ERROR - 2014-09-23 02:05:08 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-23 02:05:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-23 21:50:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-23 21:50:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-23 21:50:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-23 21:56:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-23 21:59:15 --> 404 Page Not Found --> assets
