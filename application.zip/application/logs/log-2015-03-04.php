<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-04 00:10:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 02:59:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 02:59:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 07:28:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 20:02:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 20:02:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 20:23:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 20:23:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 21:42:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 23:23:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 23:23:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 23:24:55 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-03-04 23:24:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 23:24:55 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-03-04 23:25:50 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-03-04 23:25:50 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-03-04 23:30:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 23:30:04 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-03-04 23:30:04 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-03-04 23:31:58 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-03-04 23:32:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-04 23:32:30 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
