<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-25 01:19:56 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2014-12-25 01:23:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-25 01:23:33 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-25 01:23:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2014-12-25 01:23:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2014-12-25 01:25:45 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2014-12-25 01:53:24 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2014-12-25 01:53:25 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter
ERROR - 2014-12-25 01:53:25 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min1
ERROR - 2014-12-25 01:53:25 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min2
ERROR - 2014-12-25 01:53:26 --> 404 Page Not Found --> c_oas042/feed_claim_transport_left_counter
ERROR - 2014-12-25 01:53:26 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin1_left_counter
ERROR - 2014-12-25 01:53:26 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin2_left_counter
ERROR - 2014-12-25 01:53:27 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasi_left_counter
ERROR - 2014-12-25 01:53:27 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin1_left_counter
ERROR - 2014-12-25 01:53:28 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin2_left_counter
ERROR - 2014-12-25 01:53:33 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2014-12-25 01:53:34 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter
ERROR - 2014-12-25 01:53:34 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min1
ERROR - 2014-12-25 01:53:34 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min2
ERROR - 2014-12-25 01:53:35 --> 404 Page Not Found --> c_oas042/feed_claim_transport_left_counter
ERROR - 2014-12-25 01:53:36 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin1_left_counter
ERROR - 2014-12-25 01:53:37 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin2_left_counter
ERROR - 2014-12-25 01:53:37 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasi_left_counter
ERROR - 2014-12-25 01:53:37 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin1_left_counter
ERROR - 2014-12-25 01:53:38 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin2_left_counter
ERROR - 2014-12-25 01:53:43 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2014-12-25 01:53:43 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter
ERROR - 2014-12-25 01:53:44 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min1
ERROR - 2014-12-25 01:53:44 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min2
ERROR - 2014-12-25 01:53:45 --> 404 Page Not Found --> c_oas042/feed_claim_transport_left_counter
ERROR - 2014-12-25 01:53:45 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin1_left_counter
ERROR - 2014-12-25 01:53:45 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin2_left_counter
ERROR - 2014-12-25 01:53:46 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasi_left_counter
ERROR - 2014-12-25 01:53:46 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin1_left_counter
ERROR - 2014-12-25 01:53:47 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin2_left_counter
ERROR - 2014-12-25 01:53:52 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2014-12-25 01:53:53 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter
ERROR - 2014-12-25 01:53:53 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min1
ERROR - 2014-12-25 01:53:53 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min2
ERROR - 2014-12-25 01:53:54 --> 404 Page Not Found --> c_oas042/feed_claim_transport_left_counter
ERROR - 2014-12-25 01:53:54 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin1_left_counter
ERROR - 2014-12-25 01:53:54 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin2_left_counter
ERROR - 2014-12-25 01:53:55 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasi_left_counter
ERROR - 2014-12-25 01:53:55 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin1_left_counter
ERROR - 2014-12-25 01:53:56 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin2_left_counter
