<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-22 01:21:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 01:21:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 02:23:29 --> 404 Page Not Found --> apple-touch-icon-76x76-precomposed.png
ERROR - 2015-07-22 02:23:29 --> 404 Page Not Found --> apple-touch-icon-76x76.png
ERROR - 2015-07-22 02:23:30 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-22 02:23:30 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-22 02:23:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 02:23:31 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-22 02:23:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 19:55:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 19:56:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 19:57:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-22 19:57:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-22 19:57:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-22 19:57:57 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-22 20:00:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 20:14:58 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-22 20:14:58 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-22 20:47:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-22 23:19:09 --> 404 Page Not Found --> favicon.ico
