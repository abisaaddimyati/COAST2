<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-18 00:12:59 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-18 00:12:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-18 00:12:59 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-18 00:12:59 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-18 00:12:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-18 00:12:59 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-18 01:04:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-18 01:11:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-18 01:11:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-18 01:14:38 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
