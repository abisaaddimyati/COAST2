<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-13 00:32:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-13 00:33:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-13 01:04:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-13 02:48:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-13 03:02:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-13 03:03:26 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-05-13 06:36:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-13 06:36:10 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-13 06:36:11 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-13 12:49:38 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-13 12:49:38 --> 404 Page Not Found --> mobile
ERROR - 2015-05-13 12:52:29 --> 404 Page Not Found --> m
