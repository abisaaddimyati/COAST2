<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-10 21:58:23 --> 404 Page Not Found --> Login
ERROR - 2014-09-10 21:58:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-10 21:58:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-10 21:58:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-10 21:58:27 --> 404 Page Not Found --> Login
ERROR - 2014-09-10 21:58:30 --> 404 Page Not Found --> Login
