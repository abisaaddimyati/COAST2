<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-19 00:54:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-19 00:54:12 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-12-19 00:54:12 --> 404 Page Not Found --> apple-touch-icon.png
