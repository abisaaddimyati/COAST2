<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-24 03:03:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-24 07:59:29 --> 404 Page Not Found --> robots.txt
ERROR - 2015-10-24 20:49:49 --> 404 Page Not Found --> robots.txt
ERROR - 2015-10-24 22:31:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-24 22:31:08 --> 404 Page Not Found --> favicon.ico
