<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-30 05:15:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-30 05:15:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-30 05:16:21 --> 404 Page Not Found --> favicon.ico
