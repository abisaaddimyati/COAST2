<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-06 08:50:03 --> 404 Page Not Found --> robots.txt
