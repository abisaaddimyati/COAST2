<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-24 01:08:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 01:08:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 02:14:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 02:30:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 02:44:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 03:13:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 03:13:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 07:07:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 07:15:14 --> 404 Page Not Found --> c_oas075
ERROR - 2015-03-24 07:32:52 --> 404 Page Not Found --> img
ERROR - 2015-03-24 17:10:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 17:10:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-24 18:15:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'raj Nabi Muhammad SAW' )' at line 10
ERROR - 2015-03-24 18:15:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'raj Nabi Muhammad SAW' )' at line 10
ERROR - 2015-03-24 18:16:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'raj Nabi Muhammad SAW' )' at line 10
