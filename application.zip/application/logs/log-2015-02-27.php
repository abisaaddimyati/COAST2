<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-27 04:41:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-27 04:42:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-27 04:42:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-27 04:42:31 --> 404 Page Not Found --> favicon.ico
