<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-19 02:34:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-19 21:01:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-19 21:09:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-19 21:09:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-19 21:10:00 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-05-19 21:10:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-05-19 21:20:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-19 21:28:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-19 23:45:37 --> 404 Page Not Found --> favicon.ico
