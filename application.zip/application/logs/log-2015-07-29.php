<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-29 01:14:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:18:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:19:56 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-29 01:20:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:20:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:21:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-29 01:21:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-29 01:21:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-29 01:21:27 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-29 01:21:36 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-29 01:23:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:23:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:46:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 01:46:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 18:46:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 20:13:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 20:13:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 20:34:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 21:14:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-29 21:23:12 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
