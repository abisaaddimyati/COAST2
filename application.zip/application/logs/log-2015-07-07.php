<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-07 14:06:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 14:06:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 21:05:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 21:06:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-07 21:06:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-07 21:06:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-07 21:06:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-07 22:43:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 22:44:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 22:44:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 22:47:45 --> Severity: Notice  --> Undefined index: remarks_finance /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas041.php 187
ERROR - 2015-07-07 22:50:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-07-07 22:50:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-07-07 22:51:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-07-07 22:51:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-07-07 23:16:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-07-07 23:16:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-07-07 23:52:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-07 23:52:52 --> 404 Page Not Found --> favicon.ico
