<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-19 00:05:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-19 21:36:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-19 21:36:43 --> 404 Page Not Found --> favicon.ico
