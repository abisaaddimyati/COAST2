<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-22 07:43:51 --> 404 Page Not Found --> favicon.ico
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-22 07:43:51 --> 404 Page Not Found --> nldjz
