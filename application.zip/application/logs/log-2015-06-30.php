<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-30 01:07:41 --> 404 Page Not Found --> favicon.ico
