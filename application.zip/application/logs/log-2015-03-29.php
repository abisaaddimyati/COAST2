<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-29 17:58:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 18:01:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-29 18:06:07 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-29 18:06:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-29 18:06:34 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-29 18:06:34 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-29 18:06:34 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-29 18:06:34 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-29 18:06:34 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-29 18:06:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-29 18:06:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-29 18:06:42 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-29 18:06:42 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-29 18:06:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-29 18:06:42 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-29 21:33:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 21:33:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 21:35:49 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-29 21:35:49 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-29 21:35:49 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-29 21:35:49 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-29 21:35:49 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-29 21:35:49 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-29 21:35:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-29 21:35:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-29 21:35:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-29 21:35:54 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-29 21:35:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-29 21:35:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-29 22:11:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 22:11:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 22:13:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 22:13:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 22:17:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-29 22:41:10 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2015-03-29 22:51:42 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2015-03-29 22:53:30 --> Query error: Duplicate entry 'tes' for key 'PRIMARY'
ERROR - 2015-03-29 22:56:54 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2015-03-29 23:00:43 --> Query error: Duplicate entry 'tes' for key 'PRIMARY'
ERROR - 2015-03-29 23:10:26 --> Query error: Duplicate entry 'tes-2015' for key 'PRIMARY'
ERROR - 2015-03-29 23:18:18 --> Query error: Duplicate entry 'tes-2015' for key 'PRIMARY'
ERROR - 2015-03-29 23:23:56 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2015-03-29 23:25:10 --> Query error: Duplicate entry '12345-2015' for key 'PRIMARY'
ERROR - 2015-03-29 23:25:15 --> Query error: Duplicate entry '12345' for key 'PRIMARY'
ERROR - 2015-03-29 23:45:46 --> Query error: Duplicate entry 'tes-2015' for key 'PRIMARY'
