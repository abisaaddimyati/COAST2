<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-28 00:32:22 --> 404 Page Not Found --> robots.txt
ERROR - 2015-08-28 00:45:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-28 00:45:31 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-08-28 00:45:32 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-08-28 04:08:33 --> 404 Page Not Found --> favicon.ico
