<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-27 02:41:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-27 02:41:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-27 02:48:55 --> Query error: Duplicate entry 'CBI.053.141020' for key 'PRIMARY'
ERROR - 2014-12-27 02:49:59 --> Query error: Duplicate entry 'CBI.053.141020' for key 'PRIMARY'
ERROR - 2014-12-27 19:10:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-27 19:10:31 --> 404 Page Not Found --> favicon.ico
