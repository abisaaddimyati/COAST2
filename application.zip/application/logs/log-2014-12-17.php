<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-17 00:05:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 01:45:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 02:17:35 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 02:17:45 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2014-12-17 02:18:56 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 02:18:56 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 02:18:56 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 02:18:56 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:18:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:18:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 02:18:56 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 02:18:56 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 02:32:57 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 02:32:57 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 02:32:57 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 02:32:57 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:32:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:32:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 02:32:57 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 02:32:58 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 02:33:28 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 02:33:28 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 02:33:28 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 02:33:28 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:33:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:33:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 02:33:28 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 02:33:29 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 02:34:19 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 02:34:19 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 02:34:19 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 02:34:19 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:34:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:34:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 02:34:19 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 02:34:21 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 02:34:48 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 02:34:48 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 02:34:48 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 02:34:48 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:34:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:34:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 02:34:48 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 02:34:49 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 02:37:28 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 02:37:28 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 02:37:28 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 02:37:28 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:37:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 02:37:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 02:37:28 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 02:37:29 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 09:14:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 09:14:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 09:19:27 --> Severity: Notice  --> Undefined variable: destination_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas049.php 57
ERROR - 2014-12-17 09:19:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas049.php 57
ERROR - 2014-12-17 11:01:11 --> 404 Page Not Found --> assets
ERROR - 2014-12-17 11:01:11 --> 404 Page Not Found --> assets
ERROR - 2014-12-17 11:06:04 --> 404 Page Not Found --> assets
ERROR - 2014-12-17 11:07:49 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-17 11:07:49 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-17 11:08:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2014-12-17 11:11:17 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas036.php 103
ERROR - 2014-12-17 11:11:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas036.php 103
ERROR - 2014-12-17 11:11:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas036.php 152
ERROR - 2014-12-17 19:36:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 19:36:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 19:36:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 19:49:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 20:04:02 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2014-12-17 20:04:04 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter
ERROR - 2014-12-17 20:04:04 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min1
ERROR - 2014-12-17 20:04:05 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min2
ERROR - 2014-12-17 20:04:06 --> 404 Page Not Found --> c_oas042/feed_claim_transport_left_counter
ERROR - 2014-12-17 20:04:06 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin1_left_counter
ERROR - 2014-12-17 20:04:07 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin2_left_counter
ERROR - 2014-12-17 20:04:07 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasi_left_counter
ERROR - 2014-12-17 20:04:08 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin1_left_counter
ERROR - 2014-12-17 20:04:08 --> 404 Page Not Found --> c_oas042/feed_claim_komunikasimin2_left_counter
ERROR - 2014-12-17 20:04:15 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2014-12-17 20:06:20 --> Severity: Notice  --> Undefined variable: destination_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas049.php 57
ERROR - 2014-12-17 20:06:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas049.php 57
ERROR - 2014-12-17 20:11:21 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2014-12-17 20:13:59 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2014-12-17 20:17:43 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 20:17:43 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 20:17:43 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 20:17:43 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 20:17:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 20:17:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 20:17:43 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 20:17:43 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 20:21:10 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2014-12-17 20:27:42 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 20:28:31 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 130
ERROR - 2014-12-17 20:28:31 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 137
ERROR - 2014-12-17 20:28:31 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 151
ERROR - 2014-12-17 20:28:31 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 20:28:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 247
ERROR - 2014-12-17 20:28:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 404
ERROR - 2014-12-17 20:28:31 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 407
ERROR - 2014-12-17 20:28:32 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 20:36:29 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2014-12-17 20:41:03 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 20:41:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 20:41:03 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 20:41:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 20:41:38 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 20:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 20:41:38 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 20:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 20:59:57 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 21:00:10 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2014-12-17 21:00:20 --> 404 Page Not Found --> c_oas029
ERROR - 2014-12-17 21:00:32 --> Query error: Duplicate entry '3-9' for key 'PRIMARY'
ERROR - 2014-12-17 21:11:14 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 21:11:31 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2014-12-17 21:23:15 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-17 21:23:15 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-17 21:23:58 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 21:24:05 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2014-12-17 21:24:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-17 21:24:11 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 50
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 57
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 71
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2014-12-17 21:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 329
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 330
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 331
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 337
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 396
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 397
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 398
ERROR - 2014-12-17 21:24:52 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 399
ERROR - 2014-12-17 21:24:53 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 21:27:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 21:27:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 21:59:16 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 21:59:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 21:59:16 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 21:59:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 22:14:09 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 22:14:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 22:14:09 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 22:14:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 22:14:14 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 22:14:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2014-12-17 22:14:14 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 22:14:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2014-12-17 22:17:59 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-17 22:17:59 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-17 22:31:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 22:31:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 22:54:45 --> 404 Page Not Found --> c_oas028
ERROR - 2014-12-17 22:56:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-17 22:56:26 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-17 22:57:51 --> 404 Page Not Found --> c_oas059
ERROR - 2014-12-17 23:02:00 --> 404 Page Not Found --> c_oas028
ERROR - 2014-12-17 23:02:36 --> 404 Page Not Found --> c_oas028
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 50
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 57
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 71
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2014-12-17 23:03:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 329
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 330
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 331
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 337
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 396
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 397
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 398
ERROR - 2014-12-17 23:03:11 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 399
ERROR - 2014-12-17 23:03:12 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 23:03:28 --> Query error: Unknown column 'usr.SHOW_SETTLE_INFORMATION' in 'field list'
ERROR - 2014-12-17 23:03:48 --> Query error: Unknown column 'usr.SHOW_SETTLE_INFORMATION' in 'field list'
ERROR - 2014-12-17 23:04:00 --> Query error: Unknown column 'usr.SHOW_SETTLE_INFORMATION' in 'field list'
ERROR - 2014-12-17 23:05:23 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2014-12-17 23:05:23 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2014-12-17 23:05:32 --> Query error: Unknown column 'usr.SHOW_SETTLE_INFORMATION' in 'field list'
ERROR - 2014-12-17 23:06:20 --> Query error: Unknown column 'usr.SHOW_SETTLE_INFORMATION' in 'field list'
ERROR - 2014-12-17 23:08:23 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2014-12-17 23:08:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2014-12-17 23:08:33 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2014-12-17 23:08:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2014-12-17 23:08:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2014-12-17 23:08:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2014-12-17 23:09:29 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2014-12-17 23:09:29 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2014-12-17 23:09:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 327
ERROR - 2014-12-17 23:09:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 328
ERROR - 2014-12-17 23:09:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 376
ERROR - 2014-12-17 23:09:30 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-17 23:18:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-17 23:18:32 --> 404 Page Not Found --> favicon.ico
