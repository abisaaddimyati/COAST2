<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-28 02:00:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 10:18:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 10:34:31 --> 404 Page Not Found --> robots.txt
ERROR - 2015-07-28 13:40:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 14:24:40 --> 404 Page Not Found --> robots.txt
ERROR - 2015-07-28 21:44:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 21:44:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 22:27:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 22:28:07 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-07-28 22:28:21 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-28 22:28:21 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-28 22:28:21 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-28 22:28:22 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-28 22:29:51 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-28 22:29:54 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-28 23:06:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 23:06:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 23:06:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 23:07:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-28 23:07:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-28 23:07:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-28 23:07:34 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-28 23:08:42 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-28 23:09:23 --> Query error: Duplicate entry '2-14' for key 'PRIMARY'
ERROR - 2015-07-28 23:09:36 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-28 23:10:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-28 23:10:31 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-28 23:10:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-28 23:15:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-28 23:15:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-28 23:15:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-28 23:15:46 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-28 23:22:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-28 23:23:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-28 23:23:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-28 23:23:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-28 23:23:42 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-28 23:24:35 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-28 23:27:22 --> Query error: Duplicate entry '2-11' for key 'PRIMARY'
ERROR - 2015-07-28 23:28:34 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-28 23:29:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-28 23:29:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-28 23:29:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-28 23:29:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-28 23:30:32 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-28 23:32:23 --> Query error: Duplicate entry '3-25' for key 'PRIMARY'
ERROR - 2015-07-28 23:53:44 --> 404 Page Not Found --> favicon.ico
