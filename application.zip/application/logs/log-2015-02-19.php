<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-19 18:18:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-19 19:10:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-19 19:10:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-19 21:01:07 --> 404 Page Not Found --> favicon.ico
