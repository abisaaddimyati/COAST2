<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-03 18:56:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-03 18:57:30 --> 404 Page Not Found --> favicon.ico
