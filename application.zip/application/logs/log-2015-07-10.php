<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-10 00:48:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-10 00:48:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-10 01:05:41 --> Query error: Duplicate entry '1-93' for key 'PRIMARY'
ERROR - 2015-07-10 01:05:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-10 01:10:20 --> Query error: Duplicate entry '1-93' for key 'PRIMARY'
ERROR - 2015-07-10 01:51:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-10 03:00:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-10 19:06:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-10 19:06:24 --> 404 Page Not Found --> favicon.ico
