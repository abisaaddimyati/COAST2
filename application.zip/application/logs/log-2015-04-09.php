<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-09 01:39:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-09 01:40:15 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-09 01:45:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-09 01:45:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-09 01:48:14 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-09 19:00:19 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-09 19:00:19 --> 404 Page Not Found --> apple-touch-icon.png
