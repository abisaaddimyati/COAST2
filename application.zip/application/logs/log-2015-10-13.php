<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-13 00:36:38 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-13 00:36:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-13 00:36:38 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-13 00:36:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-13 00:36:52 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-13 00:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-13 00:36:52 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-13 00:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-13 00:39:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-13 00:39:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-13 00:39:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-13 00:39:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-13 00:39:43 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-13 00:40:14 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-13 00:40:56 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-13 00:42:42 --> 404 Page Not Found --> assets
ERROR - 2015-10-13 00:46:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 01:00:57 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-10-13 01:00:57 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-10-13 01:00:57 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-10-13 01:00:57 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-10-13 01:00:57 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-10-13 01:00:57 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-10-13 01:05:38 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-10-13 01:05:38 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-10-13 01:05:38 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-10-13 01:05:38 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-10-13 01:05:38 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-10-13 01:05:38 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-10-13 01:09:35 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 463
ERROR - 2015-10-13 01:09:35 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 467
ERROR - 2015-10-13 01:09:35 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-10-13 01:09:35 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-10-13 01:10:12 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 463
ERROR - 2015-10-13 01:10:12 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 467
ERROR - 2015-10-13 01:10:12 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-10-13 01:10:12 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-10-13 03:02:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 03:04:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-13 03:04:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-13 03:04:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-13 03:04:25 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-13 03:04:38 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-13 03:04:38 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-13 03:04:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-13 03:04:38 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-13 03:05:21 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-13 03:31:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 03:31:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 03:32:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 04:25:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 04:44:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 04:44:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 04:46:50 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-13 04:46:50 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-13 04:46:50 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-13 04:46:50 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-13 04:47:02 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 102
ERROR - 2015-10-13 04:47:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 102
ERROR - 2015-10-13 04:47:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 06:29:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 06:29:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 08:26:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 20:22:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-13 22:00:23 --> 404 Page Not Found --> robots.txt
