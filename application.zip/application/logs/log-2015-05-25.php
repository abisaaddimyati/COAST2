<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-25 00:57:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-25 00:57:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-25 00:57:25 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-05-25 00:57:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-05-25 00:57:42 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-05-25 00:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-05-25 00:57:42 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-05-25 00:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-05-25 21:40:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-25 22:29:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-25 23:40:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-25 23:44:47 --> 404 Page Not Found --> favicon.ico
