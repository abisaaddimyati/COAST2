<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-25 21:34:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-25 21:34:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-25 22:10:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-25 22:10:11 --> 404 Page Not Found --> favicon.ico
