<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-22 01:26:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-22 19:35:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-22 19:39:41 --> 404 Page Not Found --> admin
ERROR - 2014-12-22 19:39:59 --> 404 Page Not Found --> assets
ERROR - 2014-12-22 19:40:03 --> 404 Page Not Found --> assets
