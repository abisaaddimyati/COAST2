<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-28 21:24:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-28 22:34:43 --> 404 Page Not Found --> favicon.ico
