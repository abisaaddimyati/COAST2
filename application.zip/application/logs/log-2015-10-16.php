<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-16 00:05:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-16 00:25:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-16 00:45:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-16 20:33:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-16 20:33:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-16 23:23:00 --> 404 Page Not Found --> favicon.ico
