<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-27 00:36:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-27 00:36:46 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-03-27 00:36:46 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-03-27 02:36:24 --> 404 Page Not Found --> favicon.ico
