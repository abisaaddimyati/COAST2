<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-02 00:19:53 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 00:19:53 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 00:19:53 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 00:19:53 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 00:19:53 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 00:19:53 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 00:35:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-02 02:33:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-02 02:34:14 --> Query error: Unknown column 'usr.SHOW_PR_INFORMATION' in 'field list'
ERROR - 2015-04-02 02:40:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 02:40:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:40:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:40:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:40:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 02:40:27 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 02:40:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 02:40:36 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:40:36 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:40:36 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:40:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 02:40:37 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 02:41:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 02:41:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:41:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:41:03 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:41:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 02:41:13 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 02:43:08 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 02:43:08 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:43:08 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:43:08 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 02:43:08 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 02:43:08 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 02:52:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-02 02:52:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-02 02:56:43 --> Severity: Notice  --> Undefined variable: item_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 02:56:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 03:01:19 --> Severity: Notice  --> Undefined variable: item_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 03:01:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 03:01:29 --> Severity: Notice  --> Undefined variable: item_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 03:01:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 03:02:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-02 03:22:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 03:22:44 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 03:22:44 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 03:22:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 03:22:45 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 03:24:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-02 03:24:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 03:24:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-02 03:24:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-02 03:24:11 --> 404 Page Not Found --> assets
ERROR - 2015-04-02 08:41:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-02 23:04:19 --> 404 Page Not Found --> favicon.ico
