<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-14 05:38:06 --> 404 Page Not Found --> favicon.ico
