<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-09 01:23:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-09 01:45:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-09 11:56:52 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-09 19:40:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-09 19:40:12 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-09 19:40:13 --> 404 Page Not Found --> apple-touch-icon.png
