<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-02 00:26:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-02 16:58:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-02 22:12:03 --> 404 Page Not Found --> favicon.ico
