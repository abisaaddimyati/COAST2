<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-08 00:43:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 03:00:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 03:00:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 19:26:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 19:26:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 19:45:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 19:59:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-07-08 19:59:04 --> 404 Page Not Found --> assets
ERROR - 2015-07-08 21:34:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 21:34:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 22:04:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-08 22:04:53 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-08 22:10:14 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
