<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-01 00:44:25 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-01 03:24:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-01 03:31:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-01 17:19:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-01 20:55:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-01 23:44:19 --> 404 Page Not Found --> favicon.ico
