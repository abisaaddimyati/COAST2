<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-23 03:40:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 03:40:00 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-23 03:40:01 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-23 03:40:14 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-23 03:40:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 03:40:14 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-23 03:40:27 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-23 03:40:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 03:40:27 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-23 03:40:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 03:40:39 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-23 03:40:40 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-23 03:41:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 03:41:54 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-23 03:41:55 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-23 21:35:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 21:38:28 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 31
ERROR - 2015-07-23 21:38:28 --> Severity: Notice  --> Undefined variable: employees /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-07-23 21:38:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-07-23 21:38:28 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 76
ERROR - 2015-07-23 22:10:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 22:10:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 22:57:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-23 22:57:28 --> 404 Page Not Found --> favicon.ico
