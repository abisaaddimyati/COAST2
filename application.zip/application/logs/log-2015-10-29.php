<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-29 01:32:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 01:32:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 01:32:35 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 01:36:41 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 01:38:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 01:39:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 01:39:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 01:43:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 01:44:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 01:46:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:08:34 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-29 02:08:34 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-29 02:08:35 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:10:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-29 02:10:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-29 02:10:04 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:21:40 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 296
ERROR - 2015-10-29 02:28:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 02:28:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 02:28:51 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:30:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:30:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-29 02:30:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-29 02:30:43 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:30:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:31:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 02:31:23 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 02:33:05 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-29 02:33:05 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-29 02:33:05 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-29 02:33:06 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-29 02:37:59 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-29 02:43:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 02:43:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 02:43:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-29 02:43:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-29 02:43:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-29 02:43:28 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-29 02:43:57 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-29 02:54:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-29 02:54:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-29 02:54:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-29 02:54:47 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-29 03:04:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 03:55:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 03:55:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 03:55:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 03:55:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 03:55:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 03:55:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 03:55:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 03:55:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 03:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 03:57:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 03:57:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 03:57:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 03:57:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 03:57:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 03:57:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 03:57:20 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-29 03:57:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 03:57:59 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 03:57:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 03:57:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 03:57:59 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 03:57:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 03:57:59 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 03:58:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 03:58:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 03:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 03:59:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 03:59:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 04:13:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-29 04:13:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-29 04:13:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-29 04:13:57 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-29 04:14:20 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-29 04:28:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 04:28:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 04:28:57 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-10-29 04:28:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-10-29 05:17:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 05:17:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 19:52:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 19:52:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-29 19:52:53 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-29 20:04:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 20:04:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 20:23:12 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:23:12 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:23:12 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:23:12 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:23:12 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:23:24 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:23:24 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:23:24 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:23:24 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:23:24 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:23:32 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:23:32 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:23:32 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:23:32 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:23:32 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:24:01 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-29 20:24:01 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-29 20:24:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-29 20:24:01 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-29 20:24:52 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:24:52 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:24:52 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:24:52 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:24:52 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:29:10 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:29:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 20:29:10 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:29:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 20:29:10 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:29:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 20:29:10 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:29:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 20:29:10 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:29:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 37
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 37
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 41
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 53
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 60
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: detail_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 67
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: detail_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 67
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 74
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 84
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 91
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 98
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 98
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 105
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 110
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 122
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 129
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 129
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 136
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 143
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 154
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 241
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 248
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 248
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 251
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 251
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 255
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 255
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 262
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 266
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 271
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 271
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 278
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 283
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 283
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 283
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 288
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 288
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 295
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 301
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 301
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 305
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 305
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 312
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 318
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 318
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 318
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 318
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 318
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 318
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 335
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 335
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 335
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 335
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 353
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 379
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 380
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 381
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 381
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 388
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 391
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 394
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 397
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 400
ERROR - 2015-10-29 20:44:32 --> Severity: Notice  --> Undefined variable: id_hal /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas041.php 403
ERROR - 2015-10-29 21:13:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 21:13:00 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 21:13:00 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 21:13:00 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 21:13:00 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 21:13:00 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 21:13:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 21:14:32 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 21:14:32 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 21:14:32 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 21:14:32 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 21:14:32 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 21:14:32 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 21:14:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 21:31:37 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 21:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 21:31:37 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 21:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 21:31:37 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 21:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 21:31:37 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 21:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 21:31:37 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 21:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:18:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-29 22:18:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-29 22:18:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 22:19:10 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:19:10 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:19:10 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:19:10 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:19:10 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:21:39 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:21:39 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:21:39 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:21:39 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:21:39 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:27:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:28:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:29:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:29:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-29 22:29:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-29 22:29:21 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 22:29:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 22:29:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 22:29:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 22:29:28 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 22:29:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 22:29:28 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 22:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 22:31:54 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:31:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:31:54 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:31:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:31:54 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:31:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:31:54 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:31:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:31:54 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:31:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:32:51 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:32:51 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:32:51 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:32:51 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:32:51 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:33:29 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 22:33:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 22:33:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 22:33:29 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 22:33:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 22:33:29 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 22:33:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 22:33:46 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:33:46 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:33:46 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:33:46 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:33:46 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:33:50 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:33:50 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:33:50 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:33:50 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:33:50 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:35:11 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:35:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:35:11 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:35:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:35:11 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:35:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:35:11 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:35:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:35:11 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:35:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:35:21 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:35:21 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:35:21 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:35:21 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:35:21 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:35:48 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:35:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:35:48 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:35:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:35:48 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:35:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:35:48 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:35:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:35:48 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:35:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:37:46 --> Severity: Notice  --> Undefined variable: list_group /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 62
ERROR - 2015-10-29 22:37:46 --> Severity: Notice  --> Undefined variable: employee_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 86
ERROR - 2015-10-29 22:37:46 --> Severity: Notice  --> Undefined variable: month_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 119
ERROR - 2015-10-29 22:37:46 --> Severity: Notice  --> Undefined variable: list_chargecodetype /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 136
ERROR - 2015-10-29 22:37:46 --> Severity: Notice  --> Undefined variable: list_cash_advance_type /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas044.php 168
ERROR - 2015-10-29 22:37:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:37:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:39:15 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-29 22:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-29 22:39:15 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-29 22:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-29 22:41:06 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-29 22:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-29 22:41:06 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-29 22:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-29 22:50:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:50:57 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-29 22:50:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 22:51:19 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 22:51:19 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 22:51:19 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 22:51:19 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 22:51:19 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 22:51:19 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 22:51:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 22:51:52 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 22:51:52 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 22:51:52 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 22:51:52 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 22:51:52 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 22:51:52 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 22:52:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 22:52:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 22:52:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 22:52:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 22:52:51 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 22:52:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 22:52:51 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 22:52:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 22:54:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-29 22:54:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-29 22:54:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-29 22:54:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-29 22:54:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-29 22:54:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-29 22:55:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-29 23:16:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 23:16:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 23:19:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 23:19:32 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 23:20:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 23:20:41 --> 404 Page Not Found --> assets
ERROR - 2015-10-29 23:21:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 23:21:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-29 23:46:25 --> 404 Page Not Found --> assets
