<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-21 04:20:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-21 04:20:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-21 04:41:29 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-03-21 04:47:54 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
