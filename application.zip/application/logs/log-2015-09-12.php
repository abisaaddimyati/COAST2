<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-12 07:19:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-12 09:26:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-12 14:41:47 --> 404 Page Not Found --> robots.txt
