<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-28 03:41:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-28 18:15:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-28 18:20:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-28 18:22:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-28 20:13:01 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-28 20:13:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-28 20:13:02 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-28 21:00:54 --> 404 Page Not Found --> favicon.ico
