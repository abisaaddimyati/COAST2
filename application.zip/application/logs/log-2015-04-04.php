<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-04 03:15:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-04 03:15:22 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-04 05:17:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-04 05:17:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-04 05:48:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-04 05:48:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-04 05:48:04 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-04 05:48:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-04 05:48:06 --> 404 Page Not Found --> assets
ERROR - 2015-04-04 06:58:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0'))
		
		ORDER BY pr.PR_ID desc' at line 47
ERROR - 2015-04-04 06:58:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0'))
		
		ORDER BY pr.PR_ID desc' at line 47
ERROR - 2015-04-04 10:03:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-04 10:11:58 --> 404 Page Not Found --> favicon.ico
