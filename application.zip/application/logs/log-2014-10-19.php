<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-19 21:48:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-19 21:49:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-19 21:49:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-19 21:49:35 --> 404 Page Not Found --> favicon.ico
