<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-30 20:48:10 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2014-12-30 20:48:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-30 20:48:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-30 20:54:59 --> 404 Page Not Found --> intranet.cybertrend-intra.com
