<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-18 01:51:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_setl_amount /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 306
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_IDR /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 307
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_IDR_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 308
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_USD /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 310
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_SGD /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 311
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_USD_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 313
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_SGD_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 314
ERROR - 2015-01-18 01:52:56 --> Severity: Notice  --> Undefined index: liability_setl_amount_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 315
ERROR - 2015-01-18 04:09:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 04:09:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 04:09:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 04:09:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 04:09:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:39:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:39:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:39:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:39:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:39:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:39:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 06:40:09 --> 404 Page Not Found --> c_oas042/feed_leave_left_counter
ERROR - 2015-01-18 06:40:11 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter
ERROR - 2015-01-18 06:40:11 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min1
ERROR - 2015-01-18 06:40:14 --> 404 Page Not Found --> c_oas042/feed_claim_left_counter_min2
ERROR - 2015-01-18 06:40:35 --> 404 Page Not Found --> c_oas042/feed_claim_transport_left_counter
ERROR - 2015-01-18 06:40:38 --> 404 Page Not Found --> c_oas042/feed_claim_transportmin1_left_counter
ERROR - 2015-01-18 17:49:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-18 17:54:13 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-01-18 17:54:13 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-01-18 17:54:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 403
ERROR - 2015-01-18 17:54:14 --> 404 Page Not Found --> jquery.js
