<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-20 04:07:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-20 04:07:34 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-10-20 04:07:35 --> 404 Page Not Found --> apple-touch-icon.png
