<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-20 19:54:16 --> 404 Page Not Found --> favicon.ico
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-20 19:54:16 --> 404 Page Not Found --> favicon.ico
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-20 19:54:16 --> 404 Page Not Found --> favicon.ico
