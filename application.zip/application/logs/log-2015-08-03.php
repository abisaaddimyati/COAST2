<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-03 01:36:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 01:36:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 02:37:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 02:37:36 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-08-03 02:37:36 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-08-03 19:48:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 20:38:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 20:50:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 22:00:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 23:21:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-03 23:21:06 --> 404 Page Not Found --> favicon.ico
