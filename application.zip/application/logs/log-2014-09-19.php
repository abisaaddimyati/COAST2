<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-19 01:50:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 01:51:17 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 01:52:33 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 01:53:28 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 01:54:35 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 01:55:51 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 01:55:51 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 01:56:13 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 01:56:13 --> Query error: Duplicate entry '1-1' for key 'PRIMARY'
ERROR - 2014-09-19 01:56:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 01:56:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 02:07:56 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:08:32 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:08:32 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 02:27:27 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:27:45 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:28:03 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:28:03 --> Query error: Duplicate entry '1-1' for key 'PRIMARY'
ERROR - 2014-09-19 02:28:11 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:28:11 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 02:28:17 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:30:01 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:32:20 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:32:20 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 02:34:19 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:34:31 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:34:31 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 02:35:52 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:37:10 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:37:24 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:37:56 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:37:56 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 02:39:38 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:39:51 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:39:51 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 02:40:12 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:42:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-09-19 02:42:34 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:53:13 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 02:53:44 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 02:53:44 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 03:08:57 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:09:22 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:09:47 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 03:09:47 --> Query error: Duplicate entry '1-10' for key 'PRIMARY'
ERROR - 2014-09-19 03:11:46 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:12:01 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 03:12:01 --> Query error: Duplicate entry '1-10' for key 'PRIMARY'
ERROR - 2014-09-19 03:12:55 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:27:58 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-19 03:27:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-19 03:28:03 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-19 03:28:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-19 03:28:03 --> Severity: Notice  --> Undefined index: employee_division_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 243
ERROR - 2014-09-19 03:28:03 --> Severity: Notice  --> Undefined index: employee_division_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 243
ERROR - 2014-09-19 03:28:03 --> Severity: Notice  --> Undefined index: employee_division_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 243
ERROR - 2014-09-19 03:32:50 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:33:14 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:54:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-09-19 03:54:24 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:55:02 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 03:55:02 --> Query error: Duplicate entry '1-9' for key 'PRIMARY'
ERROR - 2014-09-19 03:56:23 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:56:38 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 03:56:38 --> Query error: Duplicate entry '1-4' for key 'PRIMARY'
ERROR - 2014-09-19 03:56:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 03:57:59 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 03:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-09-19 12:45:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 12:45:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 12:46:26 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 12:47:51 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 12:48:23 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-19 12:48:23 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-19 12:49:55 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 13:52:54 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 13:58:31 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:09:01 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:13:44 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:14:20 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:14:38 --> 404 Page Not Found --> c_aos011
ERROR - 2014-09-19 14:14:51 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:15:09 --> 404 Page Not Found --> c_aos011
ERROR - 2014-09-19 14:15:58 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:16:30 --> 404 Page Not Found --> c_aos011
ERROR - 2014-09-19 14:18:30 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:18:53 --> 404 Page Not Found --> c_aos011
ERROR - 2014-09-19 14:19:44 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:20:16 --> 404 Page Not Found --> c_aos011
ERROR - 2014-09-19 14:25:26 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:27:47 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:29:56 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:31:03 --> 404 Page Not Found --> assets
ERROR - 2014-09-19 14:38:22 --> Query error: Table 'cybertr5_intranet.tb_m_systeM' doesn't exist
ERROR - 2014-09-19 14:38:48 --> Query error: Table 'cybertr5_intranet.tb_m_systeM' doesn't exist
ERROR - 2014-09-19 19:23:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-19 19:53:44 --> 404 Page Not Found --> assets
