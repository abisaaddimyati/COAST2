<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-31 03:37:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-31 03:37:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-31 20:48:25 --> 404 Page Not Found --> favicon.ico
