<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-30 00:01:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-30 00:06:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-30 03:25:23 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-30 03:25:23 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-30 03:25:23 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-30 03:25:23 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-30 03:25:23 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-30 03:25:23 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-30 21:20:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-30 21:20:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-30 22:43:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-30 22:43:10 --> 404 Page Not Found --> favicon.ico
