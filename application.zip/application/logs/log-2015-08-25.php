<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-25 00:16:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-25 00:16:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-25 00:17:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-25 00:31:06 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-25 00:31:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-25 06:20:11 --> 404 Page Not Found --> favicon.ico
