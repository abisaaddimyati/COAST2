<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-20 21:51:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-20 22:16:16 --> 404 Page Not Found --> favicon.ico
