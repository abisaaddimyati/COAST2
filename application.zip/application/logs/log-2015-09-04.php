<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-04 02:58:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-04 03:01:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-04 03:01:02 --> 404 Page Not Found --> favicon.ico
