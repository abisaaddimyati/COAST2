<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-15 01:32:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 01:35:00 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-15 01:35:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-15 01:35:45 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 02:05:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 02:05:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 02:39:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 02:39:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 03:12:03 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 05:32:00 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-15 05:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-15 05:36:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 05:38:28 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-15 05:38:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-15 06:36:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 06:36:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 09:45:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 09:45:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 09:46:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-15 09:46:18 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 09:47:11 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 09:47:15 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 164
ERROR - 2015-09-15 09:53:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 09:53:52 --> 404 Page Not Found --> Loginhost%20monster
ERROR - 2015-09-15 09:53:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 09:55:09 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 10:04:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-15 10:04:14 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 10:04:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-15 10:04:17 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 10:05:12 --> Severity: Notice  --> Undefined variable: response /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas090.php 59
ERROR - 2015-09-15 10:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-15 10:07:17 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 10:07:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-15 10:07:29 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 10:08:39 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 10:08:47 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 164
ERROR - 2015-09-15 10:08:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-15 10:08:52 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 12:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 12:43:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 12:43:40 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 12:44:06 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 87
ERROR - 2015-09-15 12:44:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 12:48:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 12:48:54 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 12:49:23 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 87
ERROR - 2015-09-15 12:49:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 12:54:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 12:54:21 --> 404 Page Not Found --> assets
ERROR - 2015-09-15 12:54:47 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 87
ERROR - 2015-09-15 12:54:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-15 22:10:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 22:10:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-15 22:15:20 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-15 22:15:20 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-15 22:15:20 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-15 22:15:20 --> 404 Page Not Found --> jquery.js
