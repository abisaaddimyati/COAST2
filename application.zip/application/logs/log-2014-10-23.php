<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-23 21:40:35 --> 404 Page Not Found --> favicon.ico
