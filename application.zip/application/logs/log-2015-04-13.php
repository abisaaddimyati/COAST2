<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-13 00:04:35 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-13 00:08:01 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:13 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:26 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:39 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:46 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:08:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:09:02 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:09:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-13 00:09:26 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas029.php 172
ERROR - 2015-04-13 00:09:26 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-04-13 00:09:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-04-13 00:09:26 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 151
ERROR - 2015-04-13 00:09:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 151
ERROR - 2015-04-13 00:09:51 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas029.php 172
ERROR - 2015-04-13 00:09:51 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-04-13 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-04-13 00:10:00 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas029.php 172
ERROR - 2015-04-13 03:58:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 03:58:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 05:17:20 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-13 05:18:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-13 05:18:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-13 05:18:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-13 05:18:15 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-13 05:18:52 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-04-13 09:59:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 10:07:49 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-13 11:22:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:16:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:16:34 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:16:35 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:18:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:18:59 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:18:59 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:21:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:21:23 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:21:23 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:23:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:23:07 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:23:08 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:23:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:23:17 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:23:18 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:23:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:23:53 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:23:58 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:26:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:26:11 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:26:12 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:26:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:26:40 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:26:40 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:26:51 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:26:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:26:52 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 16:26:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 16:26:54 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 16:26:54 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-13 20:17:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 22:07:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-13 22:08:00 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-13 22:08:00 --> 404 Page Not Found --> apple-touch-icon.png
