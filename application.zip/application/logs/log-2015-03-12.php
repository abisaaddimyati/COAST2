<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-12 11:29:40 --> 404 Page Not Found --> favicon.ico
