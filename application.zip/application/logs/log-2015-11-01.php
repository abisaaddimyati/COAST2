<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-01 16:40:05 --> 404 Page Not Found --> robots.txt
ERROR - 2015-11-01 18:52:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 19:02:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 19:32:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 19:32:21 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-11-01 19:32:21 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-11-01 19:32:24 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-11-01 19:32:24 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-11-01 19:58:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 19:58:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 19:59:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-01 19:59:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-01 20:01:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-01 20:01:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-01 20:21:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 20:21:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 20:36:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 20:38:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas045.php 172
ERROR - 2015-11-01 20:38:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas045.php 172
ERROR - 2015-11-01 21:05:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 21:24:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 21:24:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 22:51:58 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-01 22:51:58 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-01 22:51:58 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-01 22:52:01 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-01 23:43:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 23:43:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 23:44:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-01 23:44:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-01 23:44:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-01 23:44:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-01 23:44:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-01 23:44:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-01 23:45:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-01 23:47:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-01 23:53:32 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-11-01 23:55:19 --> 404 Page Not Found --> favicon.ico
