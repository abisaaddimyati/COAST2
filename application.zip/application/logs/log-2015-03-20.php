<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-20 02:15:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-20 02:15:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-20 05:08:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-20 05:08:45 --> 404 Page Not Found --> favicon.ico
