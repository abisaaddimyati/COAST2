<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-23 03:06:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-23 10:23:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-23 10:35:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-23 10:35:06 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-23 10:35:06 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-23 10:35:06 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-23 10:35:06 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-23 10:35:06 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-23 10:35:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-23 10:36:43 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-04-23 10:36:43 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-04-23 10:36:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-04-23 10:36:44 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-23 10:36:58 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-23 10:36:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-23 20:28:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-23 20:46:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-23 21:35:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-23 21:35:59 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-23 21:35:59 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-23 22:22:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-23 22:22:06 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-23 22:22:07 --> 404 Page Not Found --> apple-touch-icon.png
