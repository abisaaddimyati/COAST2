<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-31 00:08:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-31 02:19:59 --> 404 Page Not Found --> favicon.ico
