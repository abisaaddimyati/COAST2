<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-17 01:27:18 --> 404 Page Not Found --> apple-touch-icon-120x120-precomposed.png
ERROR - 2015-05-17 01:27:18 --> 404 Page Not Found --> apple-touch-icon-120x120.png
ERROR - 2015-05-17 01:27:18 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-17 01:27:19 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-17 01:27:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 01:27:20 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-17 01:27:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 03:01:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 18:40:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 18:40:33 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-17 18:40:33 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-17 22:03:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 22:03:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 23:47:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-17 23:47:43 --> 404 Page Not Found --> favicon.ico
