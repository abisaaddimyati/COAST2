<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-04 23:00:25 --> 404 Page Not Found --> favicon.ico
