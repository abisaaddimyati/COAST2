<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-26 01:19:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-26 01:23:31 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 98
ERROR - 2014-11-26 01:23:33 --> 404 Page Not Found --> jquery.js
