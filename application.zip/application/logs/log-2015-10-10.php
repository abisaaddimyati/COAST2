<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-10 00:11:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-10 08:31:20 --> 404 Page Not Found --> favicon.ico
