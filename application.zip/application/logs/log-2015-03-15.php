<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-15 10:10:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 10:10:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 10:41:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-15 10:41:53 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2015-03-15 10:56:12 --> 404 Page Not Found --> c_oas004
ERROR - 2015-03-15 10:56:18 --> 404 Page Not Found --> c_oas004
ERROR - 2015-03-15 10:56:23 --> 404 Page Not Found --> c_oas004
ERROR - 2015-03-15 10:56:29 --> 404 Page Not Found --> c_oas004
ERROR - 2015-03-15 11:13:55 --> Query error: Unknown column 'empl.PERIODE_MEDICAL_CLAIM' in 'field list'
ERROR - 2015-03-15 11:14:15 --> Query error: Unknown column 'empl.PERIODE_MEDICAL_CLAIM' in 'field list'
ERROR - 2015-03-15 11:14:25 --> Query error: Unknown column 'empl.PERIODE_MEDICAL_CLAIM' in 'field list'
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:33 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_MEDICAL_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 155
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KEGUGURAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 156
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KELAHIRAN_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 157
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_KACAMATA_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 158
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TRANSPORT_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 159
ERROR - 2015-03-15 11:15:34 --> Severity: Notice  --> Undefined index: ANNUAL_CLAIM_TELEKOMUNIKASI_ENTITLEMENT /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 160
ERROR - 2015-03-15 11:16:53 --> 404 Page Not Found --> c_oas0100
ERROR - 2015-03-15 11:17:27 --> 404 Page Not Found --> c_oas0100
ERROR - 2015-03-15 11:19:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas105.php 53
ERROR - 2015-03-15 11:20:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas105.php 53
ERROR - 2015-03-15 11:22:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas105.php 53
ERROR - 2015-03-15 11:22:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-15 11:22:57 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-15 11:22:57 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-15 11:22:57 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-15 11:22:57 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-15 11:22:57 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-15 11:23:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-03-15 11:24:47 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:24:53 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:24:59 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:06 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:12 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:19 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:25 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:31 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:38 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:46 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:52 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:25:58 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:04 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:11 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:17 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:23 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:29 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:36 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:42 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:48 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:26:54 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:01 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:07 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:13 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:19 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:25 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:32 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:39 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:45 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:51 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:27:58 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:08 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:14 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:21 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:27 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:34 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:41 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:47 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:28:53 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:00 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:07 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:14 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:25 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:33 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:40 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:49 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:29:59 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:30:16 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:30:32 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:30:39 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:30:45 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:30:51 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:30:57 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:04 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:10 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:17 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:23 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:29 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:36 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:43 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:49 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:31:55 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:04 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:10 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:16 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:23 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:29 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:35 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:42 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:48 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:32:56 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:03 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:17 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:23 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:30 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:36 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:42 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:49 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:33:55 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:01 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:08 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:14 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:21 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:27 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:33 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:40 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:46 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:52 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:34:59 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:06 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:13 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:20 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:28 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:35 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:42 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:48 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:35:54 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:00 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:07 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:14 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:21 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:27 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:34 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:41 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:47 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:36:54 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:00 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:09 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:15 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:21 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:28 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:34 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:40 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:46 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:37:53 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:00 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:08 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:14 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:20 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:27 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:33 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:39 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:45 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:51 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:38:57 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:05 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:17 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:24 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:30 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:37 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:43 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:49 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:39:55 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:02 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:09 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:15 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:22 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:28 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:35 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:41 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:47 --> 404 Page Not Found --> c_oas0
ERROR - 2015-03-15 11:40:54 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:00 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:01 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:08 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:09 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:15 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:16 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:22 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:23 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:31 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:33 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:38 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:40 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:45 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:47 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:53 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 11:41:55 --> 404 Page Not Found --> c_oas04
ERROR - 2015-03-15 18:57:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 18:58:13 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 18:58:37 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 18:59:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 18:59:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 18:59:42 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:36:57 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:38:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 20:38:52 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:40:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 20:40:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 20:41:07 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:41:35 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:41:57 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:42:26 --> Severity: Notice  --> Undefined index: email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas011.php 214
ERROR - 2015-03-15 20:59:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-03-15 20:59:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-03-15 21:09:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 22:16:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 22:16:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-15 22:35:53 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-15 22:36:04 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-03-15 22:37:30 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-03-15 22:37:40 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
