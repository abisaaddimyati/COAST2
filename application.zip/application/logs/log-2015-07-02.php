<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-02 01:57:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-02 01:57:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-02 02:05:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-02 21:32:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-02 21:32:31 --> 404 Page Not Found --> favicon.ico
