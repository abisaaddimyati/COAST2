<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-05 00:01:15 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-11-05 00:15:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 428
ERROR - 2015-11-05 00:15:08 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 431
ERROR - 2015-11-05 00:15:09 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 00:19:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 00:19:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 00:19:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 00:19:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 00:19:48 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 00:46:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 00:54:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 01:09:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 01:11:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 01:11:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 01:11:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 01:11:00 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 01:11:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 01:11:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 01:11:35 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 01:12:43 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-05 01:12:43 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-05 01:12:43 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-05 01:12:43 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-05 01:12:43 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-05 01:12:43 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-05 01:12:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-05 01:16:46 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-05 01:16:46 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-05 01:16:46 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-05 01:16:46 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-05 01:16:46 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-05 01:16:46 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-05 01:17:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-05 01:21:31 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-11-05 01:21:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-11-05 01:22:26 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-11-05 01:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-11-05 01:45:47 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-11-05 01:45:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-11-05 01:59:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 01:59:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 01:59:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 01:59:13 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 01:59:57 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 02:01:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:01:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:03:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:03:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:09:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:09:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:19:33 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-05 02:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-05 02:19:33 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-05 02:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-05 02:20:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-05 02:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-05 02:20:40 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-05 02:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-05 02:22:58 --> 404 Page Not Found --> c_oas0444
ERROR - 2015-11-05 02:23:30 --> 404 Page Not Found --> c_oas0444
ERROR - 2015-11-05 02:39:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 02:39:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 03:07:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 03:36:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 04:43:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 04:43:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 04:43:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 04:43:01 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 04:43:11 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 07:23:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 07:23:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 13:46:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 14:15:42 --> 404 Page Not Found --> robots.txt
ERROR - 2015-11-05 17:40:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 19:52:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 19:52:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 19:53:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 19:53:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 20:03:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 20:03:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 20:09:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 20:09:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 21:02:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 21:08:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 21:23:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 21:23:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 23:06:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 23:07:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 23:07:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 23:07:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 23:07:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 23:08:58 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 23:10:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 23:12:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 23:12:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 23:12:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 23:12:28 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 23:13:02 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 23:13:30 --> Query error: Duplicate entry '3-33' for key 'PRIMARY'
ERROR - 2015-11-05 23:13:35 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-11-05 23:13:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-05 23:13:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-05 23:13:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-05 23:13:58 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 23:14:15 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-05 23:14:49 --> Query error: Duplicate entry '3-33' for key 'PRIMARY'
ERROR - 2015-11-05 23:15:09 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-11-05 23:22:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-05 23:26:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:26:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:26:04 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:26:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:26:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:26:32 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:27:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:27:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:27:14 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:28:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:28:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:28:05 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:29:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:29:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:29:32 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:30:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:30:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:30:10 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:31:02 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 296
ERROR - 2015-11-05 23:31:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-11-05 23:31:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-11-05 23:31:08 --> 404 Page Not Found --> assets
ERROR - 2015-11-05 23:42:23 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-05 23:42:23 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-05 23:42:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-05 23:42:23 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 23:54:40 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-05 23:54:40 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-05 23:54:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-05 23:54:40 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-05 23:56:56 --> 404 Page Not Found --> favicon.ico
