<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-03 20:18:00 --> 404 Page Not Found --> robots.txt
