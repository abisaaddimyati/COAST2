<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-17 01:24:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-17 01:27:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-17 01:29:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-17 01:52:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-09-17 02:42:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-17 02:51:44 --> 404 Page Not Found --> assets
