<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-08 04:49:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 05:20:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 05:21:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-08 05:21:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-08 05:21:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-08 05:21:15 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-08 05:21:28 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-09-08 05:22:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 05:25:31 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-09-08 05:30:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 05:37:39 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-09-08 05:39:47 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-09-08 05:39:47 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-09-08 05:39:47 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-09-08 05:39:47 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-09-08 05:39:47 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-09-08 05:39:47 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-09-08 05:41:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 463
ERROR - 2015-09-08 05:41:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 467
ERROR - 2015-09-08 05:41:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-09-08 05:41:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-09-08 05:42:49 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 05:51:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 05:51:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 06:04:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 06:04:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 12:51:34 --> 404 Page Not Found --> browserconfig.xml
ERROR - 2015-09-08 14:44:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 15:23:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 15:23:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 19:32:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 19:33:27 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 19:43:57 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 20:12:49 --> 404 Page Not Found --> assets
ERROR - 2015-09-08 20:13:24 --> Severity: Notice  --> Undefined index: EMPLOYEE_EMAIL /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas075.php 211
ERROR - 2015-09-08 20:56:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 21:13:51 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 21:24:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 21:24:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 22:00:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-08 23:37:08 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 23:38:23 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 23:42:03 --> 404 Page Not Found --> OAS
ERROR - 2015-09-08 23:43:31 --> 404 Page Not Found --> OAS
