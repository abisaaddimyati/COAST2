<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-12 00:55:48 --> 404 Page Not Found --> C_OAS001
ERROR - 2014-09-12 02:30:47 --> 404 Page Not Found --> C_OAS001
ERROR - 2014-09-12 02:37:12 --> 404 Page Not Found --> C_OAS001
ERROR - 2014-09-12 02:57:19 --> 404 Page Not Found --> C_OAS001
ERROR - 2014-09-12 03:24:42 --> 404 Page Not Found --> C_OAS001
