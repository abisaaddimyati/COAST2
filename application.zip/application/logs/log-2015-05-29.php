<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-29 03:58:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-29 04:03:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-29 23:54:04 --> 404 Page Not Found --> favicon.ico
