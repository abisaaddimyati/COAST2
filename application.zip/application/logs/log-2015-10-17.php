<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-17 03:49:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-17 06:22:23 --> 404 Page Not Found --> favicon.ico
