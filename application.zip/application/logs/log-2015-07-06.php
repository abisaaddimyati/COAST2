<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-06 00:52:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-06 00:52:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-06 01:02:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-06 01:14:24 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-06 02:11:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-06 02:11:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-06 10:38:18 --> 404 Page Not Found --> favicon.ico
