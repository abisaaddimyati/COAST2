<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-16 01:28:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-16 02:58:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-16 19:44:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-16 21:22:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-16 21:22:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-16 21:39:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-16 21:39:31 --> 404 Page Not Found --> favicon.ico
