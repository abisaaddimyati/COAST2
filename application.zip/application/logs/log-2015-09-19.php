<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-19 03:05:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-19 03:06:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-19 04:25:27 --> 404 Page Not Found --> favicon.ico
