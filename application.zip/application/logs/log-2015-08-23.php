<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-23 02:46:16 --> 404 Page Not Found --> assets
ERROR - 2015-08-23 02:46:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-23 02:46:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-23 20:45:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-23 21:51:39 --> 404 Page Not Found --> favicon.ico
