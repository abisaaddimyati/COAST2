<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-10 02:38:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-10 02:38:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-10 22:26:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-10 22:32:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-10 22:47:21 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
