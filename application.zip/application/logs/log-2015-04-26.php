<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-26 05:15:47 --> 404 Page Not Found --> favicon.ico
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-26 05:15:47 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-26 05:15:49 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-26 12:49:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 12:49:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 20:43:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 20:43:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 20:48:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 20:52:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 21:05:53 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-26 21:55:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 21:55:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 22:40:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 22:41:37 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-26 22:51:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 22:52:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 22:52:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 22:54:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 23:33:49 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-26 23:48:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 23:48:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-26 23:48:44 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
