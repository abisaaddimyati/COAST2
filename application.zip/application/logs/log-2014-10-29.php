<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-29 01:36:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 01:36:21 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-10-29 01:36:22 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2014-10-29 01:37:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:21:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:21:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:22:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:32:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:32:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:32:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:32:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:32:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:32:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:38:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:38:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-29 22:38:49 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-10-29 22:38:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
