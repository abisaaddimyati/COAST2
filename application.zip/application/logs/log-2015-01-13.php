<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-13 02:47:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-13 02:47:34 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-01-13 02:47:34 --> 404 Page Not Found --> apple-touch-icon.png
