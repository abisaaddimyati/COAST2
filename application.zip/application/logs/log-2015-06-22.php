<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-22 00:51:14 --> 404 Page Not Found --> favicon.ico
