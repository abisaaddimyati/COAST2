<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-05 05:15:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-05 18:47:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-05 18:47:06 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-05 18:47:06 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-05 21:42:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-05 21:42:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-05 21:55:33 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-05 22:07:21 --> 404 Page Not Found --> favicon.ico
