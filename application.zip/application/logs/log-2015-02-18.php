<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-18 01:44:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-18 02:00:39 --> 404 Page Not Found --> favicon.ico
