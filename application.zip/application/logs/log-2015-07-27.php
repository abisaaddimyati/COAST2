<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-27 00:53:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 00:53:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 00:56:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:05:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:05:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:05:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:00 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:06 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:10 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:15 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:24 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:06:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-07-27 01:12:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:22:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:22:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:22:49 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:23:02 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:23:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:23:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:23:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:23:30 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:24:57 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:25:05 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:25:13 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:25:26 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:25:31 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:26:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:26:07 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:26:34 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:27:12 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:27:16 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:27:30 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:28:09 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-07-27 01:28:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-07-27 01:28:09 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-07-27 01:28:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-07-27 01:28:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:28:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:28:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:28:33 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:28:55 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 01:34:20 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-27 01:43:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:43:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:43:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:44:00 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:44:39 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 01:52:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:52:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:52:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:52:14 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:52:42 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 01:52:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:52:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:53:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:53:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 01:53:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:53:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:53:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:53:59 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:54:24 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 01:55:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 01:55:01 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 01:55:02 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:56:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:56:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:56:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:56:29 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:57:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 01:57:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 01:57:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 01:57:09 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 01:57:43 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:06:11 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-07-27 02:07:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:07:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 02:07:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:07:03 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:07:24 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:08:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:08:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 02:08:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:08:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:08:52 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:08:52 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 02:08:52 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:08:53 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:08:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:08:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 02:08:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:08:54 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:09:04 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:09:18 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:09:38 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:12:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 02:13:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 02:13:13 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 02:13:13 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:14:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:14:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 02:14:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:14:07 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:17:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 02:17:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 02:20:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 02:20:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 02:20:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 02:20:08 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 02:20:33 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:21:31 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:21:35 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 02:22:17 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-07-27 02:22:17 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-07-27 02:22:17 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-07-27 02:22:17 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-07-27 02:22:17 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-07-27 02:22:17 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-07-27 02:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 02:23:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 02:23:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 02:23:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 02:24:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 02:59:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 02:59:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 03:25:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 03:27:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:27:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:27:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:27:28 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:27:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 03:28:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:28:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:28:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:28:13 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:28:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 03:28:58 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:30:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 03:37:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 03:37:14 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 03:37:15 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:38:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:38:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:38:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:38:05 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 03:38:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 03:38:30 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 03:38:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 03:42:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 03:42:12 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 03:42:18 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:43:38 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:43:43 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:47:55 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-27 03:48:22 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-27 03:49:01 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:49:01 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:49:01 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:49:02 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:49:23 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:49:23 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:49:23 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:49:27 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:49:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:49:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:49:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:49:57 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:50:26 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:50:38 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:50:40 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:50:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:50:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:50:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:50:58 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:51:02 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:51:19 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:51:46 --> Query error: Duplicate entry '3-13' for key 'PRIMARY'
ERROR - 2015-07-27 03:51:51 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 03:52:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:52:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:52:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:52:34 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:52:59 --> Query error: Duplicate entry '3-14' for key 'PRIMARY'
ERROR - 2015-07-27 03:53:11 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:53:20 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 03:53:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 03:53:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 03:53:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 03:53:35 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 03:53:58 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 03:54:02 --> Query error: Duplicate entry '3-13' for key 'PRIMARY'
ERROR - 2015-07-27 03:54:42 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 03:55:28 --> Query error: Duplicate entry '3-14' for key 'PRIMARY'
ERROR - 2015-07-27 03:55:38 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 04:00:15 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-27 04:00:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 04:00:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 04:00:34 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 04:00:35 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 04:00:49 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 04:01:28 --> Query error: Duplicate entry '2-4' for key 'PRIMARY'
ERROR - 2015-07-27 04:01:31 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 04:17:35 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 04:28:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 04:28:23 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 04:28:23 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 04:31:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 04:31:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 04:33:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 04:33:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 04:33:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 04:33:53 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 04:34:45 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 04:35:46 --> Query error: Duplicate entry '3-13' for key 'PRIMARY'
ERROR - 2015-07-27 04:43:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 04:43:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 05:00:52 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-07-27 07:26:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 07:26:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 08:00:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 08:09:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 08:11:36 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 08:11:36 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 08:11:36 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 08:11:37 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 08:12:24 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 08:19:39 --> Query error: Duplicate entry '3-11' for key 'PRIMARY'
ERROR - 2015-07-27 08:19:48 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 09:53:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 09:53:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 09:58:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 09:58:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 09:58:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 09:58:18 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 09:58:43 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 09:59:37 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-07-27 09:59:37 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-07-27 09:59:37 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-07-27 09:59:37 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-07-27 09:59:37 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-07-27 09:59:37 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-07-27 09:59:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:00:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:00:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:01:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:01:07 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-07-27 10:01:07 --> Query error: Subquery returns more than 1 row
ERROR - 2015-07-27 10:01:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:01:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 10:02:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-07-27 19:53:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-27 19:54:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 19:54:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-07-27 19:54:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 19:54:24 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 19:55:14 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-07-27 19:58:20 --> Query error: Duplicate entry '3-11' for key 'PRIMARY'
ERROR - 2015-07-27 19:58:31 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 19:58:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 19:58:40 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 19:58:41 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 20:02:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 20:02:42 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 20:02:43 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 20:11:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 20:11:52 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 20:11:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 20:12:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-07-27 20:12:29 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-07-27 20:12:30 --> 404 Page Not Found --> jquery.js
ERROR - 2015-07-27 20:54:18 --> 404 Page Not Found --> favicon.ico
