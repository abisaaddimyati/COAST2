<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-17 01:20:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 01:20:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 01:20:58 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 01:20:58 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 01:20:58 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 01:20:58 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 01:20:58 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 01:21:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 01:21:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 01:40:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 01:40:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 01:41:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 01:41:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 01:41:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 01:41:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 01:41:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 01:41:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 01:41:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 01:42:21 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 01:42:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 01:42:37 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 01:42:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 01:42:47 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 01:42:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 02:04:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 02:06:20 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 02:06:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 02:06:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 02:06:20 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 02:06:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 02:06:20 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 02:06:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:28:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 02:30:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:30:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:30:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:30:59 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 02:30:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 02:30:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 02:30:59 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 02:30:59 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 02:30:59 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 02:31:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:33:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:33:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:33:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 02:33:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:33:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 02:33:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 02:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 02:37:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 02:37:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 02:37:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 02:37:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 02:37:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 02:37:42 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 02:37:42 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 02:37:42 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 02:37:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:38:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 02:38:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 02:42:36 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 02:42:36 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 02:42:36 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 02:42:36 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 02:42:36 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 02:42:36 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 02:43:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:56:19 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-09-17 02:56:19 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-09-17 02:56:19 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-09-17 02:56:20 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-17 02:56:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:56:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:56:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:56:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 02:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 03:01:54 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-09-17 03:01:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-09-17 03:02:01 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 03:02:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-17 03:02:09 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-17 03:02:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-17 03:02:09 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-17 03:02:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-17 03:02:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 03:02:14 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-17 03:02:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-17 03:02:14 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-17 03:02:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-17 03:02:19 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas029.php 172
ERROR - 2015-09-17 03:02:19 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-09-17 03:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 101
ERROR - 2015-09-17 03:02:19 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 151
ERROR - 2015-09-17 03:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas029.php 151
ERROR - 2015-09-17 03:13:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 03:13:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 03:15:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 03:18:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 03:19:01 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-17 03:19:01 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-17 03:19:01 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-17 03:19:03 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-17 04:38:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 04:39:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 05:37:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 05:37:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 05:37:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 05:37:28 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 05:37:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 05:37:28 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 05:37:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 05:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-17 05:40:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 54
ERROR - 2015-09-17 05:40:20 --> 404 Page Not Found --> assets
ERROR - 2015-09-17 05:50:11 --> 404 Page Not Found --> assets
ERROR - 2015-09-17 06:14:21 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 87
ERROR - 2015-09-17 06:14:28 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 87
ERROR - 2015-09-17 06:18:53 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 87
ERROR - 2015-09-17 08:59:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 08:59:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-17 17:07:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 19:01:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 20:28:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 20:37:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 20:37:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 20:50:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:46:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:46:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:53:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:53:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:54:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:54:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:55:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-17 21:56:07 --> 404 Page Not Found --> favicon.ico
