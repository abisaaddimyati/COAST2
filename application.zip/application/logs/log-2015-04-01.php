<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-01 01:35:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 01:35:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 01:36:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 01:36:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-04-01 01:36:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-04-01 01:36:53 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-04-01 01:36:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-04-01 01:36:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-04-01 01:49:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 01:49:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 01:50:27 --> 404 Page Not Found --> c_oas070
ERROR - 2015-04-01 01:50:40 --> Severity: Warning  --> Missing argument 1 for C_OAS030::load_view() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas030.php 36
ERROR - 2015-04-01 01:50:40 --> Severity: Notice  --> Undefined variable: id /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas030.php 39
ERROR - 2015-04-01 01:51:10 --> Query error: Table 'cybertr5_intranet.tb_r_pr' doesn't exist
ERROR - 2015-04-01 01:51:55 --> Severity: Warning  --> Missing argument 1 for C_OAS030::load_view() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas030.php 36
ERROR - 2015-04-01 01:51:55 --> Severity: Notice  --> Undefined variable: id /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas030.php 39
ERROR - 2015-04-01 01:55:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-01 01:55:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-01 02:07:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 02:11:29 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-04-01 02:11:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-04-01 02:11:29 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-04-01 02:11:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-04-01 02:38:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-04-01 02:38:23 --> 404 Page Not Found --> c_oas091
ERROR - 2015-04-01 02:38:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-04-01 02:38:50 --> 404 Page Not Found --> c_oas091
ERROR - 2015-04-01 02:39:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-04-01 02:39:53 --> 404 Page Not Found --> c_oas091
ERROR - 2015-04-01 02:43:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-04-01 02:44:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-04-01 02:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-01 02:45:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-01 03:42:37 --> Query error: Table 'cybertr5_intranet.tb_r_vendor' doesn't exist
ERROR - 2015-04-01 03:46:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 03:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 03:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 03:46:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 03:46:29 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 03:46:29 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 03:46:33 --> 404 Page Not Found --> images
ERROR - 2015-04-01 03:57:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 03:57:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 03:57:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 03:57:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 03:57:25 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 03:57:25 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 03:57:31 --> 404 Page Not Found --> images
ERROR - 2015-04-01 04:06:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas106.php 57
ERROR - 2015-04-01 04:14:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 04:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 04:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 04:14:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 04:14:01 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 04:14:02 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 04:14:08 --> 404 Page Not Found --> images
ERROR - 2015-04-01 04:14:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 04:14:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 04:14:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 04:14:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 04:14:20 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 04:14:20 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 04:14:27 --> 404 Page Not Found --> images
ERROR - 2015-04-01 04:20:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 04:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 04:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 04:20:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 04:20:35 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 04:22:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 04:22:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 04:22:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 04:22:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 04:22:03 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 04:22:15 --> 404 Page Not Found --> images
ERROR - 2015-04-01 04:22:27 --> Query error: Table 'cybertr5_intranet.documment' doesn't exist
ERROR - 2015-04-01 06:53:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 06:53:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 06:53:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 06:53:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 06:53:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 06:53:32 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 06:53:34 --> 404 Page Not Found --> images
ERROR - 2015-04-01 06:59:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 06:59:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 06:59:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 06:59:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 06:59:45 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 06:59:49 --> 404 Page Not Found --> images
ERROR - 2015-04-01 06:59:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 06:59:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 06:59:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 06:59:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 06:59:56 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 06:59:59 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:00:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:00:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 07:00:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:00:04 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:00:16 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:00:19 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:00:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:00:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 07:00:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:00:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:00:25 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:00:28 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:00:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 07:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:00:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:00:37 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:00:41 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:02:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:02:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 473
ERROR - 2015-04-01 07:02:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:02:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:02:46 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:03:07 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:04:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:04:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:04:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:04:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:04:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:04:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:04:34 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:04:36 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:04:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:04:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 492
ERROR - 2015-04-01 07:04:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:04:46 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:04:48 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:10:47 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:10:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 07:10:47 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 07:10:47 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:10:48 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:10:51 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:11:02 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 07:11:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 07:11:02 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 07:11:02 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 07:11:03 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 07:11:05 --> 404 Page Not Found --> images
ERROR - 2015-04-01 07:15:28 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 07:16:58 --> Query error: Unknown column 'fs.REMARKS_GR' in 'field list'
ERROR - 2015-04-01 07:37:21 --> Query error: Table 'cybertr5_intranet.DOCUMMENT' doesn't exist
ERROR - 2015-04-01 07:52:19 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 07:56:24 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-04-01 07:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-04-01 07:56:24 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-04-01 07:56:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-04-01 07:56:33 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-04-01 07:56:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-04-01 07:56:33 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-04-01 07:56:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-04-01 07:57:03 --> Unable to load the requested class: fpdf
ERROR - 2015-04-01 08:00:53 --> Severity: Warning  --> include(helveticab.php): failed to open stream: No such file or directory /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/libraries/fpdf.php 1145
ERROR - 2015-04-01 08:00:53 --> Severity: Warning  --> include(helveticab.php): failed to open stream: No such file or directory /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/libraries/fpdf.php 1145
ERROR - 2015-04-01 08:00:53 --> Severity: Warning  --> include(): Failed opening 'helveticab.php' for inclusion (include_path='.:/usr/php/54/usr/lib64:/usr/php/54/usr/share/pear') /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/libraries/fpdf.php 1145
ERROR - 2015-04-01 08:02:49 --> Severity: Warning  --> include(helveticab.php): failed to open stream: No such file or directory /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/libraries/fpdf.php 1145
ERROR - 2015-04-01 08:02:49 --> Severity: Warning  --> include(helveticab.php): failed to open stream: No such file or directory /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/libraries/fpdf.php 1145
ERROR - 2015-04-01 08:02:49 --> Severity: Warning  --> include(): Failed opening 'helveticab.php' for inclusion (include_path='.:/usr/php/54/usr/lib64:/usr/php/54/usr/share/pear') /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/libraries/fpdf.php 1145
ERROR - 2015-04-01 09:00:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 09:00:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 09:50:46 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 31
ERROR - 2015-04-01 09:50:46 --> Severity: Notice  --> Undefined variable: employees /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 09:50:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 09:50:46 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 76
ERROR - 2015-04-01 09:51:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 09:52:55 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 09:53:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 09:53:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 09:53:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 09:53:18 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 09:53:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 09:53:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 09:53:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 09:58:00 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 50
ERROR - 2015-04-01 09:58:00 --> Severity: Notice  --> Undefined variable: detail_akun /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 56
ERROR - 2015-04-01 09:58:00 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 70
ERROR - 2015-04-01 09:58:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-01 10:05:57 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 10:07:09 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:07:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 10:07:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 10:22:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:22:26 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:22:26 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:22:26 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:22:26 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:22:26 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:23:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:23:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:23:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:23:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:25:06 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:32:37 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:32:37 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:32:37 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:32:37 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:32:37 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:32:37 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:32:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:35:12 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:36:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:36:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:36:51 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:36:51 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:36:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:36:51 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:37:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:38:25 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:38:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:38:25 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:38:25 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:38:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:38:25 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:39:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:39:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:39:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:39:18 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:39:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:39:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:40:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:40:11 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:40:11 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:40:11 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:40:11 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:40:11 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:41:30 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:41:30 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:41:30 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:41:30 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:41:30 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:41:30 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:43:16 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:43:16 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:43:16 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:43:16 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:43:16 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:43:16 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:43:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:44:41 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 10:45:11 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:45:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 10:45:41 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:45:41 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:45:41 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:45:41 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:45:41 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:45:41 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:46:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 10:46:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:46:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:46:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:46:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 10:46:27 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 10:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:46:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:47:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 10:47:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:47:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:47:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:47:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 10:47:07 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 10:47:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-01 10:47:10 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-01 10:47:10 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-01 10:47:10 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-01 10:47:10 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-01 10:47:10 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-01 10:47:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:47:27 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 10:47:27 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:47:27 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:47:27 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:47:27 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 10:47:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-04-01 10:47:28 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 10:50:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 10:50:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:50:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:50:06 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 10:50:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 10:50:08 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 10:52:56 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:52:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1,
						   'user: winy337@yahoo.com',
						   '2015-04-01 23:52:59')' at line 17
ERROR - 2015-04-01 10:53:10 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:53:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1,
						   'user: winy337@yahoo.com',
						   '2015-04-01 23:53:12')' at line 17
ERROR - 2015-04-01 10:53:24 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:53:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1,
						   'user: winy337@yahoo.com',
						   '2015-04-01 23:53:27')' at line 17
ERROR - 2015-04-01 10:53:34 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 372
ERROR - 2015-04-01 10:53:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1,
						   'user: winy337@yahoo.com',
						   '2015-04-01 23:53:36')' at line 17
ERROR - 2015-04-01 10:57:07 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 31
ERROR - 2015-04-01 10:57:07 --> Severity: Notice  --> Undefined variable: employees /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 10:57:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 10:57:07 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 76
ERROR - 2015-04-01 11:03:08 --> Severity: Notice  --> Undefined index: EMPLOYEE_EMAIL /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas075.php 211
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:11:24 --> Severity: Notice  --> Undefined property: c_oas076::$member_model /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 202
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 11:12:36 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 11:17:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 11:17:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:17:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:17:21 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:17:21 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 11:17:21 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:17:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 11:17:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:17:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:17:42 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:17:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 11:17:42 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:20:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 11:20:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 11:20:07 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:20:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 11:20:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:23 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 11:20:23 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:20:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 11:20:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:20:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 11:20:30 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:21:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 11:21:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:21:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:21:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 11:21:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 11:21:29 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:28:15 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 31
ERROR - 2015-04-01 11:28:15 --> Severity: Notice  --> Undefined variable: employees /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 11:28:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 11:28:15 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 76
ERROR - 2015-04-01 11:28:38 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 31
ERROR - 2015-04-01 11:28:38 --> Severity: Notice  --> Undefined variable: employees /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 11:28:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 40
ERROR - 2015-04-01 11:28:38 --> Severity: Notice  --> Undefined variable: approval /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas030.php 76
ERROR - 2015-04-01 11:37:13 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:40:18 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 11:40:37 --> Severity: Notice  --> Undefined index: EMPLOYEE_EMAIL /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas075.php 211
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 11:41:47 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 11:46:29 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 12:06:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 12:06:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 12:07:07 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 12:11:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 12:12:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-04-01 12:12:07 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:13:08 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:13:08 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:08 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:08 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:08 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:13:09 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:13:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:13:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:13:26 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:13:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:13:41 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:41 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:41 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:13:42 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:13:58 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:13:58 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:58 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:58 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:13:58 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:13:59 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:14:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:14:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:14:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:14:55 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:14:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:14:56 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:17:18 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:17:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:17:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:17:18 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:17:18 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:17:19 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:17:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:17:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:17:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:17:37 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:17:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:17:38 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:18:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 12:18:32 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:18:32 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:18:32 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 12:18:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 12:18:33 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:18:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 12:18:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 12:21:05 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 12:21:22 --> Severity: Notice  --> Undefined index: EMPLOYEE_EMAIL /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas075.php 211
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 12:22:01 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 14:26:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 14:29:59 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 14:34:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 14:34:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 14:47:57 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 14:48:41 --> Severity: Notice  --> Undefined index: REQNAME /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas038.php 346
ERROR - 2015-04-01 14:49:47 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-01 15:14:32 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 15:14:38 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 15:16:52 --> 404 Page Not Found --> OAS
ERROR - 2015-04-01 15:18:32 --> 404 Page Not Found --> OAS
ERROR - 2015-04-01 15:18:47 --> 404 Page Not Found --> OAS
ERROR - 2015-04-01 15:25:48 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-04-01 15:25:48 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-04-01 15:25:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-04-01 15:25:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-01 15:30:25 --> Severity: Notice  --> Undefined index: type_id /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 361
ERROR - 2015-04-01 15:30:26 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 17:51:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 19:09:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 19:19:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 19:19:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 19:19:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 19:19:45 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 19:19:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 19:19:47 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 19:20:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-04-01 19:20:11 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 19:20:11 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 19:20:11 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 493
ERROR - 2015-04-01 19:20:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 579
ERROR - 2015-04-01 19:20:12 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 20:21:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 20:22:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 20:24:41 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 21:00:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 21:09:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 21:09:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 21:13:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 21:49:52 --> Query error: Table 'cybertr5_intranet.DOCUMMENT' doesn't exist
ERROR - 2015-04-01 21:53:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 21:53:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 21:54:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 135
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 138
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 143
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 146
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 151
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 154
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 159
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 162
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 167
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 170
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 175
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 178
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 186
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 215
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 270
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 22:01:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 283
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 216
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 216
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 216
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 216
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 220
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 220
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 220
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 220
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 224
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 224
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 224
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 224
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 271
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 271
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 284
ERROR - 2015-04-01 22:04:48 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 284
ERROR - 2015-04-01 22:06:09 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 272
ERROR - 2015-04-01 22:06:09 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 272
ERROR - 2015-04-01 22:06:09 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 285
ERROR - 2015-04-01 22:06:09 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 285
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 273
ERROR - 2015-04-01 22:07:32 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 286
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 120
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 120
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 123
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 123
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 128
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 128
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 131
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 131
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 136
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 136
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 139
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 139
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 144
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 144
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 147
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 147
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 152
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 152
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 155
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 155
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 160
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 160
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 163
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 163
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 171
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 171
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 200
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 200
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 200
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 200
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 204
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 204
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 204
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 204
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 208
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 208
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 208
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 208
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 255
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 255
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 268
ERROR - 2015-04-01 22:53:28 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 268
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 141
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 141
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 144
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 144
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 149
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 149
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 152
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 152
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 157
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 157
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 160
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 160
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 165
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 165
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 168
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 168
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 173
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 173
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 176
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 176
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 181
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 181
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 184
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 184
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 192
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 192
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 22:57:57 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 141
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 141
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 144
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 144
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 149
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 149
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 152
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 152
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 157
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 157
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 160
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 160
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 165
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 165
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 168
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 168
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 173
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 173
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 176
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 176
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 181
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 181
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 184
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 184
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 192
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 192
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 221
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 225
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 229
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 22:58:22 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 23:01:26 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 254
ERROR - 2015-04-01 23:01:26 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 254
ERROR - 2015-04-01 23:01:26 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 267
ERROR - 2015-04-01 23:01:26 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 267
ERROR - 2015-04-01 23:16:44 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 254
ERROR - 2015-04-01 23:16:44 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 254
ERROR - 2015-04-01 23:16:44 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 267
ERROR - 2015-04-01 23:16:44 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 267
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 139
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 139
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 142
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 142
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 147
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 147
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 150
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 150
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 155
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 155
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 158
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 158
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 163
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 163
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 166
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 166
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 171
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 171
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 174
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 174
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 179
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 179
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 182
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 182
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 190
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 190
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 274
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 274
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 287
ERROR - 2015-04-01 23:19:11 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 287
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 219
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 223
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: column /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 227
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 274
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 274
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 287
ERROR - 2015-04-01 23:21:18 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 287
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:23:13 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 23:24:00 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 254
ERROR - 2015-04-01 23:24:00 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 254
ERROR - 2015-04-01 23:24:00 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 267
ERROR - 2015-04-01 23:24:00 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 267
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:37 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 277
ERROR - 2015-04-01 23:24:52 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 290
ERROR - 2015-04-01 23:25:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:25:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:25:24 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 23:25:24 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 23:25:27 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:25:27 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 276
ERROR - 2015-04-01 23:25:27 --> Severity: Notice  --> Undefined variable: data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 23:25:27 --> Severity: Notice  --> Trying to get property of non-object /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas076.php 289
ERROR - 2015-04-01 23:26:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-04-01 23:26:20 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 23:35:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-04-01 23:35:42 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 23:37:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:40:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:41:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:41:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-04-01 23:41:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:41:28 --> 404 Page Not Found --> assets
ERROR - 2015-04-01 23:41:32 --> 404 Page Not Found --> c_oas071/load_view
ERROR - 2015-04-01 23:41:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:42:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:42:51 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-01 23:42:52 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-01 23:43:46 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-01 23:43:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:43:47 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-01 23:45:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:55:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-01 23:55:07 --> 404 Page Not Found --> favicon.ico
