<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-21 23:30:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-21 23:30:44 --> 404 Page Not Found --> favicon.ico
