<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-09 00:04:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-09 03:59:57 --> 404 Page Not Found --> favicon.ico
