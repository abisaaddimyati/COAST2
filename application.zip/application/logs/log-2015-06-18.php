<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-18 20:19:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-18 20:19:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-18 22:12:59 --> 404 Page Not Found --> favicon.ico
