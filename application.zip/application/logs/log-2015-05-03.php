<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-03 01:07:38 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-03 02:47:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 07:37:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 07:42:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 07:42:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 08:05:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 17:21:37 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-03 18:48:30 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-03 18:48:30 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-03 20:19:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 20:19:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 20:43:34 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-05-03 21:40:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 21:45:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 21:45:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-03 22:16:13 --> 404 Page Not Found --> favicon.ico
