<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-21 00:08:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 00:16:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 00:16:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 00:16:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 00:16:02 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 00:16:55 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 00:16:57 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 00:28:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:28:03 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:28:03 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:28:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:28:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:28:44 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:30:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:30:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:30:22 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:35:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:35:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:35:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:36:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:36:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:36:47 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:37:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:37:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:37:08 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:38:02 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 296
ERROR - 2015-10-21 00:38:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:38:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:38:13 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:41:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 00:41:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 00:41:19 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:41:29 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:44:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 00:44:42 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:46:40 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 00:47:01 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 01:00:39 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 01:00:47 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 01:01:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 01:01:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 01:01:11 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 01:01:28 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 01:07:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 01:07:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 01:09:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 01:09:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 01:10:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 01:17:16 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 01:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 01:17:16 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 01:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 01:19:40 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 01:20:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 01:56:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 02:01:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 02:01:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 02:23:01 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 02:25:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 02:25:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 02:49:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 02:49:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 02:49:49 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 03:00:06 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 03:02:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 03:02:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 03:02:46 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 03:05:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 296
ERROR - 2015-10-21 03:05:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-21 03:05:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 636
ERROR - 2015-10-21 03:05:58 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 03:24:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 03:48:17 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 04:36:03 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 06:46:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 07:03:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-21 07:03:08 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-21 07:03:08 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-21 07:03:08 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-21 07:03:08 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-21 07:03:08 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-21 07:27:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 15:59:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 15:59:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 19:26:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 19:26:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 19:26:31 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 19:26:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 19:27:01 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:27:07 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:27:10 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:27:14 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:27:20 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:27:28 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:27:30 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:28:22 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:28:55 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:29:04 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 19:33:22 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 19:33:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 19:33:22 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 19:33:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 20:17:49 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:17:49 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 20:17:49 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:17:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:18:06 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 20:26:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:26:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 20:26:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:26:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:26:18 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 20:27:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 20:27:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 20:27:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:27:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 20:27:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:27:50 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:28:08 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 20:28:26 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 20:28:53 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 20:28:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 20:28:53 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 20:28:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 20:30:19 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 20:30:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-21 20:30:19 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 20:30:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-21 20:31:19 --> 404 Page Not Found --> assets
ERROR - 2015-10-21 20:41:20 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:41:20 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 20:41:20 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:41:21 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:41:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:41:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 20:41:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:41:26 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:50:39 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-21 20:50:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-10-21 20:50:39 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-21 20:50:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-21 20:50:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 428
ERROR - 2015-10-21 20:50:50 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 431
ERROR - 2015-10-21 20:50:50 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-21 20:52:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 428
ERROR - 2015-10-21 20:52:39 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 431
ERROR - 2015-10-21 20:52:39 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 20:55:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 20:58:37 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-10-21 20:58:37 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-10-21 20:58:37 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-10-21 20:58:37 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-10-21 20:58:37 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-10-21 20:58:37 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-10-21 21:00:21 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 466
ERROR - 2015-10-21 21:00:21 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 470
ERROR - 2015-10-21 21:00:21 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 471
ERROR - 2015-10-21 21:01:40 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 240
ERROR - 2015-10-21 21:01:40 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 244
ERROR - 2015-10-21 21:01:40 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 245
ERROR - 2015-10-21 21:02:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 489
ERROR - 2015-10-21 21:02:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 493
ERROR - 2015-10-21 21:02:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 494
ERROR - 2015-10-21 21:02:32 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 494
ERROR - 2015-10-21 21:03:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 21:03:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 21:06:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 21:06:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 21:06:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 21:06:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 21:06:34 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 21:06:48 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-21 21:09:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 21:18:42 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-10-21 21:18:42 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-10-21 21:18:42 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-10-21 21:18:42 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-10-21 21:18:42 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-10-21 21:18:42 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-10-21 21:19:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 489
ERROR - 2015-10-21 21:19:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 493
ERROR - 2015-10-21 21:19:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 494
ERROR - 2015-10-21 21:19:30 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 494
ERROR - 2015-10-21 22:19:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 22:50:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 22:50:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-21 22:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-21 22:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-21 22:50:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-21 22:50:38 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-21 23:56:49 --> 404 Page Not Found --> assets
