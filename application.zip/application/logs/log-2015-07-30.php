<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-30 09:49:17 --> 404 Page Not Found --> favicon.ico
