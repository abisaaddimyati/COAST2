<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-11 21:23:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-11 21:23:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-11 21:44:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-11 21:44:50 --> 404 Page Not Found --> favicon.ico
