<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-24 21:17:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-24 21:17:36 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-10-24 21:17:36 --> 404 Page Not Found --> apple-touch-icon.png
