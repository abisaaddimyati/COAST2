<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-08 03:25:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-08 03:25:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-08 08:04:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-08 08:04:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-08 08:04:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-08 22:13:07 --> 404 Page Not Found --> favicon.ico
