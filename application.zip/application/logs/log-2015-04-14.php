<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-14 06:00:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 06:00:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 06:01:12 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-14 07:51:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 07:51:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 19:25:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 19:43:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 20:12:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 20:13:08 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-14 20:16:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-14 20:16:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-14 20:16:02 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-14 20:16:08 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-14 20:16:55 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-04-14 20:19:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-14 20:19:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-14 20:19:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-14 20:20:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-14 20:20:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-14 20:20:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-14 20:20:21 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-14 20:20:37 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-04-14 20:21:21 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-14 20:21:21 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-14 20:21:21 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-14 20:21:23 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-14 20:21:41 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-04-14 20:22:14 --> Query error: Duplicate entry '2-4' for key 'PRIMARY'
ERROR - 2015-04-14 20:22:18 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-04-14 20:22:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-14 20:22:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-14 20:22:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-14 20:22:47 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-14 20:23:06 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-04-14 20:23:55 --> Query error: Duplicate entry '3-3' for key 'PRIMARY'
ERROR - 2015-04-14 20:23:58 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-04-14 20:27:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-14 20:28:44 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-14 20:29:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-14 20:29:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-14 20:29:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-14 20:29:00 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-14 20:29:13 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-04-14 21:50:07 --> 404 Page Not Found --> favicon.ico
