<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-03 02:16:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-03 02:16:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-03 22:54:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-03 22:55:32 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-03 22:55:32 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-03 22:55:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-03 22:55:32 --> 404 Page Not Found --> jquery.js
