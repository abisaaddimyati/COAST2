<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-07 00:28:38 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-07 00:52:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 00:52:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 01:06:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 01:06:36 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 01:07:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 01:07:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 01:07:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 01:07:08 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 01:07:20 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 01:34:27 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-07 01:36:07 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-07 01:49:51 --> Severity: Notice  --> Undefined variable: item_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-09-07 01:49:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas090.php 57
ERROR - 2015-09-07 01:56:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 01:56:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 01:56:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 01:56:26 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 01:56:26 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 01:56:27 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 03:03:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 03:10:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 03:10:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 03:16:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 03:16:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 05:30:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 11:17:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 11:17:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 11:19:29 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-07 11:19:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-07 11:19:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-07 11:19:29 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-07 11:19:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-07 11:19:29 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-07 20:22:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 20:22:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 20:37:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 20:38:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 20:38:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 20:39:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 20:41:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:41:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 20:41:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:41:54 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:42:13 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-09-07 20:44:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:44:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 20:44:00 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:44:00 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:47:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:47:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 20:47:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:47:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:48:29 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:48:29 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 20:48:29 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:48:30 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:48:43 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-09-07 20:49:55 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-09-07 20:55:49 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-09-07 20:56:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:56:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 20:56:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:56:07 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:57:43 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined index: posid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 214
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-09-07 20:58:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 414
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 417
ERROR - 2015-09-07 20:58:01 --> Severity: Notice  --> Undefined variable: detail_ga2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 692
ERROR - 2015-09-07 20:58:01 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:58:19 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-07 20:58:19 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-07 20:58:19 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-07 20:58:19 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-07 20:58:28 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-09-07 21:01:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:01:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:01:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:01:05 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:01:05 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:01:06 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:01:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:01:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:01:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:01:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:01:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:01:47 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:04:49 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-07 21:05:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:05:00 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:05:00 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:05:00 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:05:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:05:02 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:05:26 --> 404 Page Not Found --> OAS
ERROR - 2015-09-07 21:11:37 --> 404 Page Not Found --> OAS
ERROR - 2015-09-07 21:14:27 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:15:06 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:16:56 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:18:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:18:00 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:18:00 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:18:00 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:18:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:18:00 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:21:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:21:28 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:21:28 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:21:28 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:21:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:21:28 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:21:50 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:21:50 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:21:50 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:21:50 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:21:50 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:21:50 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:23:56 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-07 21:24:51 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-07 21:24:57 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-07 21:25:28 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 287
ERROR - 2015-09-07 21:25:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-07 21:25:33 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:25:33 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:25:33 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-07 21:25:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-07 21:25:33 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:25:43 --> 404 Page Not Found --> OAS
ERROR - 2015-09-07 21:29:06 --> 404 Page Not Found --> assets
ERROR - 2015-09-07 21:41:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:43:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:43:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:44:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:45:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:46:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:47:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:47:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:47:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:52:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:53:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:54:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:54:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 21:54:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 22:31:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 22:37:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-07 22:37:33 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-07 22:37:33 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-07 22:37:33 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-07 22:37:33 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-07 22:37:33 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-07 22:37:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-07 22:44:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-07 22:45:23 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 177
ERROR - 2015-09-07 22:48:14 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 377
ERROR - 2015-09-07 22:50:00 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 377
