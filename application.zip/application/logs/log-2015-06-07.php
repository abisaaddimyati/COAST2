<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-07 09:06:39 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-07 21:07:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-07 21:50:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-07 21:50:32 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-06-07 21:50:32 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-06-07 23:04:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-07 23:04:55 --> 404 Page Not Found --> favicon.ico
