<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-07 00:19:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-07 22:08:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-07 22:08:14 --> 404 Page Not Found --> favicon.ico
