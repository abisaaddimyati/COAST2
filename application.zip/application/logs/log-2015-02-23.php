<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-23 01:17:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 01:17:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 01:18:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 01:18:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 01:20:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 01:24:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 01:24:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 05:14:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 05:14:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 05:14:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 05:34:43 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-02-23 05:42:27 --> 404 Page Not Found --> jquery.js
ERROR - 2015-02-23 05:44:23 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-02-23 19:37:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 19:37:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-23 21:09:49 --> Severity: Notice  --> Undefined variable: destination_list /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas063.php 57
ERROR - 2015-02-23 21:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas063.php 57
