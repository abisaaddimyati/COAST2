<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-25 23:10:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-25 23:10:44 --> 404 Page Not Found --> favicon.ico
