<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-07 06:56:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-07 21:57:54 --> 404 Page Not Found --> favicon.ico
