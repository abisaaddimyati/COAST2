<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-15 00:07:46 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-15 00:07:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-15 00:07:46 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-15 00:07:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-15 00:15:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 00:15:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 01:11:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 01:11:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 01:52:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 01:52:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 02:18:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 02:18:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 03:52:03 --> 404 Page Not Found --> login
ERROR - 2015-10-15 03:52:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 03:52:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 03:55:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-15 03:55:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-15 03:55:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-15 03:55:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-15 03:56:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-15 03:56:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-15 03:56:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-15 03:56:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-15 03:58:17 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-15 04:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 428
ERROR - 2015-10-15 04:14:00 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 431
ERROR - 2015-10-15 04:14:01 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-15 04:15:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 428
ERROR - 2015-10-15 04:15:09 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 431
ERROR - 2015-10-15 04:15:09 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-15 10:42:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 19:20:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 20:48:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 20:48:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 20:54:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 23:38:45 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-15 23:38:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-15 23:38:45 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-15 23:38:46 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-15 23:38:47 --> 404 Page Not Found --> apple-touch-icon.png
