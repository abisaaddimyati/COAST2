<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-16 22:26:42 --> 404 Page Not Found --> favicon.ico
