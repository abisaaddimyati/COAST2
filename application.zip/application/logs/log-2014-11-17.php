<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-17 18:51:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-17 18:51:26 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-11-17 18:51:26 --> 404 Page Not Found --> apple-touch-icon.png
