<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-03 15:27:37 --> Severity: Notice  --> Undefined variable: list_division C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 15:27:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 15:27:46 --> Severity: Notice  --> Undefined variable: list_division C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 15:27:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 15:27:46 --> Severity: Notice  --> Undefined variable: list_division C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 15:27:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 15:56:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\controllers\c_oas020.php 69
ERROR - 2014-09-03 16:09:10 --> Severity: Notice  --> Undefined variable: list_division C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 16:09:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 16:51:02 --> Severity: Notice  --> Undefined variable: list_division C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 16:51:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\views\v_oas015.php 102
ERROR - 2014-09-03 16:53:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\OAS\application\controllers\c_oas020.php 69
ERROR - 2014-09-03 17:27:53 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\xampp\htdocs\OAS\system\database\drivers\mysql\mysql_driver.php 91
