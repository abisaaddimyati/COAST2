<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-10 05:58:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-10 05:58:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-10 05:58:54 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-10 08:12:11 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-10 08:12:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-10 08:12:11 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-10 16:53:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-10 19:57:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-10 23:36:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-10 23:37:04 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-05-10 23:44:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-10 23:45:02 --> 404 Page Not Found --> favicon.ico
