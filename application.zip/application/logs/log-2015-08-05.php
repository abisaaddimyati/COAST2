<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-05 22:33:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-05 22:34:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-05 22:48:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-05 22:48:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-05 23:40:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-05 23:56:49 --> 404 Page Not Found --> favicon.ico
