<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-19 01:13:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-19 01:14:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-08-19 01:14:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-08-19 01:14:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-08-19 01:14:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-08-19 01:15:19 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:15:48 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:15:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:16:17 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:16:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:19:42 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:19:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-19 01:29:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-08-19 01:29:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-08-19 03:14:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-19 03:14:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-19 19:52:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-19 19:52:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-19 20:01:15 --> 404 Page Not Found --> favicon.ico
