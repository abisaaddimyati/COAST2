<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-10 07:04:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-10 07:42:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-10 17:29:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-10 22:46:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-10 23:08:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-10 23:08:34 --> 404 Page Not Found --> favicon.ico
