<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-19 01:25:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 01:25:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 21:27:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 21:31:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 21:31:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 22:53:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 22:53:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-19 23:02:41 --> 404 Page Not Found --> jquery.js
