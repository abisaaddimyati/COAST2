<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-12 04:13:05 --> 404 Page Not Found --> robots.txt
ERROR - 2015-07-12 20:17:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-12 20:17:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-12 21:09:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-12 21:09:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-12 21:14:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-12 21:14:49 --> 404 Page Not Found --> favicon.ico
