<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-17 03:33:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 03:33:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 18:48:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 18:48:14 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-03-17 18:48:15 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-03-17 19:19:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 21:01:40 --> 404 Page Not Found --> 6_S3_
ERROR - 2015-03-17 21:01:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 21:12:56 --> 404 Page Not Found --> 6_S3_
ERROR - 2015-03-17 21:14:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 21:16:14 --> 404 Page Not Found --> 6_S3_
ERROR - 2015-03-17 21:17:08 --> 404 Page Not Found --> 6_S3_
ERROR - 2015-03-17 21:22:12 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-17 21:22:46 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2015-03-17 22:04:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 22:04:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 22:18:07 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-17 22:18:07 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-17 22:18:07 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-17 22:18:07 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-17 22:18:07 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-17 22:18:07 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-17 22:18:21 --> Query error: Unknown column 'usr.SHOW_EXPENSE_INFORMATION' in 'field list'
ERROR - 2015-03-17 22:19:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 22:19:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-17 22:20:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-17 22:20:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-17 22:20:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-17 22:20:54 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-17 22:20:54 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-17 22:20:54 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-17 22:52:51 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-17 23:55:22 --> 404 Page Not Found --> favicon.ico
