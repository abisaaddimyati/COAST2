<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-20 02:47:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-20 04:14:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-20 04:14:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-20 22:33:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-20 22:33:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-20 22:33:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-20 22:33:07 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-20 22:33:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-20 22:33:08 --> 404 Page Not Found --> assets
