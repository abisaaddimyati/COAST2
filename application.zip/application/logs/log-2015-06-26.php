<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-26 12:48:03 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-26 19:47:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-26 19:47:10 --> 404 Page Not Found --> favicon.ico
