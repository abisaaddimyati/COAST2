<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-06 00:28:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 00:28:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 01:51:27 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-11-06 01:53:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 01:53:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 01:53:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-06 01:53:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-06 01:53:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-06 01:53:59 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 01:55:01 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-06 01:57:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-06 01:57:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-06 01:57:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-06 01:57:26 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:20:55 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-06 02:20:55 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-06 02:20:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-06 02:20:55 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:26:10 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-06 02:26:10 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-06 02:26:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-06 02:26:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:28:01 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-06 02:28:01 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-06 02:28:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-06 02:28:01 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:28:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 02:28:30 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-06 02:28:30 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-06 02:28:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-06 02:28:30 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:30:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-06 02:30:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-06 02:30:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-06 02:30:03 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:30:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-06 02:30:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-06 02:30:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-06 02:30:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:38:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 02:38:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 02:38:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-06 02:38:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-06 02:38:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-06 02:38:48 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-06 02:38:50 --> 404 Page Not Found --> robots.txt
ERROR - 2015-11-06 02:38:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-06 02:38:56 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-06 02:38:56 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-06 02:38:56 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-06 02:38:56 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-06 02:38:56 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-06 02:39:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-06 02:39:22 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-06 02:41:38 --> Severity: Warning  --> Missing argument 2 for C_OAS025::load_form() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas025.php 39
ERROR - 2015-11-06 02:41:38 --> Severity: Notice  --> Undefined variable: tipe_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas025.php 41
ERROR - 2015-11-06 02:55:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:01:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:06:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:06:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:18:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 03:20:41 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 282
ERROR - 2015-11-06 03:20:41 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 286
ERROR - 2015-11-06 03:20:41 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 287
ERROR - 2015-11-06 03:20:41 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 365
ERROR - 2015-11-06 03:20:41 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 369
ERROR - 2015-11-06 03:20:41 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 370
ERROR - 2015-11-06 09:44:54 --> 404 Page Not Found --> robots.txt
ERROR - 2015-11-06 09:44:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-06 10:42:51 --> 404 Page Not Found --> favicon.ico
