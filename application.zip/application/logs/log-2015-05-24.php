<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-24 23:32:12 --> 404 Page Not Found --> favicon.ico
