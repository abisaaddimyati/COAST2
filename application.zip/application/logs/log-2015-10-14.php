<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-14 11:21:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 19:06:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 19:58:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 19:58:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 19:58:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 19:58:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 20:17:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 20:18:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 20:18:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-10-14 20:18:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-10-14 20:59:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 21:04:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 21:04:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 21:10:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-14 21:10:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-14 21:10:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-14 21:10:33 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-14 21:10:45 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-14 21:10:45 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-14 21:10:45 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-14 21:10:45 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-14 21:10:45 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-14 21:10:45 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-14 21:11:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-14 21:11:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-14 21:11:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-14 21:11:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-14 21:27:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas072.php 153
ERROR - 2015-10-14 22:20:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-14 22:22:11 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
