<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-02 05:11:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-02 20:02:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-02 20:02:23 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-08-02 20:02:23 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-08-02 22:20:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-02 22:22:39 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-02 22:22:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-08-02 22:47:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-02 22:47:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-02 23:44:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-02 23:44:06 --> 404 Page Not Found --> favicon.ico
