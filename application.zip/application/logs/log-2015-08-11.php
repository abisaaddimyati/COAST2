<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-11 00:03:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-11 16:34:55 --> 404 Page Not Found --> robots.txt
ERROR - 2015-08-11 21:04:59 --> 404 Page Not Found --> favicon.ico
