<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-25 02:24:22 --> 404 Page Not Found --> favicon.ico
