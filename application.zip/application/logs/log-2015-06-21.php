<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-21 18:46:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 18:46:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 18:49:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 18:49:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 18:49:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 18:49:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 20:01:05 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-21 22:17:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-21 22:17:40 --> 404 Page Not Found --> favicon.ico
