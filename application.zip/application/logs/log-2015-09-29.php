<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-29 04:09:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 04:41:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 08:05:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 08:05:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 08:06:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-29 08:06:50 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-29 08:06:50 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-29 08:06:50 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-29 08:06:50 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-29 08:06:50 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-29 17:58:21 --> 404 Page Not Found --> robots.txt
ERROR - 2015-09-29 17:58:21 --> 404 Page Not Found --> apple-app-site-association
ERROR - 2015-09-29 18:30:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 20:12:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 20:46:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 20:46:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 21:07:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 21:07:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 21:08:52 --> Severity: Notice  --> Undefined variable: tujuan /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas038.php 499
ERROR - 2015-09-29 21:08:52 --> Severity: Notice  --> Undefined variable: judul /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas038.php 499
ERROR - 2015-09-29 21:08:52 --> Severity: Notice  --> Undefined variable: isi /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas038.php 499
ERROR - 2015-09-29 21:08:52 --> Severity: Notice  --> Undefined variable: headers /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas038.php 499
ERROR - 2015-09-29 21:08:52 --> Severity: Notice  --> Undefined variable: tujuan /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas038.php 502
ERROR - 2015-09-29 21:09:13 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-29 21:09:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-09-29 21:09:13 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-29 21:09:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-09-29 21:09:16 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-09-29 21:09:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-09-29 21:09:16 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-09-29 21:09:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-09-29 21:09:22 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-09-29 21:09:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 103
ERROR - 2015-09-29 21:31:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-29 21:31:28 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-29 21:31:28 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-29 21:31:28 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-29 21:31:28 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-29 21:31:28 --> 404 Page Not Found --> assets
ERROR - 2015-09-29 22:43:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 22:43:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-29 22:45:06 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-29 22:45:06 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-29 22:45:29 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-29 22:45:29 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-29 23:19:31 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-29 23:19:31 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-29 23:27:51 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-29 23:27:51 --> Query error: Subquery returns more than 1 row
