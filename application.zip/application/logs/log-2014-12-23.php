<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-23 02:24:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 02:24:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 02:27:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 02:28:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 18:30:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 18:30:10 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-12-23 18:30:10 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2014-12-23 19:13:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 19:13:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 19:14:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-12-23 19:31:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 20:07:24 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-23 20:08:17 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2014-12-23 23:32:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 23:32:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-23 23:32:53 --> 404 Page Not Found --> favicon.ico
