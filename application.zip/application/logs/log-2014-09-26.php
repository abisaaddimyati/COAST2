<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-26 05:45:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-26 05:45:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-26 05:45:06 --> 404 Page Not Found --> favicon.ico
