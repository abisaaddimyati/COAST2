<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-28 00:53:09 --> 404 Page Not Found --> favicon.ico
