<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-21 10:46:45 --> 404 Page Not Found --> robots.txt
