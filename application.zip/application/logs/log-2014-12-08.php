<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-08 19:39:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-08 19:39:59 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-12-08 19:39:59 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2014-12-08 19:40:30 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2014-12-08 19:40:30 --> 404 Page Not Found --> apple-touch-icon.png
