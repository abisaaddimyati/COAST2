<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-17 00:38:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-17 02:49:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-17 02:49:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-17 07:30:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-17 07:45:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-17 07:51:15 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-06-17 07:51:15 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-06-17 07:51:15 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-06-17 07:51:15 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-06-17 07:51:15 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-06-17 07:51:15 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-06-17 07:51:36 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-06-17 07:51:36 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-06-17 07:51:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-06-17 07:51:37 --> 404 Page Not Found --> jquery.js
ERROR - 2015-06-17 10:16:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-17 11:00:53 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-17 11:00:53 --> 404 Page Not Found --> robots.txt
