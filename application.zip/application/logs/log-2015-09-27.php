<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-27 16:05:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 17:47:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 17:48:16 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-27 17:48:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-27 20:01:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:01:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:03:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:14:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:16:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-27 20:16:08 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-27 20:16:08 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-27 20:16:08 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-27 20:16:08 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-27 20:16:08 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-27 20:16:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-27 20:16:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:16:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-27 20:21:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:22:49 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-27 20:22:49 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-27 20:22:49 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-27 20:22:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-27 20:23:59 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-27 20:23:59 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-27 20:23:59 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-27 20:23:59 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-27 20:52:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:52:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 20:53:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-27 20:53:10 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-27 20:53:10 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-27 20:53:10 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-27 20:53:10 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-27 20:53:10 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-27 20:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-27 20:54:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-27 20:54:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-27 20:54:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-27 20:54:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-27 20:54:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-27 20:54:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-27 20:54:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-27 20:55:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 21:03:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 21:03:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 21:29:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-27 22:29:21 --> 404 Page Not Found --> OAS
ERROR - 2015-09-27 23:26:11 --> 404 Page Not Found --> OAS
