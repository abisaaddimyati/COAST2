<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-24 04:50:31 --> 404 Page Not Found --> robots.txt
ERROR - 2015-09-24 19:48:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 19:48:36 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-24 19:50:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 20:16:22 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-24 20:16:22 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-24 20:16:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-24 20:16:23 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-24 20:16:28 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-24 20:16:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-24 20:16:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-24 20:16:28 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-24 20:16:28 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-24 20:16:28 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-24 20:42:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 21:33:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 21:51:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 21:58:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 21:58:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 22:03:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-24 22:07:56 --> 404 Page Not Found --> intranet.cybertrend-intra.comc_oas020
ERROR - 2015-09-24 22:08:12 --> 404 Page Not Found --> intranet.cybertrend-intra.comc_oas020
