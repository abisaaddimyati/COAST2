<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-26 03:28:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-26 03:28:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-26 21:59:14 --> 404 Page Not Found --> favicon.ico
