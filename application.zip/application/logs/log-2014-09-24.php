<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-24 03:50:01 --> 404 Page Not Found --> favicon.ico
