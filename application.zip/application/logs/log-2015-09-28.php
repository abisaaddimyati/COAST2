<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-28 00:04:40 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 00:04:40 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 00:04:57 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 00:04:57 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 00:05:23 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 00:05:23 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 00:07:58 --> Query error: Duplicate entry '2-51' for key 'PRIMARY'
ERROR - 2015-09-28 00:08:03 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-09-28 00:10:17 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 00:10:17 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 00:12:31 --> Query error: Duplicate entry '2-51' for key 'PRIMARY'
ERROR - 2015-09-28 00:12:36 --> 404 Page Not Found --> c_oas044/load_form
ERROR - 2015-09-28 00:14:24 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 00:14:24 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 00:15:05 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 00:15:05 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 00:21:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 00:21:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 00:25:20 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-28 00:25:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-28 00:25:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-28 00:25:20 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-28 00:25:20 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-28 00:25:20 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-28 00:25:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-28 00:25:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-28 00:26:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-28 00:55:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-28 00:55:24 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-28 00:55:24 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-28 00:55:24 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-28 00:55:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-28 00:55:25 --> 404 Page Not Found --> assets
ERROR - 2015-09-28 01:22:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 01:22:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 01:23:12 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-28 01:23:12 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-28 01:23:12 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-28 01:23:12 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-28 01:23:12 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-28 01:23:12 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-28 01:25:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 01:46:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-28 01:46:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-28 01:46:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-28 01:46:46 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-28 01:46:46 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-28 01:46:47 --> 404 Page Not Found --> assets
ERROR - 2015-09-28 02:31:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 02:31:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 02:32:36 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-28 02:32:47 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-28 02:32:58 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-28 02:33:16 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-28 02:33:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 02:33:53 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-28 02:35:21 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-28 02:59:48 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 02:59:48 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 03:01:23 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 03:01:23 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 03:05:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 03:52:35 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-28 03:52:35 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-28 03:52:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-28 03:52:36 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-28 03:53:09 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-28 03:53:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-28 03:53:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-28 03:53:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-28 03:53:09 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-28 03:53:09 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-28 03:53:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-28 05:07:24 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-28 05:07:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-28 05:10:09 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-28 05:10:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-28 06:34:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 06:34:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 07:57:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 07:57:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 10:02:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 11:55:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 17:40:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 17:41:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 17:41:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-28 17:41:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-28 17:41:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-28 17:41:51 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-28 17:41:51 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-28 17:41:51 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-28 17:51:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 17:51:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 18:49:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 20:22:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 20:56:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:12:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:12:25 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-28 21:12:25 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-28 21:12:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-28 21:12:26 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-28 21:13:08 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-28 21:13:08 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-28 21:13:08 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-28 21:13:09 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-28 21:13:29 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-28 21:13:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-28 21:13:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-28 21:13:29 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-28 21:13:29 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-28 21:13:29 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-28 21:13:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:13:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:14:34 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 176
ERROR - 2015-09-28 21:15:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:15:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:15:43 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 21:15:43 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 21:18:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:18:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 21:19:48 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-28 21:19:48 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-28 21:19:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-28 21:19:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-28 21:25:36 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-28 21:31:28 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-28 21:32:02 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-28 21:32:31 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-28 21:33:34 --> 404 Page Not Found --> assets
ERROR - 2015-09-28 22:02:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 22:12:52 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-28 22:12:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-28 22:17:56 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 22:17:56 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 22:18:41 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 22:18:41 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 22:18:58 --> Severity: Warning  --> mysql_query(): Unable to save result set /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-09-28 22:18:58 --> Query error: Subquery returns more than 1 row
ERROR - 2015-09-28 23:26:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 23:26:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-28 23:26:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-28 23:26:56 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-28 23:26:56 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-28 23:26:56 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-28 23:26:56 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-28 23:26:56 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
