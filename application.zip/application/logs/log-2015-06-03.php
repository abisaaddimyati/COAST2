<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-03 01:35:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-03 02:37:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-03 03:35:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-03 10:42:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-03 19:19:08 --> 404 Page Not Found --> robots.txt
ERROR - 2015-06-03 19:43:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-03 20:15:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-03 22:20:44 --> 404 Page Not Found --> favicon.ico
