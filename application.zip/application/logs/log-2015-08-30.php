<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-30 03:23:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-30 20:15:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-30 20:48:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-30 21:03:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-30 21:03:43 --> 404 Page Not Found --> favicon.ico
