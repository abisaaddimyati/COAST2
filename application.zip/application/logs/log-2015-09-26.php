<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-26 10:16:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-26 20:23:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-26 20:47:55 --> 404 Page Not Found --> favicon.ico
