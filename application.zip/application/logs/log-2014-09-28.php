<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-28 20:55:00 --> 404 Page Not Found --> NldjZ
