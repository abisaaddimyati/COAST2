<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-11 08:46:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 09:15:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 09:16:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-11 09:16:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-11 09:16:03 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-11 09:16:04 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-11 09:16:37 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-11 09:20:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-11 09:20:06 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-11 09:20:06 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-11 09:20:06 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-11 09:20:06 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-11 09:20:06 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-11 09:20:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined index: name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 133
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 140
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 154
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-11 09:36:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 250
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined index: approval_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 428
ERROR - 2015-10-11 09:36:49 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 431
ERROR - 2015-10-11 09:36:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-11 19:55:18 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-11 19:55:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 19:55:18 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-11 19:55:19 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-11 19:55:19 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-11 20:22:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 20:22:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 20:53:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 20:53:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 20:55:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:03:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:03:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:03:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:06:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:06:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:38:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 21:56:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 22:30:08 --> 404 Page Not Found --> assets
ERROR - 2015-10-11 22:33:53 --> 404 Page Not Found --> login
ERROR - 2015-10-11 22:33:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 22:37:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-11 22:37:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-11 22:37:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-11 22:37:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-11 22:38:31 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-10-11 22:40:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 22:40:06 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-11 22:40:07 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-11 22:40:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-11 22:40:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-11 22:40:40 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-11 22:40:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-11 22:55:25 --> 404 Page Not Found --> assets
ERROR - 2015-10-11 23:48:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 23:48:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 23:48:51 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-11 23:48:59 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-11 23:51:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-11 23:53:25 --> 404 Page Not Found --> intranet.cybertrend-intra.comc_oas045
ERROR - 2015-10-11 23:54:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-11 23:54:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-11 23:54:33 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-11 23:54:34 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-11 23:55:46 --> 404 Page Not Found --> intranet.cybertrend-intra.comc_oas022
ERROR - 2015-10-11 23:56:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-10-11 23:56:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-10-11 23:56:08 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-10-11 23:56:10 --> 404 Page Not Found --> jquery.js
