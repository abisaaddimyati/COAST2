<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-04 11:31:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 15:59:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 17:53:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:10:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:19:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:22:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:22:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:35:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:35:42 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-04 20:35:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:35:43 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-04 20:35:43 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-04 20:35:43 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-04 20:36:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:36:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:38:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-10-04 20:38:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-04 20:38:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-04 20:38:52 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-10-04 20:38:52 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-10-04 20:38:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-04 20:41:06 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-04 20:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-04 20:41:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:52:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 20:52:47 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-04 20:52:50 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-04 21:02:32 --> 404 Page Not Found --> intranet.cybertrend-intra.comc_oas020
ERROR - 2015-10-04 21:04:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 21:08:33 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-04 21:08:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-04 21:23:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 23:58:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 23:58:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 23:59:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-04 23:59:09 --> 404 Page Not Found --> favicon.ico
