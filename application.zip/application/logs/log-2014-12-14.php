<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-14 19:17:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-14 19:18:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-14 19:19:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-14 19:20:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-14 21:28:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-14 21:29:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
