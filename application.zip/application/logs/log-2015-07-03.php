<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-03 01:23:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:30:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:30:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:30:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:30:50 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-03 01:31:17 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-03 01:31:44 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-03 01:34:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:34:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:34:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:34:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:36:22 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-03 01:41:55 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-03 01:42:11 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-07-03 01:43:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-03 01:59:13 --> 404 Page Not Found --> favicon.ico
