<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-18 20:16:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-18 20:22:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-18 20:22:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-18 20:23:38 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:23:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:23:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:23:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:23:42 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:23:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:23:49 --> 404 Page Not Found --> assets
ERROR - 2014-09-18 20:24:04 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 122
ERROR - 2014-09-18 20:24:04 --> Severity: Notice  --> Undefined index: EMPLOYEE_RM_ID /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas011.php 145
ERROR - 2014-09-18 20:24:45 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:24:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:24:45 --> Severity: Notice  --> Undefined index: employee_group_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 242
ERROR - 2014-09-18 20:24:45 --> Severity: Notice  --> Undefined index: employee_division_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 243
ERROR - 2014-09-18 20:25:19 --> 404 Page Not Found --> assets
ERROR - 2014-09-18 20:30:49 --> 404 Page Not Found --> assets
ERROR - 2014-09-18 20:31:55 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:31:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-09-18 20:31:55 --> Severity: Notice  --> Undefined index: employee_division_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 243
ERROR - 2014-09-18 20:33:15 --> 404 Page Not Found --> assets
ERROR - 2014-09-18 20:48:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-18 20:48:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-18 20:49:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-09-18 20:53:35 --> 404 Page Not Found --> favicon.ico
