<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-16 22:46:18 --> 404 Page Not Found --> favicon.ico
