<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-08 11:57:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-08 23:47:12 --> 404 Page Not Found --> favicon.ico
