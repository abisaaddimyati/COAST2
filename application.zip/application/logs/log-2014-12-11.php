<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-11 06:09:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-11 06:11:42 --> Severity: Notice  --> Undefined variable: value /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas069.php 213
ERROR - 2014-12-11 06:11:42 --> Severity: Notice  --> Undefined variable: value /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas069.php 242
ERROR - 2014-12-11 10:26:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-11 10:26:21 --> 404 Page Not Found --> favicon.ico
