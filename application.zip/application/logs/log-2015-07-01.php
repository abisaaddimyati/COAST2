<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-01 00:34:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-01 00:36:37 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-07-01 00:40:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-01 00:40:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-01 20:43:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-01 20:43:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-01 21:00:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-01 21:00:09 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-01 21:00:09 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-01 23:58:25 --> 404 Page Not Found --> favicon.ico
