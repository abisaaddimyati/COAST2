<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-05 23:02:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-05 23:03:12 --> 404 Page Not Found --> favicon.ico
