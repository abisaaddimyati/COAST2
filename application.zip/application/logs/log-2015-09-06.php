<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-06 21:11:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 21:13:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 22:08:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 22:09:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 22:35:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 22:35:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 23:19:39 --> 404 Page Not Found --> assets
ERROR - 2015-09-06 23:20:07 --> 404 Page Not Found --> assets
ERROR - 2015-09-06 23:29:37 --> 404 Page Not Found --> assets
ERROR - 2015-09-06 23:41:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 23:41:50 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-06 23:41:54 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-06 23:41:59 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-06 23:42:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-06 23:42:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-06 23:42:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-06 23:42:24 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-06 23:42:24 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-06 23:42:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-09-06 23:42:32 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-09-06 23:43:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-09-06 23:43:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-09-06 23:48:35 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:49:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-06 23:49:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-06 23:49:56 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-06 23:49:56 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-06 23:50:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-06 23:50:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-06 23:50:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-06 23:50:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-06 23:50:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-06 23:50:14 --> 404 Page Not Found --> assets
ERROR - 2015-09-06 23:50:40 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:51:05 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-06 23:51:05 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-06 23:51:05 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-06 23:51:05 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-06 23:51:05 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-06 23:51:05 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-06 23:51:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas075.php 247
ERROR - 2015-09-06 23:51:13 --> 404 Page Not Found --> assets
ERROR - 2015-09-06 23:51:20 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:51:27 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:51:48 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:53:59 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:54:13 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:55:27 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:55:43 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:55:54 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
ERROR - 2015-09-06 23:56:08 --> Query error: Unknown column 'fs.F2_APPROVE' in 'field list'
