<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-21 06:24:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-21 06:25:09 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-21 19:17:34 --> 404 Page Not Found --> favicon.ico
