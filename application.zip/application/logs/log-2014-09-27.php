<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-27 06:29:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-27 06:29:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-27 06:29:31 --> 404 Page Not Found --> favicon.ico
