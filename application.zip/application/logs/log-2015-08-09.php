<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-09 18:41:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-09 18:41:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-09 19:59:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-09 20:32:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-09 20:32:53 --> 404 Page Not Found --> favicon.ico
