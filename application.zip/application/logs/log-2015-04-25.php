<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-25 20:26:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-25 21:03:16 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-25 21:03:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-25 21:03:17 --> 404 Page Not Found --> apple-touch-icon.png
