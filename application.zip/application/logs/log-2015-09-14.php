<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-14 00:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 00:06:04 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-09-14 00:11:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 00:14:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-14 00:14:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 00:14:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 00:14:10 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 00:14:10 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-14 00:14:11 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 00:14:27 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-14 00:14:27 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-14 00:14:27 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-14 00:14:27 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-14 00:19:07 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 00:22:49 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-14 00:22:49 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-14 00:22:49 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-14 00:22:50 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-14 00:28:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 00:28:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 00:42:51 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 00:47:51 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 01:47:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 01:49:44 --> 404 Page Not Found --> browserconfig.xml
ERROR - 2015-09-14 02:00:27 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 02:26:48 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 02:47:26 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:08:40 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:38:10 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:39:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-14 03:39:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 03:39:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 03:39:22 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 03:39:22 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-14 03:39:23 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:40:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 03:40:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 03:42:02 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:48:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 03:48:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 03:50:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-14 03:50:40 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 03:50:40 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 03:50:40 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-14 03:50:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-14 03:50:40 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:52:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-14 03:52:36 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:52:49 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:52:52 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:53:58 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 03:54:12 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 164
ERROR - 2015-09-14 03:54:27 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 164
ERROR - 2015-09-14 03:54:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-14 03:54:33 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 04:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-14 04:00:40 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 04:00:52 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 04:31:04 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 04:35:52 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 05:12:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 05:13:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 05:13:27 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 05:13:40 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 05:13:59 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 164
ERROR - 2015-09-14 05:14:04 --> Severity: Warning  --> Missing argument 1 for C_OAS031::delete_doc() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas031.php 164
ERROR - 2015-09-14 21:06:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 21:58:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-14 21:58:36 --> 404 Page Not Found --> assets
ERROR - 2015-09-14 22:09:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-14 22:31:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 22:36:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 22:36:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-14 22:37:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas031.php 161
ERROR - 2015-09-14 22:37:18 --> 404 Page Not Found --> assets
