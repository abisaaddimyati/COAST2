<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-18 08:06:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-18 11:57:10 --> 404 Page Not Found --> robots.txt
