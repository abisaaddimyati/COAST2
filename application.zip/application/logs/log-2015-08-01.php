<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-01 01:49:47 --> 404 Page Not Found --> robots.txt
ERROR - 2015-08-01 20:06:33 --> 404 Page Not Found --> favicon.ico
