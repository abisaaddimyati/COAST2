<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-24 05:08:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 05:11:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 05:31:57 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 05:37:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 05:37:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 05:51:30 --> Query error: Duplicate entry '1-3' for key 'PRIMARY'
ERROR - 2015-02-24 20:50:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:02:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:02:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:24:27 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:24:48 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:25:17 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:26:04 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:29:15 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:29:29 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:30:19 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:34:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:34:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:34:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:35:24 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:35:36 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:41:12 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:43:58 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:44:31 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:45:37 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:45:47 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:47:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-02-24 21:47:06 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 126
ERROR - 2015-02-24 21:47:20 --> 404 Page Not Found --> jquery.js
ERROR - 2015-02-24 21:48:26 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2015-02-24 21:49:16 --> 404 Page Not Found --> jquery.js
ERROR - 2015-02-24 21:49:31 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:50:21 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:52:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:52:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-24 21:53:32 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:58:20 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 21:59:10 --> Severity: Notice  --> Undefined index: USER_EMAIL /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas006.php 300
ERROR - 2015-02-24 22:06:03 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 22:06:21 --> 404 Page Not Found --> C_OAS014
ERROR - 2015-02-24 22:06:43 --> 404 Page Not Found --> C_OAS014
