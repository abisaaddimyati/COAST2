<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-20 04:15:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-20 05:28:07 --> 404 Page Not Found --> favicon.ico
