<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-21 04:13:01 --> 404 Page Not Found --> assets
ERROR - 2014-10-21 04:13:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-21 04:13:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-10-21 04:13:17 --> 404 Page Not Found --> favicon.ico
