<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-11 03:00:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 03:00:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 03:25:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 03:25:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 03:25:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 03:29:26 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:29:29 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:29:30 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:30:51 --> 404 Page Not Found --> C_OAS022
ERROR - 2014-11-11 03:30:53 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 03:31:03 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:31:11 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:32:07 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 03:32:07 --> 404 Page Not Found --> C_OAS022
ERROR - 2014-11-11 03:32:26 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:32:34 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:32:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-11-11 03:32:51 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:39:49 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:39:50 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-11-11 03:45:20 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:20 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:20 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:21 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:22 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:22 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:27 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:28 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:29 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:30 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:31 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:31 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:32 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:34 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:40 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:41 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:41 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:42 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:43 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:44 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:45 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:47 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:47 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:48 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:54 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:55 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:45:59 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:01 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:02 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:03 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:04 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:04 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:05 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:06 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:07 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:13 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:14 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:15 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:16 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:17 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:18 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:19 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:20 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:20 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:21 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:22 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:28 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:28 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:29 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:30 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:31 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:31 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:32 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:32 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:34 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:39 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:40 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:40 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:41 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:41 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:41 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:42 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:42 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:43 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:43 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:43 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:44 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:44 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:44 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:45 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:45 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:45 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:47 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:48 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:53 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:53 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:53 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:54 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:54 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:55 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:55 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:56 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:56 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:56 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:56 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:57 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:57 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:58 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:58 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:58 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:59 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:59 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:46:59 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:00 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:00 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:01 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:05 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:06 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:06 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:07 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:07 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:07 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:07 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:08 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:09 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:10 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:10 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:11 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:12 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:13 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:13 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:18 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:19 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:20 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:21 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:22 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:23 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:24 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:25 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:27 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:32 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:34 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:36 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:37 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:37 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:38 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:39 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:40 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:45 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:47 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:48 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:49 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:50 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:50 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:51 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:52 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:53 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:58 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:59 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:47:59 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:00 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:01 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:01 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:02 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:03 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:04 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 03:48:22 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:48:24 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:48:27 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-11-11 03:48:36 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:48:56 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:49:07 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:49:11 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:49:20 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:49:34 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:49:47 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:50:00 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 03:50:05 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:50:08 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:50:17 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 03:51:12 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:51:18 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:51:21 --> 404 Page Not Found --> C_OAS008
ERROR - 2014-11-11 03:51:32 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:51:32 --> 404 Page Not Found --> C_OAS026
ERROR - 2014-11-11 03:51:33 --> 404 Page Not Found --> C_OAS030
ERROR - 2014-11-11 03:51:33 --> 404 Page Not Found --> C_OAS028
ERROR - 2014-11-11 03:52:33 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:53:15 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:53:51 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 03:53:53 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 03:54:02 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 03:58:22 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 03:58:23 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 04:01:59 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 04:02:01 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 04:03:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-11-11 04:03:21 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 04:05:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 04:05:58 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 04:06:55 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 04:06:57 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 04:07:07 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 04:07:36 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 04:08:02 --> 404 Page Not Found --> C_OAS022
ERROR - 2014-11-11 04:08:10 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 04:08:32 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 04:08:32 --> 404 Page Not Found --> C_OAS008
ERROR - 2014-11-11 04:08:46 --> 404 Page Not Found --> C_OAS026
ERROR - 2014-11-11 04:08:57 --> 404 Page Not Found --> C_OAS030
ERROR - 2014-11-11 04:09:00 --> 404 Page Not Found --> C_OAS026
ERROR - 2014-11-11 04:09:26 --> 404 Page Not Found --> C_OAS022
ERROR - 2014-11-11 04:09:40 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 06:28:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 06:28:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 06:29:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 06:30:07 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 06:32:23 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:23 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:23 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:24 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:24 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:25 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:25 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:27 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:32 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:32 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:33 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:34 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:35 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:36 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:36 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:37 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:43 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:44 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:46 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 06:32:46 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min2
ERROR - 2014-11-11 06:32:47 --> 404 Page Not Found --> c_oas004/feed_claim_transport_left_counter
ERROR - 2014-11-11 06:32:48 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin1_left_counter
ERROR - 2014-11-11 06:32:48 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin2_left_counter
ERROR - 2014-11-11 06:32:49 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasi_left_counter
ERROR - 2014-11-11 06:32:49 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin1_left_counter
ERROR - 2014-11-11 06:32:49 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin2_left_counter
ERROR - 2014-11-11 06:32:55 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter
ERROR - 2014-11-11 06:32:56 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min1
ERROR - 2014-11-11 06:32:57 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min2
ERROR - 2014-11-11 06:32:57 --> 404 Page Not Found --> c_oas004/feed_claim_transport_left_counter
ERROR - 2014-11-11 06:32:57 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin1_left_counter
ERROR - 2014-11-11 06:32:58 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin2_left_counter
ERROR - 2014-11-11 06:32:58 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasi_left_counter
ERROR - 2014-11-11 06:32:59 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin1_left_counter
ERROR - 2014-11-11 06:32:59 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin2_left_counter
ERROR - 2014-11-11 06:33:28 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter
ERROR - 2014-11-11 06:33:29 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min1
ERROR - 2014-11-11 06:33:29 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min2
ERROR - 2014-11-11 06:33:30 --> 404 Page Not Found --> c_oas004/feed_claim_transport_left_counter
ERROR - 2014-11-11 06:33:30 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin1_left_counter
ERROR - 2014-11-11 06:33:31 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin2_left_counter
ERROR - 2014-11-11 06:33:31 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasi_left_counter
ERROR - 2014-11-11 06:33:32 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin1_left_counter
ERROR - 2014-11-11 06:33:32 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin2_left_counter
ERROR - 2014-11-11 06:33:38 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter
ERROR - 2014-11-11 06:33:38 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min1
ERROR - 2014-11-11 06:33:39 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min2
ERROR - 2014-11-11 06:33:40 --> 404 Page Not Found --> c_oas004/feed_claim_transport_left_counter
ERROR - 2014-11-11 06:33:41 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin1_left_counter
ERROR - 2014-11-11 06:33:42 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin2_left_counter
ERROR - 2014-11-11 06:33:42 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasi_left_counter
ERROR - 2014-11-11 06:33:43 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin1_left_counter
ERROR - 2014-11-11 06:33:43 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin2_left_counter
ERROR - 2014-11-11 06:33:49 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter
ERROR - 2014-11-11 06:33:50 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min1
ERROR - 2014-11-11 06:33:51 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min2
ERROR - 2014-11-11 06:33:51 --> 404 Page Not Found --> c_oas004/feed_claim_transport_left_counter
ERROR - 2014-11-11 06:33:51 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin1_left_counter
ERROR - 2014-11-11 06:33:52 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin2_left_counter
ERROR - 2014-11-11 06:33:52 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasi_left_counter
ERROR - 2014-11-11 06:33:53 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin1_left_counter
ERROR - 2014-11-11 06:33:54 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin2_left_counter
ERROR - 2014-11-11 06:34:00 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter
ERROR - 2014-11-11 06:34:00 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min1
ERROR - 2014-11-11 06:34:00 --> 404 Page Not Found --> c_oas004/feed_claim_left_counter_min2
ERROR - 2014-11-11 06:34:01 --> 404 Page Not Found --> c_oas004/feed_claim_transport_left_counter
ERROR - 2014-11-11 06:34:01 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin1_left_counter
ERROR - 2014-11-11 06:34:02 --> 404 Page Not Found --> c_oas004/feed_claim_transportmin2_left_counter
ERROR - 2014-11-11 06:34:02 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasi_left_counter
ERROR - 2014-11-11 06:34:03 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin1_left_counter
ERROR - 2014-11-11 06:34:03 --> 404 Page Not Found --> c_oas004/feed_claim_komunikasimin2_left_counter
ERROR - 2014-11-11 06:34:09 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 06:35:09 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 06:35:19 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 06:35:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 69
ERROR - 2014-11-11 06:39:35 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 06:39:37 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 06:40:29 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 06:40:30 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 06:50:06 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 06:57:36 --> 404 Page Not Found --> C_OAS016
ERROR - 2014-11-11 06:57:38 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 06:57:39 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 06:57:41 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 07:56:42 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:56:43 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:56:48 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:56:49 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:56:54 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:56:55 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:00 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:01 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:06 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:07 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:12 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:13 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:18 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:19 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:24 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:26 --> 404 Page Not Found --> c_oas004
ERROR - 2014-11-11 07:57:28 --> 404 Page Not Found --> c_oas002
ERROR - 2014-11-11 08:02:57 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:03:24 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:07:50 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:07:56 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:02 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:09 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:16 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:22 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:28 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:34 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:40 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:49 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:08:55 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:09:01 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:09:08 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:09:14 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:09:21 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:09:51 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 08:09:54 --> 404 Page Not Found --> C_OAS022
ERROR - 2014-11-11 08:10:00 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 08:10:01 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 08:10:05 --> 404 Page Not Found --> C_OAS005
ERROR - 2014-11-11 08:10:41 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:41 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:42 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:10:47 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:10:48 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:49 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:49 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:51 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:52 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:52 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:53 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:54 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:55 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:10:56 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:11:03 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:11:04 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:06 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:08 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:18 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:19 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:20 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:21 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:22 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:23 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:11:30 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:12:17 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:12:51 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:14:32 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:15:28 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:15:42 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:16:36 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:17:38 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim' doesn't exist
ERROR - 2014-11-11 08:21:30 --> 404 Page Not Found --> C_OAS022
ERROR - 2014-11-11 08:21:31 --> 404 Page Not Found --> C_OAS024
ERROR - 2014-11-11 08:21:41 --> 404 Page Not Found --> C_OAS015
ERROR - 2014-11-11 08:21:47 --> 404 Page Not Found --> C_OAS009
ERROR - 2014-11-11 08:23:37 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:23:38 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:39 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:39 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:40 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:40 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:41 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:42 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:42 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:43 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:44 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:23:49 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:23:50 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:50 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:51 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:51 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:52 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:53 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:54 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:54 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:55 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:23:55 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:24:01 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:24:02 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:03 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:03 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:04 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:05 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:06 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:06 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:07 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:07 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:08 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:24:13 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:24:15 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:16 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:17 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:56 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:24:58 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:01 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:06 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:08 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:25:13 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:25:14 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:16 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:17 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:17 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:18 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:19 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:19 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:20 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:21 --> Query error: Table 'cybertr5_intranet.tb_r_annual_claim_trx' doesn't exist
ERROR - 2014-11-11 08:25:21 --> Query error: Table 'cybertr5_intranet.tb_r_notification' doesn't exist
ERROR - 2014-11-11 08:25:28 --> Query error: Table 'cybertr5_intranet.tb_r_annual_leave_trx' doesn't exist
ERROR - 2014-11-11 08:27:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 08:27:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 08:27:47 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 08:45:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 08:45:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 08:45:48 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 08:47:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 08:47:54 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 08:47:56 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 08:56:16 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 08:56:16 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 08:56:18 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 08:59:04 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 08:59:04 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 08:59:05 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 08:59:16 --> 404 Page Not Found --> c_oas023/load_view
ERROR - 2014-11-11 09:10:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 09:10:26 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 09:10:27 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 09:15:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-11-11 09:39:17 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 09:39:17 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 09:39:18 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 09:39:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-11-11 15:12:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 15:16:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 15:16:06 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 15:17:04 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 17:05:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 17:05:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 19:14:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 19:41:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 19:45:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 19:45:13 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 19:46:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 20:21:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 20:21:47 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 20:21:47 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 20:21:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 20:21:58 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 20:21:59 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 20:22:10 --> 404 Page Not Found --> assets
ERROR - 2014-11-11 20:23:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 20:23:38 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 20:23:39 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 20:54:09 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 20:54:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 20:54:21 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 20:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 20:54:25 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 20:54:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 20:54:25 --> Severity: Notice  --> Undefined variable: detail_admin /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 252
ERROR - 2014-11-11 21:04:33 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 21:04:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2014-11-11 21:30:59 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 21:30:59 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 21:31:00 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 21:36:04 --> Query error: Table 'cybertr5_intranet.TB_R_FORM_STATUS' doesn't exist
ERROR - 2014-11-11 21:37:49 --> Query error: Table 'cybertr5_intranet.TB_R_FORM_STATUS' doesn't exist
ERROR - 2014-11-11 21:40:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 21:40:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 21:40:28 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 21:40:31 --> 404 Page Not Found --> C_OAS025
ERROR - 2014-11-11 21:43:49 --> Query error: Table 'cybertr5_intranet.TB_R_FORM_STATUS' doesn't exist
ERROR - 2014-11-11 22:58:41 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 22:58:41 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 22:58:41 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 23:04:34 --> Query error: Table 'cybertr5_intranet.TB_M_EMPLOYEE' doesn't exist
ERROR - 2014-11-11 23:05:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 23:06:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 23:06:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 23:06:54 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 23:08:10 --> Query error: Table 'cybertr5_intranet.TB_M_EMPLOYEE' doesn't exist
ERROR - 2014-11-11 23:09:35 --> Query error: Table 'cybertr5_intranet.TB_M_EMPLOYEE' doesn't exist
ERROR - 2014-11-11 23:10:05 --> Query error: Table 'cybertr5_intranet.TB_M_EMPLOYEE' doesn't exist
ERROR - 2014-11-11 23:12:10 --> Query error: Table 'cybertr5_intranet.TB_M_EMPLOYEE' doesn't exist
ERROR - 2014-11-11 23:18:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 23:18:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 23:25:16 --> Severity: Notice  --> Undefined index: start_dt /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 282
ERROR - 2014-11-11 23:25:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 23:25:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 23:26:01 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 23:26:26 --> Severity: Notice  --> Undefined index: start_dt /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 282
ERROR - 2014-11-11 23:36:19 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-11-11 23:36:19 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2014-11-11 23:36:20 --> 404 Page Not Found --> jquery.js
ERROR - 2014-11-11 23:37:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-11-11 23:41:44 --> Query error: Table 'cybertr5_intranet.TB_R_FORM_STATUS' doesn't exist
ERROR - 2014-11-11 23:46:42 --> Severity: Notice  --> Undefined index: kategory_claim /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 47
ERROR - 2014-11-11 23:46:42 --> Severity: Notice  --> Undefined index: kategory_claim /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 59
ERROR - 2014-11-11 23:47:07 --> Severity: Notice  --> Undefined index: kategory_claim /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 47
ERROR - 2014-11-11 23:47:07 --> Severity: Notice  --> Undefined index: kategory_claim /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 59
ERROR - 2014-11-11 23:47:51 --> Severity: Notice  --> Undefined index: kategory_claim /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 47
ERROR - 2014-11-11 23:47:51 --> Severity: Notice  --> Undefined index: kategory_claim /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas023.php 59
