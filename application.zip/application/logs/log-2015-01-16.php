<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-16 08:41:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-16 08:42:02 --> 404 Page Not Found --> favicon.ico
