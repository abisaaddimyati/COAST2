<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-02 02:49:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-02 02:49:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-02 02:55:13 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-02 03:08:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-02 03:15:25 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-02 03:15:30 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-02 03:15:41 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-10-02 03:27:45 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-02 03:27:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-10-02 04:43:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-02 07:22:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-02 10:02:06 --> 404 Page Not Found --> robots.txt
