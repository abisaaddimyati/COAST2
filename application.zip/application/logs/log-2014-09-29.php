<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-29 04:10:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-29 04:10:09 --> 404 Page Not Found --> favicon.ico
