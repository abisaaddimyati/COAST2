<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-03 00:11:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 00:11:39 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-11-03 00:11:39 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-11-03 00:11:39 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-11-03 00:11:39 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-03 00:11:53 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-11-03 00:13:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 00:22:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 01:29:30 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 01:29:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 01:29:30 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 01:29:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 02:39:09 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 02:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 02:39:09 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 02:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 02:39:42 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 02:39:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 02:39:42 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 02:39:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 02:46:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 03:43:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 03:43:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 03:44:18 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-03 03:44:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-03 03:44:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-03 03:44:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-03 03:44:18 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-03 03:44:18 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-03 03:44:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 03:55:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 03:55:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 17:34:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 17:34:37 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-11-03 17:34:39 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-11-03 17:49:30 --> 404 Page Not Found --> robots.txt
ERROR - 2015-11-03 17:59:44 --> 404 Page Not Found --> assets
ERROR - 2015-11-03 19:08:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 19:08:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 19:09:30 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:09:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:09:30 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:09:30 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:11:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 19:11:39 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-11-03 19:11:40 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-11-03 19:12:26 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:12:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:12:26 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:12:26 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:12:28 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:12:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:12:28 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:12:28 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:15:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 19:15:06 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 19:23:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 19:26:47 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:26:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:27:50 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:27:50 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:30:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:30:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:31:18 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:31:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:31:41 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:31:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:31:41 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:31:41 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:31:41 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:31:41 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:52:02 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:52:02 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:52:49 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:52:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:52:49 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:52:49 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:52:49 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:53:26 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:53:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:53:26 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:53:26 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:53:26 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:54:05 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:54:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:54:05 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:54:05 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:54:05 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:55:19 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:55:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:55:19 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:56:03 --> 404 Page Not Found --> assets
ERROR - 2015-11-03 19:56:12 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:56:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:56:12 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:58:08 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:58:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 19:58:08 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 19:58:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 19:58:48 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-11-03 19:58:48 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-11-03 19:58:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-11-03 19:58:48 --> 404 Page Not Found --> jquery.js
ERROR - 2015-11-03 19:58:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-03 19:58:57 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-03 19:58:57 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-03 19:58:57 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-03 19:58:57 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-03 19:58:57 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-03 19:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 20:00:49 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:00:49 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:00:49 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:03:11 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:03:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:03:11 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:12 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:04:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:04:12 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:12 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:12 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:12 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:12 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:38 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:04:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:04:38 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:38 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:38 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:38 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:04:38 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:06 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:05:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:05:06 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:06 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:06 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:06 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:06 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:23 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:05:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 20:05:23 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:23 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:23 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:23 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:05:23 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 20:19:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 20:19:00 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 20:48:04 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-03 20:48:04 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-03 20:48:04 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-03 20:48:04 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-03 20:48:04 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-03 20:48:04 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-03 20:48:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 20:48:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 20:48:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 20:48:56 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-11-03 20:48:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-11-03 20:51:27 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-11-03 20:51:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 100
ERROR - 2015-11-03 20:51:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 20:51:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 21:09:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 21:09:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 21:15:25 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-11-03 21:15:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-11-03 21:15:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-11-03 21:15:25 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-11-03 21:15:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-11-03 21:15:25 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-11-03 21:18:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-11-03 22:12:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:12:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:12:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:12:40 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:13:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:13:37 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:21:24 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 22:21:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-11-03 22:21:24 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 22:21:24 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 22:21:24 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-11-03 22:42:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:42:55 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:43:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:43:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:44:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:44:25 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:44:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:44:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:45:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:45:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:45:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 133
ERROR - 2015-11-03 22:45:33 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas059.php 134
ERROR - 2015-11-03 22:59:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 23:02:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 23:02:48 --> Severity: Warning  --> Missing argument 2 for C_OAS025::load_form() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas025.php 39
ERROR - 2015-11-03 23:02:48 --> Severity: Notice  --> Undefined variable: tipe_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas025.php 41
ERROR - 2015-11-03 23:18:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-11-03 23:18:41 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:18:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:18:41 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:18:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:19:38 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:19:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:19:38 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:19:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:19:53 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:19:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:19:53 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:19:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:20:47 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-11-03 23:20:47 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-11-03 23:20:56 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-03 23:20:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-03 23:20:56 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-03 23:20:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-03 23:21:02 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-03 23:21:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-11-03 23:21:02 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-03 23:21:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-11-03 23:21:12 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 23:21:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 23:21:12 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 23:21:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 23:21:33 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 23:21:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-11-03 23:21:33 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-11-03 23:21:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
