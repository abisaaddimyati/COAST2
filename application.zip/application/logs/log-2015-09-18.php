<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-18 00:28:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-18 00:28:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-18 12:43:22 --> 404 Page Not Found --> favicon.ico
