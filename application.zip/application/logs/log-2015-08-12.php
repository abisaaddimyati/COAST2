<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-12 20:26:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-12 21:55:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-12 22:16:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-12 22:16:01 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-08-12 22:16:01 --> 404 Page Not Found --> apple-touch-icon.png
