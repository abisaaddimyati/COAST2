<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-17 03:36:46 --> 404 Page Not Found --> favicon.ico
