<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-06 00:09:03 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 98
ERROR - 2014-12-06 00:09:05 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:12:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-06 00:13:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-06 00:13:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-12-06 00:17:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-12-06 00:17:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-12-06 00:17:27 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 166
ERROR - 2014-12-06 00:17:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-12-06 00:17:28 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:17:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-12-06 00:18:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-12-06 00:18:57 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 166
ERROR - 2014-12-06 00:18:58 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:20:15 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-12-06 00:20:15 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 166
ERROR - 2014-12-06 00:20:22 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:23:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 22
ERROR - 2014-12-06 00:23:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 166
ERROR - 2014-12-06 00:23:35 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:24:05 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:28:57 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:41:55 --> 404 Page Not Found --> jquery.js
ERROR - 2014-12-06 00:41:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas020.php 68
ERROR - 2014-12-06 00:49:17 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 104
ERROR - 2014-12-06 00:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 104
ERROR - 2014-12-06 00:51:39 --> 404 Page Not Found --> favicon.ico
