<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-23 01:30:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 01:32:21 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:32:35 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:32:39 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:32:48 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:32:52 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:32:56 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:33:03 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-23 01:33:13 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:33:30 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:35:27 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:36:42 --> Query error: Table 'cybertr5_intranet.tb_m_approval' doesn't exist
ERROR - 2015-03-23 01:39:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-23 01:45:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-03-23 01:45:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 79
ERROR - 2015-03-23 01:45:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 99
ERROR - 2015-03-23 01:45:35 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 167
ERROR - 2015-03-23 01:45:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 506
ERROR - 2015-03-23 01:45:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 527
ERROR - 2015-03-23 01:48:19 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-03-23 01:48:19 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-03-23 01:48:19 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-03-23 01:48:19 --> 404 Page Not Found --> jquery.js
ERROR - 2015-03-23 03:58:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 03:58:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 21:36:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 21:37:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 21:37:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 22:07:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-23 22:07:03 --> 404 Page Not Found --> favicon.ico
