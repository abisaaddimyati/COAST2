<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-12 05:13:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-12 05:13:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-12 05:14:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 50
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 57
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 71
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2015-01-12 05:14:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 329
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 330
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 331
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 337
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 396
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 397
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 398
ERROR - 2015-01-12 05:14:24 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 399
ERROR - 2015-01-12 05:14:25 --> 404 Page Not Found --> jquery.js
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined variable: this_name /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 50
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined variable: this_email /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 57
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: divid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 71
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined variable: currency /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2015-01-12 05:24:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 167
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 329
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 330
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 331
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 337
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: amountid /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 396
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: amountid1 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 397
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: amountid2 /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 398
ERROR - 2015-01-12 05:24:11 --> Severity: Notice  --> Undefined index: btDuration /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 399
ERROR - 2015-01-12 05:24:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-01-12 05:24:29 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2015-01-12 05:24:30 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 124
ERROR - 2015-01-12 05:27:28 --> 404 Page Not Found --> jquery.js
ERROR - 2015-01-12 20:03:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-12 20:03:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-12 21:43:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_setl_amount /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 306
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_IDR /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 307
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_IDR_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 308
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_USD /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 310
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_SGD /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 311
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_USD_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 313
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_SGD_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 314
ERROR - 2015-01-12 21:46:49 --> Severity: Notice  --> Undefined index: liability_setl_amount_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 315
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_setl_amount /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 306
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_IDR /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 307
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_IDR_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 308
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_USD /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 310
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_SGD /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 311
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_USD_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 313
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_SGD_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 314
ERROR - 2015-01-12 21:47:10 --> Severity: Notice  --> Undefined index: liability_setl_amount_employee /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas046.php 315
