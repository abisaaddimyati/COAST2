<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-15 14:06:37 --> 404 Page Not Found --> robots.txt
