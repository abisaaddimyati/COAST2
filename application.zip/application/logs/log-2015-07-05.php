<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-05 20:52:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 20:55:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 21:00:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 21:24:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 21:44:10 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-07-05 21:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-07-05 21:45:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 21:45:16 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-07-05 21:45:16 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-07-05 21:57:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 21:58:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 22:29:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-05 22:29:31 --> 404 Page Not Found --> favicon.ico
