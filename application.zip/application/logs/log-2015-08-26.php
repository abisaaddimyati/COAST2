<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-26 04:00:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-26 04:00:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-26 17:34:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-26 20:23:34 --> 404 Page Not Found --> favicon.ico
