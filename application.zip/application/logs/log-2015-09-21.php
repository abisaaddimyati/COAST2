<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-21 00:01:35 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:02:16 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:02:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 00:02:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 00:03:05 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:03:36 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:03:55 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-21 00:03:55 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-21 00:03:55 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-21 00:03:55 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-21 00:03:55 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-21 00:03:55 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-21 00:04:01 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:04:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-21 00:04:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-21 00:04:36 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:06:22 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-21 00:06:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-09-21 00:43:52 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-21 00:43:52 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-21 00:43:52 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-21 00:43:52 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-21 00:43:52 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-21 00:43:52 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-21 00:43:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-21 00:44:22 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-21 00:44:22 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-21 00:44:22 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-21 00:44:22 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-21 00:44:22 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-21 00:44:22 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-21 00:44:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-21 00:49:03 --> Query error: Duplicate entry 'CBI.072.150915' for key 'PRIMARY'
ERROR - 2015-09-21 00:52:07 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-09-21 00:52:17 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-21 00:52:17 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-21 00:52:17 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-21 00:52:18 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-21 00:52:39 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-09-21 00:53:53 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 00:54:46 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 01:01:50 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-21 01:01:50 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-21 01:01:50 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-21 01:01:50 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-21 01:01:50 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-21 01:01:50 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-21 01:01:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-21 01:02:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-21 01:15:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 01:15:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 01:17:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 01:17:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 01:18:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-21 01:18:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-21 01:18:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-21 01:18:42 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-21 01:20:04 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-21 01:20:04 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-21 01:20:04 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-21 01:20:04 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-21 01:20:25 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-21 01:20:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-21 01:20:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-21 01:20:25 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-21 01:20:25 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-21 01:20:25 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-21 01:23:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 01:32:20 --> 404 Page Not Found --> browserconfig.xml
ERROR - 2015-09-21 01:32:23 --> 404 Page Not Found --> browserconfig.xml
ERROR - 2015-09-21 01:49:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 01:50:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 02:14:19 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 262
ERROR - 2015-09-21 02:14:19 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 266
ERROR - 2015-09-21 02:14:19 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 267
ERROR - 2015-09-21 02:14:20 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 345
ERROR - 2015-09-21 02:14:20 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 349
ERROR - 2015-09-21 02:14:20 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas067.php 350
ERROR - 2015-09-21 02:18:04 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 463
ERROR - 2015-09-21 02:18:04 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 467
ERROR - 2015-09-21 02:18:04 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-09-21 02:18:04 --> Severity: Notice  --> Undefined variable: status /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas057.php 468
ERROR - 2015-09-21 02:18:07 --> Severity: Notice  --> Undefined index: REQUESTER_NAMA /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas033.php 375
ERROR - 2015-09-21 02:53:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 02:53:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 03:45:09 --> 404 Page Not Found --> OAS
ERROR - 2015-09-21 07:33:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 20:33:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 20:56:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 21:06:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 21:06:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 22:16:54 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-21 22:16:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 22:19:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 22:20:14 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-21 22:20:53 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-09-21 23:41:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-21 23:41:50 --> 404 Page Not Found --> favicon.ico
