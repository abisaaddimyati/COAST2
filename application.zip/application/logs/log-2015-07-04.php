<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-04 22:44:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-04 22:44:49 --> 404 Page Not Found --> favicon.ico
