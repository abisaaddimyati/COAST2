<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-27 00:10:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 00:10:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 00:19:44 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 00:19:44 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 00:19:44 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 00:19:45 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 00:21:45 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 00:21:45 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 00:21:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 00:21:46 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 00:26:51 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 00:26:51 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 00:26:51 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 00:26:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 00:36:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 00:36:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 00:36:31 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 00:37:19 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 00:37:49 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 00:38:28 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 00:40:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 01:03:13 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-10-27 01:03:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-10-27 01:03:13 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-10-27 01:03:22 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-10-27 01:03:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-10-27 01:03:22 --> Severity: Notice  --> Undefined index: balance_leave /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 249
ERROR - 2015-10-27 01:15:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 01:15:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 01:36:59 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 01:37:51 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-27 01:37:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-27 01:37:51 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-27 01:37:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-27 01:37:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 01:39:15 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 01:39:34 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 01:40:11 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 01:41:00 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 01:41:45 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-27 01:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-27 01:41:45 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-27 01:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-27 02:27:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 02:28:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:28:24 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:28:26 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:36:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:36:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:36:32 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:37:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:37:01 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:37:02 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:37:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:37:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:37:46 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:37:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:37:56 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:37:57 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:38:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:38:35 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:38:36 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:40:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:40:12 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:40:12 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:40:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:40:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:40:42 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:40:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:40:48 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:40:49 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:41:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:41:36 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:41:37 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 02:47:34 --> Severity: Notice  --> Undefined variable: month /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/models/m_oas070.php 296
ERROR - 2015-10-27 02:47:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 417
ERROR - 2015-10-27 02:47:45 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 640
ERROR - 2015-10-27 02:47:45 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 03:26:33 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 03:29:47 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-27 03:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 101
ERROR - 2015-10-27 03:29:47 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-27 03:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas072.php 151
ERROR - 2015-10-27 03:29:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 06:59:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 16:28:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 17:32:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 17:32:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 17:32:53 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-27 17:32:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-27 17:32:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-27 17:32:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-27 17:32:53 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-27 17:32:53 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-27 17:32:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-27 20:19:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:19:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:20:55 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-27 20:20:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 102
ERROR - 2015-10-27 20:20:55 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-27 20:20:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas044.php 152
ERROR - 2015-10-27 20:26:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:26:55 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-27 20:26:56 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-27 20:26:57 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-27 20:26:57 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-27 20:27:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:27:40 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-27 20:27:40 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-27 20:33:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:37:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:42:57 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 20:42:57 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 20:42:57 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 20:42:57 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 20:47:42 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 20:47:42 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 20:47:42 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 20:47:42 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 20:50:49 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 20:50:49 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 20:50:49 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 20:50:49 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 20:54:23 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 20:54:53 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 20:56:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:56:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 20:57:44 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 20:58:21 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 20:58:47 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 20:59:11 --> 404 Page Not Found --> assets
ERROR - 2015-10-27 21:00:53 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 102
ERROR - 2015-10-27 21:00:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 102
ERROR - 2015-10-27 21:02:36 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 102
ERROR - 2015-10-27 21:02:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas022.php 102
ERROR - 2015-10-27 21:08:17 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas056.php 102
ERROR - 2015-10-27 21:08:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas056.php 102
ERROR - 2015-10-27 21:08:17 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas056.php 151
ERROR - 2015-10-27 21:08:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas056.php 151
ERROR - 2015-10-27 21:42:07 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 21:42:07 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 21:42:07 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 21:42:08 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 21:46:08 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 21:46:08 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 21:46:08 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 21:46:10 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 21:47:30 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 21:47:30 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 21:47:30 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 21:47:32 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 21:50:58 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 21:50:58 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 21:50:58 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 21:50:58 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 21:54:23 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 21:54:23 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 21:54:23 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 21:54:23 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 21:56:17 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 21:56:17 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 21:56:17 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 21:56:17 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 22:07:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 22:07:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 22:07:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 22:07:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 22:09:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 22:16:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 22:26:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 22:26:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 22:30:41 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 22:30:41 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 22:30:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 22:30:41 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 22:31:31 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-27 22:31:31 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-27 22:31:31 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-27 22:31:31 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-27 22:34:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 22:34:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 23:05:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 23:05:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 23:06:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 23:06:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-27 23:36:24 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas069.php 94
ERROR - 2015-10-27 23:36:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas069.php 94
