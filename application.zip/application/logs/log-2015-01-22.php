<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-22 14:19:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-22 14:20:38 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-01-22 14:21:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-01-22 14:22:40 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-01-22 14:22:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-01-22 14:23:06 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-01-22 14:23:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
