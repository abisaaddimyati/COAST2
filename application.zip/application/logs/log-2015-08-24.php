<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-24 01:03:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:04:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:04:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:04:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:04:15 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:04:15 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:04:16 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:05:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:05:41 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:05:41 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:05:41 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:05:41 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:05:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:05:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:05:47 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:06:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:06:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:06:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:06:39 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:06:39 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:06:40 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:12:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:14:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:14:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:14:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:14:29 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:14:29 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:14:31 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:15:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:16:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:16:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:16:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:16:13 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:16:13 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:16:20 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:17:25 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-08-24 01:17:25 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-08-24 01:17:25 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-08-24 01:17:34 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-24 01:19:16 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-08-24 01:19:16 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-08-24 01:19:16 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-08-24 01:19:16 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-08-24 01:19:16 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-08-24 01:19:16 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-08-24 01:19:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-08-24 01:19:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-08-24 01:19:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-08-24 01:25:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:26:27 --> Severity: Notice  --> Undefined index: remarks_finance /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas041.php 187
ERROR - 2015-08-24 01:27:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:28:20 --> Severity: Notice  --> Undefined index: remarks_finance /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas041.php 187
ERROR - 2015-08-24 01:28:32 --> Severity: Notice  --> Undefined index: remarks_finance /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas041.php 187
ERROR - 2015-08-24 01:30:20 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-08-24 01:30:20 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-08-24 01:30:20 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-08-24 01:30:22 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-24 01:39:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 01:40:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:40:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:40:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:40:16 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:40:16 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:40:17 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:40:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:40:38 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:40:38 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:40:38 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:40:38 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:40:40 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:41:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 409
ERROR - 2015-08-24 01:41:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:41:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:41:43 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 486
ERROR - 2015-08-24 01:41:43 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 572
ERROR - 2015-08-24 01:41:44 --> 404 Page Not Found --> assets
ERROR - 2015-08-24 01:41:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 02:19:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-08-24 02:19:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-08-24 02:19:10 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-08-24 02:19:13 --> 404 Page Not Found --> jquery.js
ERROR - 2015-08-24 05:08:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 05:08:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 07:04:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 07:07:08 --> Query error: Unknown column 'rpr.CREATED_PO' in 'where clause'
ERROR - 2015-08-24 07:07:57 --> Query error: Unknown column 'rpr.CREATED_PO' in 'where clause'
ERROR - 2015-08-24 07:11:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 07:11:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 07:11:51 --> Query error: Unknown column 'rpr.CREATED_PO' in 'where clause'
ERROR - 2015-08-24 07:12:22 --> Query error: Unknown column 'rpr.CREATED_PO' in 'where clause'
ERROR - 2015-08-24 07:16:24 --> Query error: Unknown column 'rpr.CREATED_PO' in 'where clause'
ERROR - 2015-08-24 07:16:32 --> Query error: Unknown column 'rpr.CREATED_PO' in 'where clause'
ERROR - 2015-08-24 11:07:09 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-08-24 19:00:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 20:39:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 20:39:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-24 23:44:09 --> 404 Page Not Found --> favicon.ico
