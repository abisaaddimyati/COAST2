<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-06 20:03:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-06 20:03:50 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-08-06 20:03:51 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-08-06 22:32:44 --> 404 Page Not Found --> favicon.ico
