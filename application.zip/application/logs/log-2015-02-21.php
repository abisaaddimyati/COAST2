<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-21 03:03:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-21 03:03:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-21 03:03:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-21 08:10:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-21 23:18:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-21 23:18:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-21 23:18:04 --> 404 Page Not Found --> favicon.ico
