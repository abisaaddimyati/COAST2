<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-22 18:43:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-22 18:43:50 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-03-22 18:43:51 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-03-22 20:41:43 --> 404 Page Not Found --> favicon.ico
