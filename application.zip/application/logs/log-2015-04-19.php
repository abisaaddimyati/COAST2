<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-19 07:05:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 07:05:45 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-19 07:24:26 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-19 07:24:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-04-19 07:58:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 07:58:26 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 07:58:28 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 07:59:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 07:59:15 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 07:59:16 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 07:59:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 07:59:27 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 07:59:28 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 07:59:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 07:59:36 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 07:59:40 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 08:03:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 08:03:15 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 08:03:16 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 08:03:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 08:03:18 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 08:03:19 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 08:16:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 09:45:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 09:46:42 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-19 09:53:35 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-04-19 09:53:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 81
ERROR - 2015-04-19 09:53:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 101
ERROR - 2015-04-19 09:53:35 --> Severity: Warning  --> Illegal string offset 'depth' /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 174
ERROR - 2015-04-19 09:53:35 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 517
ERROR - 2015-04-19 09:53:35 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 538
ERROR - 2015-04-19 19:52:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 19:52:50 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-04-19 19:52:51 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-04-19 23:34:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 23:34:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 23:34:44 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-04-19 23:34:52 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-04-19 23:35:11 --> 404 Page Not Found --> intranet.cybertrend-intra.com
ERROR - 2015-04-19 23:35:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-19 23:36:01 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
