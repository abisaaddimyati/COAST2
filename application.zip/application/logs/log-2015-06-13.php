<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-13 15:27:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-13 15:27:37 --> 404 Page Not Found --> favicon.ico
