<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-23 01:08:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 01:08:09 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-10-23 01:08:09 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-10-23 01:09:25 --> 404 Page Not Found --> assets
ERROR - 2015-10-23 01:15:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 03:25:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 03:29:58 --> 404 Page Not Found --> assets
ERROR - 2015-10-23 03:38:07 --> 404 Page Not Found --> assets
ERROR - 2015-10-23 08:07:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 08:07:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 08:08:48 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-23 08:08:48 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-23 08:08:48 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-23 08:08:48 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-23 08:08:48 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-23 08:08:48 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-23 08:09:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-23 08:09:27 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-10-23 08:09:27 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-10-23 08:09:27 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-10-23 08:09:28 --> 404 Page Not Found --> jquery.js
ERROR - 2015-10-23 08:09:40 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-10-23 08:09:40 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-10-23 08:09:40 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-10-23 08:09:40 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-10-23 08:09:40 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-10-23 08:09:40 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-10-23 08:09:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-10-23 08:15:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 08:15:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 09:18:59 --> 404 Page Not Found --> robots.txt
ERROR - 2015-10-23 16:22:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 16:53:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 16:53:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-10-23 18:14:58 --> 404 Page Not Found --> favicon.ico
