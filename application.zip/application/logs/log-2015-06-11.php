<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-11 00:15:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-11 00:23:52 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-06-11 00:23:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas015.php 102
ERROR - 2015-06-11 05:55:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-11 05:58:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-11 06:02:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-11 06:04:22 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-06-11 06:04:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-06-11 06:04:59 --> Severity: Notice  --> Undefined variable: list_division /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-06-11 06:04:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 103
ERROR - 2015-06-11 06:04:59 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-06-11 06:04:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas045.php 154
ERROR - 2015-06-11 06:06:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-11 06:06:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-11 06:07:15 --> 404 Page Not Found --> favicon.ico
