<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-15 01:22:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-15 01:22:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-15 20:01:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-15 20:01:08 --> 404 Page Not Found --> favicon.ico
