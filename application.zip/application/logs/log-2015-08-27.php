<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-27 01:16:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-27 10:53:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-27 10:53:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-08-27 10:53:50 --> 404 Page Not Found --> assets
ERROR - 2015-08-27 20:22:12 --> 404 Page Not Found --> favicon.ico
