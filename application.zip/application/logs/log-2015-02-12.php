<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-12 00:00:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-02-12 00:00:46 --> 404 Page Not Found --> favicon.ico
