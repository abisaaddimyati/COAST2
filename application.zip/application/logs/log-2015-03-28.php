<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-28 10:36:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-28 10:36:10 --> 404 Page Not Found --> favicon.ico
