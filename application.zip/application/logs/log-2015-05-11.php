<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-11 00:51:48 --> 404 Page Not Found --> favicon.ico
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-11 00:51:48 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-11 00:51:49 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-11 01:44:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-11 07:38:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-11 07:38:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-11 07:38:53 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-11 20:37:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-05-11 20:37:42 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-05-11 20:37:42 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-05-11 21:16:29 --> 404 Page Not Found --> favicon.ico
