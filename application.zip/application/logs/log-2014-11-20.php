<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-20 20:15:21 --> 404 Page Not Found --> favicon.ico
