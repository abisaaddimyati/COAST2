<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-25 00:41:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-25 00:41:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-06-25 04:39:42 --> 404 Page Not Found --> robots.txt
