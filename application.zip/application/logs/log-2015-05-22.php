<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-22 00:25:58 --> 404 Page Not Found --> favicon.ico
