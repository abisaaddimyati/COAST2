<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-15 01:09:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-15 01:09:46 --> Severity: Notice  --> Undefined variable: this_pwdStat /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas003.php 27
ERROR - 2015-04-15 05:23:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-15 05:25:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-04-15 05:25:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-04-15 05:25:51 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-04-15 05:25:52 --> 404 Page Not Found --> jquery.js
ERROR - 2015-04-15 06:03:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-04-15 22:29:34 --> 404 Page Not Found --> favicon.ico
