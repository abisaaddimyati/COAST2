<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-13 11:39:07 --> 404 Page Not Found --> favicon.ico
