<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-08 11:16:53 --> 404 Page Not Found --> favicon.ico
