<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-30 00:09:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 00:29:39 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-30 00:29:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-30 00:29:47 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-30 00:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-30 00:37:20 --> Severity: Notice  --> Undefined variable: list_chargecode /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-30 00:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas026.php 76
ERROR - 2015-09-30 00:44:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 00:44:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 00:51:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 00:56:21 --> 404 Page Not Found --> assets
ERROR - 2015-09-30 01:03:32 --> 404 Page Not Found --> assets
ERROR - 2015-09-30 01:05:15 --> 404 Page Not Found --> assets
ERROR - 2015-09-30 01:13:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 01:13:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 01:15:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 01:16:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 01:41:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-30 01:41:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-30 01:41:11 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-30 01:41:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-30 01:41:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 74
ERROR - 2015-09-30 01:41:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 75
ERROR - 2015-09-30 01:41:42 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas037.php 76
ERROR - 2015-09-30 01:41:43 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-30 01:43:32 --> Severity: Notice  --> Undefined index: traveller /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas037.php 125
ERROR - 2015-09-30 01:49:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 01:49:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 02:11:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 02:13:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 108
ERROR - 2015-09-30 02:13:11 --> Severity: Notice  --> Undefined variable: status_edit /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 118
ERROR - 2015-09-30 02:13:11 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas039.php 411
ERROR - 2015-09-30 02:13:11 --> 404 Page Not Found --> jquery.js
ERROR - 2015-09-30 02:13:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 02:13:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 02:19:46 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-30 02:19:46 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-30 02:19:46 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-30 02:19:46 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-30 02:19:46 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-30 02:19:46 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-30 02:53:15 --> Severity: Notice  --> Undefined variable: form_data /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 24
ERROR - 2015-09-30 02:53:15 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 82
ERROR - 2015-09-30 02:53:15 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 104
ERROR - 2015-09-30 02:53:15 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 124
ERROR - 2015-09-30 02:53:15 --> Severity: Notice  --> Undefined variable: bantu /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 540
ERROR - 2015-09-30 02:53:15 --> Severity: Notice  --> Undefined variable: tnj /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas024.php 561
ERROR - 2015-09-30 02:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/controllers/c_oas024.php 67
ERROR - 2015-09-30 03:26:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 03:30:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 03:32:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 03:33:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 03:33:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 05:15:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 05:15:28 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2015-09-30 05:15:29 --> 404 Page Not Found --> apple-touch-icon.png
ERROR - 2015-09-30 06:01:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 06:01:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 07:23:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 09:39:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 11:38:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 17:31:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 21:06:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 22:03:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 22:03:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-09-30 22:03:20 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 413
ERROR - 2015-09-30 22:03:20 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-30 22:03:20 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-30 22:03:20 --> Severity: Notice  --> Undefined variable: this_shipto /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 494
ERROR - 2015-09-30 22:03:20 --> Severity: Notice  --> Undefined variable: form_detail /home8/cybertr5/public_html/www.intranet-cybertrend-intra-com/application/views/v_oas070.php 577
ERROR - 2015-09-30 22:03:21 --> 404 Page Not Found --> assets
ERROR - 2015-09-30 22:37:16 --> 404 Page Not Found --> favicon.ico
