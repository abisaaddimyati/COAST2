<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-13 01:18:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-13 01:49:39 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-13 01:49:53 --> Query error: Unknown column 'AC.BT_ID' in 'where clause'
ERROR - 2015-07-13 20:05:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-13 20:05:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-13 22:44:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-13 22:44:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-07-13 23:48:07 --> 404 Page Not Found --> robots.txt
