<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-23 15:10:21 --> 404 Page Not Found --> robots.txt
ERROR - 2015-05-23 20:03:18 --> 404 Page Not Found --> favicon.ico
