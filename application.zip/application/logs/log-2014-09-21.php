<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-21 05:22:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-21 21:03:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-21 21:03:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2014-09-21 21:03:04 --> 404 Page Not Found --> favicon.ico
