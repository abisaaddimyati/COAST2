<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-06 03:30:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2015-03-06 09:54:24 --> 404 Page Not Found --> favicon.ico
